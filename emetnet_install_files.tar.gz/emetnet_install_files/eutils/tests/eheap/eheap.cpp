#include <eutils/emain.h>
#include <eutils/eheap.h>
#include <eutils/ernd.h>

eheap<int> arr;

int emain(){
  int i;
  int tmp;
  for (i=0; i<10; ++i){
    tmp=ernd.uniform()*20;
    cout << i << ": " << tmp << " ("<<arr.size()<<")"<< endl;
    arr.add(tmp);
  }

  i=0;
  while (arr.size()){
    cout << i << ": "<< arr.root()<<" " << arr.size() << endl;
    arr.delroot();
    ++i;
  }

  for (i=0; i<10; ++i){
    tmp=ernd.uniform()*20;
    cout << i << ": " << tmp << " ("<<arr.size()<<")"<< endl;
    arr.add(tmp);
  }

  i=0;
  while (arr.size()>5){
    cout << i << ": "<< arr.root()<<" " << arr.size() << endl;
    arr.delroot();
    ++i;
  }

  for (i=0; i<10; ++i){
    tmp=ernd.uniform()*20;
    cout << i << ": " << tmp << " ("<<arr.size()<<")"<< endl;
    arr.add(tmp);
  }

  for (i=0; i<20; ++i){
    cout << i << " exists? " << arr.exists(i) << endl;
  }


  i=0;
  while (arr.size()){
    cout << i << ": "<< arr.root()<<" " << arr.size() << endl;
    arr.delroot();
    ++i;
  }




  return(0);
}


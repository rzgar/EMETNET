#include <eutils/evar.h>
#include <eutils/etimer.h>
#include <iomanip>


class testclass
{
 public:
  int a;
  int testmethod();
};
int testclass::testmethod()
{
  ++a;
  if (a==0)
    return(0);

  if (a!=0) return(a);
}

int testfunc()
{
  static int b=0;

  ++b;
  if (b!=0) return(b);
  return(b);
}

testclass *ptc=new testclass;

int testfunc2()
{
  ++ptc->a;
  if (ptc->a==0) return(ptc->a);

  if (ptc->a!=0) return(ptc->a);
  return(-1);
}


int main()
{
  int i,i2;
  double ti,tm;
  etimer t1,t2;

  t1.reset();

  t2.reset();
  for (i=0; i<1000000; ++i){
  }
  ti=t2.lap();
  cout << "1000000 cycle takes: "<<setprecision(12)<<ti<<"msecs"<< endl;

  t2.reset();
  for (i=0; i<1000000; ++i){
    t1.lap();
  }
  tm=t2.lap();
  cout << "1000000 measurements takes: "<<setprecision(12)<<tm<<"msecs"<< endl;


  int a;
  t2.reset();
  for (i=0; i<1000000; ++i){
    a=2*i;
//    a=i*i;
  }
  tm=t2.lap();
  cout << "1000000 direct assignments takes: "<<setprecision(12)<<tm<<"msecs"<< endl;

  evar ea;
  ea=a;
  t2.reset();
  for (i=0; i<1000000; ++i){
    ea=2*i;
  }
  tm=t2.lap();
  cout << "1000000 evar assignments takes: "<<setprecision(12)<<tm<<"msecs"<< endl;

  t2.reset();
  for (i=0; i<1000000; ++i){
    a=2*ea.get<int>();
//    a=a*a;
  }
  tm=t2.lap();
  cout << "1000000 evar gets takes: "<<setprecision(12)<<tm<<"msecs"<< endl;

  double d;
  t2.reset();
  for (i=0; i<1000000; ++i){
    d=2.0*ea.get<double>();
//    d=d*d;
  }
  tm=t2.lap();
  cout << "1000000 evar conversion gets takes: "<<setprecision(12)<<tm<<"msecs"<< endl;

  t2.reset();
  for (i=0; i<1000000; ++i){
    a=2*testfunc();
//    a=a*a;
  }
  tm=t2.lap();
  cout << "1000000 testfunc gets takes: "<<setprecision(12)<<tm<<"msecs"<< endl;

  testclass tc;
  tc.a=1;
  t2.reset();
  for (i=0; i<1000000; ++i){
    a=2*tc.testmethod();
//    a=2*i;
  }
  tm=t2.lap();
  cout << "1000000 testmethod gets takes: "<<setprecision(12)<<tm<<"msecs"<< endl;

  t2.reset();
  for (i=0; i<1000000; ++i){
    a=2*testfunc2();
//    a=2*i;
  }
  tm=t2.lap();
  cout << "1000000 testfunc gets takes: "<<setprecision(12)<<tm<<"msecs"<< endl;

  return(0);
}

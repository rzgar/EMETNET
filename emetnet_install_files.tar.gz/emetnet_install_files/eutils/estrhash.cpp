#include "estrhash.h"

estr estrhash::join(const estr& fseparator,const estr& vseparator)
{
  estr str;

  int i;
  for (i=0; i<size()-1; ++i){
    if (keys(i).len()){
      str += keys(i);
      str += vseparator;
    }
    str += values(i);
    str += fseparator;
  }
  if (size()){  
    if (keys(i).len()){
      str += keys(i);
      str += vseparator;
    }
    str += values(i);
  }
  return(str);
}

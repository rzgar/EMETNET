#ifndef ESTRHASHOF_H
#define ESTRHASHOF_H

#include "eutils.h"

#include "ehashmap_dec.h"
#include "ebasichashmap_dec.h"
#include "evar_dec.h"

unsigned int estr_oaat_hash(const estr& str);
unsigned int estr_lookup3_hash(const estr& str);
unsigned int estr_sf_hash(const estr& str);

template <class T>
class estrhashof : public ehashmap<estr,T>
{
 public:
  estrhashof(unsigned int (*hashfunc)(const estr&)=estr_oaat_hash);

  void addvar(evar& evarkey,evar& var);
};

template <class T>
class ebasicstrhashof : public ebasichashmap<estr,T>
{
 public:
  ebasicstrhashof(unsigned int (*hashfunc)(const estr&)=estr_lookup3_hash);

//  void addvar(evar& evarkey,evar& var);
};

//#include "ehashfunc.h"


template <class T>
void estrhashof<T>::addvar(evar& evarkey,evar& var)
{
  this->addref(evarkey.get<estr>(),&var.get<T>());
}

template <>
void estrhashof<evar>::addvar(evar& evarkey,evar& var);




template <class T>
estrhashof<T>::estrhashof(unsigned int (*_hashfunc)(const estr&)): ehashmap<estr,T>(_hashfunc) {}

template <class T>
ostream& operator<<(ostream& stream,const estrhashof<T>& strhash)
{
  int i;
  stream <<"{"<<endl;
  for (i=0; i<strhash.size()-1; ++i)
    stream << " "<<strhash.keys(i)<<"="<<(T&)strhash.values(i)<<","<<endl;
  if (strhash.size())
    stream << " "<<strhash.keys(i)<<"="<<(T&)strhash.values(i)<<endl;
  stream << "}"<<endl;
  return(stream);
}

template <class T>
ebasicstrhashof<T>::ebasicstrhashof(unsigned int (*_hashfunc)(const estr&)): ebasichashmap<estr,T>(_hashfunc) {}

template <class T>
ostream& operator<<(ostream& stream,const ebasicstrhashof<T>& strhash)
{
  typename ebasicstrhashof<T>::iter i;
  stream <<"{"<<endl;
  for (i=strhash.begin(); i!=strhash.end(); ++i)
    stream << " "<<i.key()<<"="<<(T&)i.value()<<","<<endl;
  stream << "}"<<endl;
  return(stream);
}



#endif

#ifndef __ETIME__
#define __ETIME__

#include "estr.h"
#include <time.h>

estr date();
int unixtime();

#endif


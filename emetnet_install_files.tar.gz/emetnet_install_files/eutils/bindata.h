#ifndef _BINDATA_
#define _BINDATA_

#include "eutils.h"
#include <stdio.h>


class ebindata
{
 private:
  double min;
  double max;
  double isize;

  int count;
  int nbins;
  int *bins;
  
  double *data;
  bool autoAdjust;
 public:
  ebindata();
  ebindata(int nbins);
  ebindata(double min, double max);
  ebindata(int nbins, double min, double max);

  void read(estr filename);
  void read(FILE *input);

  void write(estr filename);
  void write(FILE *output);


};


typedef struct S_BINDATA {
  double min;
  double max;
  double isize;
  int count;
  int nbins;
  int *bins;
} s_bindata, *t_bindata;


inline void bindata_fastadd(t_bindata bdata, double value){
  ++bdata->bins[ (int)( (value - bdata->min) * bdata->isize ) ];
}

void bindata_add(t_bindata bdata,double value);

t_bindata bindata_create(int nbins);


t_bindata logbindata_create(FILE *f);
t_bindata logbindata_create(double bin_size,FILE *f);

t_bindata bindata_create(double min,double max, int nbins);
t_bindata bindata_create(double min,double max, double bin_resolution);

t_bindata bindata_create(char *filename,int nbins=0);
t_bindata bindata_create(char *filename,double min,double max, double bin_resolution);

t_bindata bindata_create(double *values, int nvalues, double bin_resolution);
t_bindata bindata_create(double *values, int nvalues, int nbins=0);

void bindata_reset(t_bindata bdata);
void bindata_check(t_bindata bdata, double *values, int nvalues);
void logbindata_check(t_bindata bdata, double *values, int nvalues);

void bindata_add(t_bindata bdata, double *values, int nvalues);
void logbindata_add(t_bindata bdata, double *values, int nvalues);

void bindata_print(t_bindata bdata);
void bindata_printnormal(t_bindata bdata);
void logbindata_print(t_bindata bdata);

double bindata_mode(t_bindata bdata);
double logbindata_mode(t_bindata bdata);

#endif


//#include <eutils/emain.h>
#include <eutils/eparser.h>
#include <eutils/logger.h>
#include <eutils/evar.h>
#include <eutils/efile.h>
#include <eutils/esystem.h>

#include <edlib-2/edlib.h>
//#include <edlib-2/ewinarray.h>
//#include <edlib-2/ewintable.h>
//#include <edlib-2/ewinedit.h>
//#include <edlib-2/ewinplot.h>
//#include <edlib-2/ewinpopup.h>
#include <edlib-2/eimage_jpg.h>
#include <edlib-2/eimage_bmp.h>
#include <edlib-2/eimage_png.h>
#include <eutils/evarclass.h>

#include <eutils/evarclassconstructor.h>
#include <eutils/evarclasscout.h>

void register_edlib(){
  epregisterClassConstructor(esystem,());
  epregisterClassMethod(esystem,process);

/*
  epregisterClassConstructor(eimageLocal,());
  epregisterClassMethod2D(eimageLocal,draw,void,(const eimage&,int,int,int,int,int,int),"0,0,0,0,0,0");
  epregisterClassMethod2D(eimageLocal,draw,void,(const eimageLocal&,int,int,int,int,int,int),"0,0,0,0,0,0");
  epregisterClassMethod(eimageLocal,drawRotate);
  epregisterClassMethod(eimageLocal,create);
  epregisterClassMethod(eimageLocal,clear);
  epregisterClassMethod(eimageLocal,moveTo);
  epregisterClassMethod(eimageLocal,lineTo);
  epregisterClassMethod(eimageLocal,setColor);
*/

  epregisterClassConstructor(eimage,(ewindow&));
  epregisterClassMethod2D(eimage,draw,void,(const eimage&,int,int,int,int,int,int),"0,0,0,0,0,0");
//  epregisterClassMethod2D(eimage,draw,void,(const eimageLocal&,int,int,int,int,int,int),"0,0,0,0,0,0");
  epregisterClassMethod2(eimage,moveTo,void,(int,int));
  epregisterClassMethod2(eimage,lineTo,void,(int,int));
  epregisterClassMethod2(eimage,moveTo,void,(const evector2&));
  epregisterClassMethod2(eimage,lineTo,void,(const evector2&));
  epregisterClassMethod2(eimage,setColor,void,(int));
  epregisterClassMethod2(eimage,clear,void,(int));
  epregisterClassMethod2(eimage,print,void,(int,int,const estr&));
  epregisterClassMethod2D(eimage,draw,void,(const eimage&,int,int,int,int,int,int),"0,0,0,0,0,0");
//  epregisterClassMethod2D(eimage,draw,void,(const eimageLocal&,int,int,int,int,int,int),"0,0,0,0,0,0");


  epregisterClassConstructor(ewindow,());
  epregisterClassInheritance(ewindow,eimage);
  epregisterClassMethod2(ewindow,flip,void,());
  epregisterClassMethod2D(ewindow,create,void,(int,int),"640,480");
//  epregisterClassMethod2(ewindow,create,void,(ewindow&,int,int,int,int));
  epregisterClassProperty(ewindow,onMouseClick);
  epregisterClassProperty(ewindow,onMouseMove);
  epregisterClassProperty(ewindow,onKeyPress);


/*
  epregisterClassMethod2(ewindow,moveTo,void,(int,int));
  epregisterClassMethod2(ewindow,lineTo,void,(int,int));
  epregisterClassMethod2(ewindow,moveTo,void,(const evector2&));
  epregisterClassMethod2(ewindow,lineTo,void,(const evector2&));
  epregisterClassMethod2(ewindow,setColor,void,(int));
  epregisterClassMethod2(ewindow,clear,void,(int));
  epregisterClassMethod2(ewindow,print,void,(int,int,const estr&));
  epregisterClassMethod2D(ewindow,draw,void,(const eimage&,int,int,int,int,int,int),"0,0,0,0,0,0");
  epregisterClassMethod2D(ewindow,draw,void,(const eimageLocal&,int,int,int,int,int,int),"0,0,0,0,0,0");
*/

/*
  epregisterClassConstructor(ewinplot,());
  epregisterClassInheritance(ewinplot,ewindow);
  epregisterClassInheritance(ewinplot,ebasicwindow);
  epregisterClassMethod(ewinplot,plot);
  epregisterClassMethod(ewinplot,setAutoRange);

  epregisterClassConstructor(ewinarray,());
  epregisterClassInheritance(ewinarray,ewindow);
  epregisterClassInheritance(ewinarray,ebasicwindow);
  epregisterClassProperty(ewinarray,array);

  epregisterClassConstructor(ewintable,());
  epregisterClassInheritance(ewintable,ewindow);
  epregisterClassInheritance(ewintable,ebasicwindow);
  epregisterClassProperty(ewintable,table);

  epregisterClassConstructor(ewinpopup,());
  epregisterClassInheritance(ewinpopup,ebasicwindow);
  epregisterClassInheritance(ewinpopup,ewindow);
  epregisterClassMethod2(ewinpopup,create,void,(ewindow&,int,int,int,int));

  epregisterClassConstructor(ewinpopupmenu,());
  epregisterClassInheritance(ewinpopupmenu,ebasicwindow);
  epregisterClassInheritance(ewinpopupmenu,ewindow);
  epregisterClassInheritance(ewinpopupmenu,ewinpopup);

  epregisterClassConstructor(ewinedit,());
  epregisterClassInheritance(ewinedit,ebasicwindow);
  epregisterClassInheritance(ewinedit,ewindow);
*/

//  epregisterClassConverterPointer(estr*,estr);
//  epregisterClassConverterObject(estr,estr*);

//  epregisterClassProperty(ewinedit,pstr);
}








/*
void sayhello(estr a)
{
  cout << " hello "<<a<<endl;
}
*/


void sayhello(int n=1)
{
  if (n<0) return;
  while (n){
    cout << " hello "<<endl;
    --n;
  }
}

eparser& getParser2()
{
  return(*getParser());
}

#define parser getParser2()
#include <eutils/earrayof.h>
#include <iostream>
using namespace std;




void changevar(int &a)
{
  a=2222;
}


estr eclass(const evar& var)
{
  return(var.getClass());
}

int main(int argvc,char *argv[])
{
  register_edlib();

  parser.init(argvc,argv);


  if (argvc==2){
    estr s;
    efile file(argv[1]);
    if (file.exists()){
      file.readln(s);
      if (s.len() && s.substr(0,2) != "#!")
        epinterpret(s);
      while (file.readln(s))
        epinterpret(s);
    }
  }

  estr *tmps;

  epregister(tmps);

  epregisterFunc(eclass);
  epregisterFunc2(sayhello,void,(int));
  epregisterFunc(epinterpret);
  epregisterFunc(epruninterpret);

  esystem *system=getSystem();
  epregister(system);

//  epregisterFunc(loadjpg);
  epregisterFunc(loadbmp);
  epregisterFunc(loadpng);

  epregisterClassConstructor(evararray,());
  epregisterClassMethod2(evararray,add,evar&,(const evar&));

  epregisterClassMethod(evar,operator==);
  epregisterClassMethod(evar,operator!=);
//  epregisterClassCout(evar);

/*
  ewindow win;
  win.create(640,480);

  ewinpopupmenu winpm;
  winpm.items.add("item1",sayhello);
  winpm.items.add("item2",sayhello);
  winpm.items.add("item3",sayhello);
  winpm.create(win);
*/

  int i;

  epruninterpret();

  return(0);
}

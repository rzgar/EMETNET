
#include <iostream>

using namespace std;

#include <eutils/estr.h>
#include <eutils/logger.h>
#include <eutils/vector2.h>
#include <eutils/earray.h>

#include <edlib-2/edlib.h>


#include "evar.h"






class myhello
{
 public:
  void helloworld();
};

void myhello::helloworld()
{
  cout << "just called myhello::helloworld() function!!!" << endl << endl;
}


int str2int(estr str)
{
  return(str.i());
}

float str2float(estr str)
{
  return(str.f());
}

int main()
{
//  logger.level=0;

  epregisterClass(evar);
  epregisterClass(int);
  epregisterClass(float);
  epregisterClass(double);

  epregisterClass(estr);
  epregisterClassMethod(estr,substr);

  epregisterClass(evararray);

  // this is necessary when there are function overloadings
  _epregisterClassMethod< evararray,evar& (evararray::*)(int) >("evararray","at",&evararray::at);
  _epregisterClassMethod< evararray,evar& (evararray::*)(int) >("evararray","operator[]",&evararray::at);
  _epregisterClassMethod< evararray,evar& (evararray::*)(const evar&)>("evararray","add",&evararray::add);

  epregisterClass(evector2);
  epregisterClassMethod(evector2,len);
  epregisterClassProperty(evector2,x);
  epregisterClassProperty(evector2,y);

  epregisterClassConverterCast2(int,char);
  epregisterClassConverterCast2(int,float);
  epregisterClassConverterCast2(int,double);
  epregisterClassConverterCast2(float,double);

  epregisterClassConverterCast(estr,int);
  epregisterClassConverter(str2int);
  epregisterClassConverter(str2float);

  epregisterClass(ewindow);
  epregisterClassMethod2(ewindow,create,void,(int,int,int,int));
  epregisterClassMethod2(ewindow,moveTo,void,(int,int));
  epregisterClassMethod2(ewindow,lineTo,void,(int,int));
  epregisterClassMethod2(ewindow,setColor,void,(int));
  epregisterClassMethod2(ewindow,flip,void,());






  evar test;

  // evar as a vector
  test = evector2(3,4);
  cout << "I can be a \""<<test.getClass()<<"\": "<< test << endl;
  cout << "test.len() = " << test.call("len") << endl;
  cout << "test.x = " << test.get("x") << endl;
  test.set("x","5");
  cout << "test.x = " << test.get("x") << endl;
  cout << "test.len() = " << test.call("len") << endl;
  cout << endl;

  // evar as an integer
  test = 2;
  cout << "I can be a \""<<test.getClass()<<"\": "<< test << endl;
  cout << endl;

  // evar as a string ( becomes estr class, so you have substr function )
  test = "hello world test";
  cout << "I can be a \""<<test.getClass()<<"\": "<< test << endl;
  cout << test.call("substr","2,-3") << endl;
  cout << endl;

  // evar as an array
  test = evararray();
  test.call("add","array element1");
  test.call("add","element2");
  cout << "I can also be an \""<<test.getClass()<<"\": "<< test << endl;


  cout << "When I am an array (or object with operator[]), you can access my items: test[0] = " << test[0] << endl;
  cout << endl;



  // registering your own class "myhello", and its "helloworld" method ...  epregisterClass(myhello);
  epregisterClass(myhello);
  epregisterClassMethod(myhello,helloworld);

//  myhello myobj;
  test = myhello();
  cout << "I can even be a class registered by you: \""<<test.getClass()<<"\""<<endl; //  we cannot use cout << test << endl; for the "myhello" class because it is not defined!
 
  // ...  and calling its "helloworld" method!
  test.call("helloworld");


  ewinsys winsys;
  test = new ewindow();
  test.call("create","100,100,300,200");
  test.call("setColor","255");
  test.call("moveTo","20,20");
  test.call("lineTo","100,30");
  test.call("flip");

  winsys.run();

 
  return(0);
}










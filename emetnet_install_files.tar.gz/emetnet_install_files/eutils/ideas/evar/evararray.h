#ifndef __EVARARRAY__
#define __EVARARRAY__

#include <eutils/earray.h>

class evar;

typedef earray<evar> evararray;

#endif


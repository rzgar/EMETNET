#ifndef __EVAR__
#define __EVAR__

#include "evarbase.h"

class evar;
typedef const evar& evarRef;

class evar
{
 public:
  evarBase* var;

  evar();

  evar(const evar& value);

  template <class T>
  evar(const T& value);
  template <class T>
  evar(T* value);
  evar(const char* value);

  ~evar();

  void clearVar();


  template <class T>
  T* get();

//  evar* get();
  const evar* get();

  template <class T>
  T* convert();

  template <class T>
  evar& operator=(T* value);
  template <class T>
  evar& operator=(const T& value);
  evar& operator=(const char* value);

  evar  operator[](int i);

  evar get(const estr& property) const;
  void set(const estr& property,evar value);
  evar call(const estr& method,evararray& args);
  evar call(const estr& method,const estr& args="");

  estr getClass();
};

#include "evarclass.h"
#include "evartype.h"
#include "evarclassconverter.h"

#include <eutils/estrarray.h>


estr evar::getClass()
{
  if (!var) return("empty");
  return(var->getClassName());
}

template <class T>
T* evar::get()
{
  if (!var) return(0x00);

  if (var->getClassId() == epclass<T>::id)
    return( ((evarType<T>*)var)->get() );

  linfo("convertion needed, object type: "+var->getClassName()+"("+estr(var->getClassId())+") to type: "+epclass<T>::name+"("+estr(epclass<T>::id)+")");

  return( convert<T>() );
}

/*
template <>
evar* evar::get()
{
  return(new evar(*this));
}
*/

template <>
const evar* evar::get()
{
  return(new evar(*this));
}



template <class T>
T* evar::convert()
{
  if (classConverters.findkey(epclass<T>::id)!=-1 && classConverters[epclass<T>::id].findkey(var->getClassId())!=-1)
    return( classConverters[epclass<T>::id][var->getClassId()]->convert(*this).get<T>() );

  lwarn("no class converter found! "+var->getClassName()+"("+estr(var->getClassId())+") to "+epclass<T>::name+"("+estr(epclass<T>::id)+")");

  return((T*)0x00);
}







void splitArgs(evararray &arr,const estr& args)
{
  estrarray strarr = args.explode(",");
  int i;
  for (i=0; i<strarr.size(); ++i)
    arr.add(strarr[i]);
}

evar evar::call(const estr& method,const estr& args)
{
  evararray arr;
  splitArgs(arr,args); 
  return(var->call(method,arr));
}

evar evar::call(const estr& method,evararray& args)
{
  return(var->call(method,args));
}

evar evar::get(const estr& property) const
{
  return(var->get(property));
}

void evar::set(const estr& property,evar value)
{
  var->set(property,value);
}


evar evar::operator[](int i)
{
  evararray arr;
  arr.add(i);
  return(var->call("operator[]",arr));
}

evar::evar(): var(0x00) {}

evar::evar(const evar& value): var(0x00)
{
  if (value.var){
    var = value.var->copy();
    ++var->pcount;
  }
}

template <class T>
evar::evar(T* value)
{
  var = new evarType<T>(*value);
  ++var->pcount;
}

template <class T>
evar::evar(const T& value)
{
  var = new evarType<T>(*new T(value));
  ++var->pcount;
}

evar::evar(const char* value)
{
  var = new evarType<estr>(*new estr(value));
  ++var->pcount;
}

evar::~evar()
{
  clearVar();
}

void evar::clearVar()
{
  if (var){
    --var->pcount;
    if (!var->pcount)
      delete var;
    var=0x00;
  }
}

template <class T>
evar& evar::operator=(T* value)
{
  var = new evarType<T>(*value);
  ++var->pcount;
}

template <class T>
evar& evar::operator=(const T& value)
{
  clearVar();
  var = new evarType<T>(*new T(value));
  ++var->pcount;
}

evar& evar::operator=(const char* value)
{
  clearVar();
  var = new evarType<estr>(*new estr(value));
  ++var->pcount;
}


ostream& operator<<(ostream& stream,const evar& variable)
{
  if (!variable.var) return(stream);
  return(variable.var->outstream(stream));
}

#endif


#ifndef __EPCLASSCONVERTER__
#define __EPCLASSCONVERTER__

//#include "evartype.h"

#include "evarbase.h"
#include "evarclass.h"

class epclassConverterBase
{
 public:
  virtual evar convert(evar& obj)=0;
};

earrayof<earrayof<epclassConverterBase*,int>,int> classConverters;

///////////////////////////////////////////////////////////////////////////////
//
//  Class Converters
//
template <class T1,class T2>
class epclassConverterCast : public epclassConverterBase
{
 public:
  evar convert(evar& obj);
};

template <class T1,class T2>
evar epclassConverterCast<T1,T2>::convert(evar& obj)
{
  T1* resobj;
  resobj=new T1( (T1)*obj.get<T2>() );
  return(*resobj);
}

template <class T1,class T2>
class epclassConverterUserFunc : public epclassConverterBase
{
 public:
  T1 (*userFunc)(T2);
  evar convert(evar& obj);
  epclassConverterUserFunc(T1 (*userFunc)(T2));
};

template <class T1,class T2>
epclassConverterUserFunc<T1,T2>::epclassConverterUserFunc(T1 (*_userFunc)(T2)): userFunc(_userFunc) {}

template <class T1,class T2>
evar epclassConverterUserFunc<T1,T2>::convert(evar& obj)
{
  T1* resobj;
  resobj=new T1( userFunc( *obj.get<T2>() ) );
  return(*resobj);
}

/*
template <class T1,class T2>
class epclassConverterMethod : public epclassConverterBase
{
 public:
  earray<evar> args;
  estr methodname;
  evar convert(evarBase *obj);
};

template <class T1,class T2>
evar epclassConverterMethod<T1,T2>::convert(evarBase *obj)
{
  return( obj->call(methodname,args) );
}
*/


#define epregisterClassConverter(a)  _epregisterClassConverter(a)

//TODO: Write class converter wrapper functions to call user defined converter functions!
// it is possible to also define class methods as converter functions, in a very elegant fashion!!

template <class T1,class T2>
void _epregisterClassConverter(T1 (*pconvfunc)(T2))
{
  epclassAssignId<T1>();
  epclassAssignId<T2>();
  if (classConverters.findkey(epclass<T1>::id)==-1)
    classConverters.add(epclass<T1>::id,earrayof<epclassConverterBase*,int>());
//  classConverters[epclass<T1>::id].add(epclass<T2>::id,epclassConvert<T1,T2>); 
  classConverters[epclass<T1>::id].add(epclass<T2>::id, new epclassConverterUserFunc<T1,T2>(pconvfunc)); 
}


#define epregisterClassConverterCast(a,b)  _epregisterClassConverterCast<a,b>()
#define epregisterClassConverterCast2(a,b)  { _epregisterClassConverterCast<a,b>(); _epregisterClassConverterCast<b,a>(); }

template <class T1,class T2>
void _epregisterClassConverterCast()
{
  epclassAssignId<T1>();
  epclassAssignId<T2>();
  if (classConverters.findkey(epclass<T1>::id)==-1)
    classConverters.add(epclass<T1>::id,earrayof<epclassConverterBase*,int>());
//  classConverters[epclass<T1>::id].add(epclass<T2>::id,epclassConvert<T1,T2>); 
  classConverters[epclass<T1>::id].add(epclass<T2>::id,new epclassConverterCast<T1,T2>()); 
}



#endif


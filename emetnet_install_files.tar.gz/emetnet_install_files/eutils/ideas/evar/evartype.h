#ifndef __EVARTYPE__
#define __EVARTYPE__

#include "evarbase.h"

///////////////////////////////////////////////////////////////////////////////
//
//  Objects
//

template <class T>
class evarType : public evarBase
{
 public:
  T* object;
  evarType(T& object);
  ~evarType();

  inline int  getClassId()   { return(epclass<T>::id);   }
  inline estr getClassName() { return(epclass<T>::name); }
  inline T*   get()    { return(object);  }

  inline evarBase* copy() { return( new evarType<T>(*new T(*object))); }

  evar call(const estr& methodname,evararray& args);
  evar get(const estr& propertyname);
  void set(const estr& propertyname,evar& value);

  ostream& outstream(ostream& stream);
};

#include "evar.h"
#include "evarclass.h"
#include "evararray.h"

template <class T>
evarType<T>::evarType(T& _object): object(&_object) {}

template <class T>
evarType<T>::~evarType() {}

template <class T>
ostream& evarType<T>::outstream(ostream& stream)
{ return(stream << *get()); }

template <class T>
evar evarType<T>::call(const estr& methodname,evararray& args)
{
  if (epclass<T>::methods.findkey(methodname) != -1)
    return(epclass<T>::methods[methodname]->call(get(),args));
  lwarn("method "+methodname+" not found in class: "+getClassName());
  return(evar());
}

template <class T>
evar evarType<T>::get(const estr& propertyname)
{
  if (epclass<T>::properties.findkey(propertyname) != -1)
    return(epclass<T>::properties[propertyname]->get(get()));
  lwarn("get(): property "+propertyname+" not found in class: "+getClassName());
  return(evar());
}

template <class T>
void evarType<T>::set(const estr& propertyname,evar& value)
{
  if (epclass<T>::properties.findkey(propertyname) != -1)
    { epclass<T>::properties[propertyname]->set(get(),value); return; }
  lwarn("set(): property "+propertyname+" not found in class: "+getClassName());
  return;
}


#endif


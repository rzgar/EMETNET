#include "ethread.h"





// Find out number of processors: sysconf(_SC_NPROCESSORS_ONLN); 



emutex::emutex()
{
  pthread_mutex_init(&_mutex,NULL);
}

emutex::~emutex()
{
  pthread_mutex_destroy(&_mutex);
}

void emutex::lock()
{
  pthread_mutex_lock(&_mutex);
}

void emutex::unlock()
{
  pthread_mutex_unlock(&_mutex);
}

bool emutex::trylock()
{
  if (pthread_mutex_trylock(&_mutex)==0) return(true);
  return(false);
}

/*
class econdsig
{
 public:
  econdsig();
  ~econdsig();

  bool wait();
  bool signal();
 private:
  _pthread_cond_t _condsig;
};
*/

ethread::ethread(): active(true), _isbusy(false)
{
//  pthread_mutex_init(&_busymutex,NULL);
  pthread_mutex_init(&_waitmutex,NULL);
//  pthread_mutex_lock(&_waitmutex); // should not lock mutexes in different threads
  pthread_cond_init(&_waitcond,NULL);
  pthread_create(&_pthread,NULL,ethread::entrypoint, this);
//  linfo("ethread() finished");
}

ethread::~ethread()
{
//  pthread_mutex_destroy(&_busymutex);
  pthread_mutex_destroy(&_waitmutex);
  pthread_cond_destroy(&_waitcond);
}

/*
int ethread::create(const efunc& func)
{
  _func=func;
  return(code);
}
*/

bool ethread::run(const efunc& func,const evararray& args)
{
//  linfo("ethread::run");
//  if (pthread_mutex_trylock(&_waitmutex)!=0) return(false);
  ldie("TODO: fix ethread code, problem was in how to wait for thread to start before running code");
  // NOTE: additinally the wait code should use condition signals
  

  _func=func;
  _args=args;
  _isbusy=true;
//  linfo("run: cond_signal and unlock");
  pthread_cond_signal(&_waitcond);
  pthread_mutex_unlock(&_waitmutex);
  return(true);
}

int ethread::_runJob()
{
  result.set(_func.call(_args));
}

int ethread::_runThread()
{
  pthread_mutex_lock(&_waitmutex); // should not lock mutexes in different threads than they will be unlocked
  do {
//    linfo("runThread: mutex_lock and cond_wait");
    _isbusy=false;
    pthread_cond_wait(&_waitcond,&_waitmutex);
//    linfo("runThread: running");
    _isbusy=true;
    _runJob();
  } while(active);
  pthread_mutex_unlock(&_waitmutex);
//  linfo("runThread: thread finishing");
  return(0);
}

bool ethread::isBusy()
{
  if (pthread_mutex_trylock(&_waitmutex)==0){
    pthread_mutex_unlock(&_waitmutex);
    return(false);
  }
  return(true);
}

void ethread::wait()
{
  pthread_mutex_lock(&_waitmutex);
  while(_isbusy) {
    pthread_mutex_unlock(&_waitmutex);
    pthread_mutex_lock(&_waitmutex);
  }
  pthread_mutex_unlock(&_waitmutex);
}

void *ethread::entrypoint(void *pthis)
{
 static_cast<ethread*>(pthis)->_runThread();
 return(0x00);
}



etaskthread::etaskthread(etaskman& _taskman): active(true), _isBusy(true), taskman(_taskman)
{
//  pthread_mutex_init(&_busymutex,NULL);
  pthread_mutex_init(&_waitmutex,NULL);
  pthread_cond_init(&_waitcond,NULL);
  pthread_create(&_pthread,NULL,etaskthread::entrypoint, this);
//  linfo("etaskthread() finished");
}

etaskthread::~etaskthread()
{
//  pthread_mutex_destroy(&_busymutex);
  pthread_mutex_destroy(&_waitmutex);
  pthread_cond_destroy(&_waitcond);
}

bool etaskthread::wake()
{
//  linfo("etaskthread::run");
  ldinfo("waking thread");
  if (pthread_mutex_trylock(&_waitmutex)!=0) { ldinfo("thread not in wait state"); return(false); }

  ldinfo("thread is in wait state");
  _isBusy=true;
//  linfo("run: cond_signal and unlock");
  pthread_cond_signal(&_waitcond);
  pthread_mutex_unlock(&_waitmutex);
  return(true);
}

int etaskthread::_runJob(etask& task)
{
  ldinfo("running task");
  task.result.set(task.func.call(task.args));
  task.setDone();
  taskman.onTaskDone.call(evararray(taskman,task));
}

int etaskthread::_runThread()
{
  pthread_mutex_lock(&_waitmutex);
  do {
//    linfo("runThread: mutex_lock and cond_wait");
   
    // try to get a task from the taskmanager
    etask *ptask=taskman.getTask(*this);

    if (ptask) // if there is a task, run it
      _runJob(*ptask);
    else // if no task is available block and wait for tasks to be added
      pthread_cond_wait(&_waitcond,&_waitmutex);

//    linfo("runThread: running");
  } while(active);
  pthread_mutex_unlock(&_waitmutex);
//  linfo("runThread: thread finishing");
  return(0);
}

/*
bool etaskthread::isBusy()
{
  if (pthread_mutex_trylock(&_waitmutex)==0){
    pthread_mutex_unlock(&_waitmutex);
    return(false);
  }
  return(true);
}
*/

void *etaskthread::entrypoint(void *pthis)
{
 static_cast<etaskthread*>(pthis)->_runThread();
 return(0x00);
}






etask::etask(const efunc& _func,const evararray& _args): status(0),func(_func),args(_args) {}


etaskman::etaskman(): runningThreads(0), pendingTasks(0) 
{
  pthread_mutex_init(&_waitmutex,NULL);
  pthread_cond_init(&_waitcond,NULL);
}

etaskman::~etaskman()
{
  pthread_mutex_destroy(&_waitmutex);
  pthread_cond_destroy(&_waitcond);
}

void etaskman::createThread(int n)
{
  runThreadsMutex.lock();
  int i;
  for (i=0; i<n; ++i){
    threads.addref(new etaskthread(*this));
    ++runningThreads;
  }
  runThreadsMutex.unlock();
}

etask& etaskman::addTask(const efunc& func,const evararray& args)
{
  runThreadsMutex.lock();
  etask &task(tasks.add(etask(func,args)));
  ++pendingTasks;

  while (runningThreads<pendingTasks && runningThreads<threads.size()){
    int i;
    for (i=0; i<threads.size(); ++i){
      if (!threads[i].isBusy() && threads[i].wake()){
        ++runningThreads;
        break;
      }
    }
  }
  runThreadsMutex.unlock();
  return(task);
}

etask* etaskman::getTask(etaskthread& thread)
{
  do {
    runThreadsMutex.lock();
    if (pendingTasks>0){
      int i;
      for (i=0; i<tasks.size(); ++i){
        if (tasks[i].isPending()){
          tasks[i].setRunning();
          --pendingTasks;
          runThreadsMutex.unlock();
          return(&tasks[i]);
        }
      }
    }
    if (runningThreads==1){
      runThreadsMutex.unlock();
      onAllDone.call(evararray(*this));
      runThreadsMutex.lock();
    }
  }while(pendingTasks>0);

  --runningThreads;
  thread.setFree();

  if (runningThreads==0){
    pthread_cond_signal(&_waitcond);
    pthread_mutex_unlock(&_waitmutex);
  }

  runThreadsMutex.unlock();
  return(0x00);
}

void etaskman::wait()
{
  pthread_mutex_lock(&_waitmutex);
  pthread_cond_wait(&_waitcond,&_waitmutex);
  pthread_mutex_unlock(&_waitmutex);
}




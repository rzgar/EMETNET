#ifndef __ESYSTEM_LINUX__
#define __ESYSTEM_LINUX__

#include "eutils-config.h"

#include "earray.h"
#include "efunc.h"

class esystem
{
 public:
  earray<int> fds;
  earray<efunc> funcs;
  ebasicarray<evar> datas;

  static esystem *cursystem;

//  bool processMessages();
//  bool processMessagesWait();
  void run();

  inline void addSocket(int fd,const efunc& func,const evar& data=evar()) { add(fd,func,data); }
  inline void removeSocket(int fd) { remove(fd); }

  void add(int fd,const efunc& func,const evar& data=evar());

  void addfunc(int fd,efunc *func);

  void remove(int fd);
  void wait(int fd=-1);  
};

//extern esystem fdwatch;

esystem *getSystem();

#endif


#include "ehashmap.h"


template <>
void ehashmap<evar,evar>::addvar(evar& key,evar& var)
{
  add(key,var);
}

template <>
evar ehashmap<evar,evar>::getvar(int i) const
{
  return(values(i));
}

template <>
evar ehashmap<evar,evar>::getvarkey(int i) const
{
  return(keys(i));
}

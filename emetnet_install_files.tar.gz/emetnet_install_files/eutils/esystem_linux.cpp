#include "esystem_linux.h"

#include <stdio.h>

esystem *esystem::cursystem=0x00;

esystem *getSystem()
{
  if (!esystem::cursystem)
    esystem::cursystem=new esystem;
  return(esystem::cursystem);
}

void esystem::add(int fd,const efunc& func,const evar& data)
{
  fds.add(fd);
  funcs.addref(new efunc(func));
  datas.add(data);
}

void esystem::addfunc(int fd,efunc *func)
{
  fds.add(fd);
  funcs.addref(func);
  datas.add(evar());
}

void esystem::remove(int fd)
{
  int i;
  i=fds.find(fd);
  lerrorifr(i==-1,"file descriptor not found",);

  fds.erase(i);
  funcs.erase(i);
  datas.erase(i);
}

void esystem::run()
{
  while (1) wait();
}

void esystem::wait(int fd)
{
//  struct timeval tv;
  fd_set rd;
  int i;
  int fdmax;

  do{
    ldinfo("waiting on fds: "+estr(fds.size())+" fd: "+estr(fd));
    FD_ZERO(&rd);
    if (fds.size())
      fdmax=fds[0];
    for (i=0; i<fds.size(); ++i){
      FD_SET(fds[i],&rd);
      if (fds[i]>fdmax) fdmax=fds[i];
    }

    if (fd!=-1){
      FD_SET(fd,&rd);
      if (!fds.size() || fd > fdmax) fdmax=fd;
    }

    int res;
    res=select(fdmax+1,&rd,NULL,NULL,NULL);

    lerrorif(res<0,"error in select");

    for (i=0; i<fds.size(); ++i){
      if (FD_ISSET(fds[i],&rd)){
        evararray arr;
        if (!datas[i].isNull())
          arr.add(datas[i]);
        funcs[i].call(arr);
      }
    }
  } while (fds.size() && fd!=-1 && !FD_ISSET(fd,&rd));
}

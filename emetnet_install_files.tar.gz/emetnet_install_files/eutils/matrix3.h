#ifndef __EMATRIX3__
#define __EMATRIX3__

#include "eutils.h"

#include "vector3.h"

class ematrix3
{
 public:
  float x[9];
  ematrix3();
  ematrix3(float x0,float x1,float x2,float x3,float x4,float x5,float x6,float x7,float x8);

  ~ematrix3();
  
  float det();
  
  ematrix3 unit();
  
  ematrix3 operator*(float f);
  ematrix3 operator/(float f);

  evector3 operator*(evector3 v);
  
  ematrix3 operator*(ematrix3 m);
  ematrix3 operator+(ematrix3 m);
  ematrix3 operator-(ematrix3 m);
  
  ematrix3 operator=(ematrix3 m);  
  
};

ematrix3 mEuler(float phi, float psi, float teta);

ematrix3 mRotX(float ang);
ematrix3 mRotY(float ang);
ematrix3 mRotZ(float ang);
ematrix3 mRot(float ang, evector3 vec);
  

#endif


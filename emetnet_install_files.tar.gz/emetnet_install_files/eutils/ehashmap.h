#ifndef EHASHMAP_H
#define EHASHMAP_H

#include "eutils.h"

#include "ehashmap_dec.h"
#include "evar_dec.h"




template <class K,class T>
void ehashmap<K,T>::addvar(evar& evarkey,evar& var)
{
  addref(evarkey.get<K>(),&var.get<T>());
}
template <class K,class T>
evar ehashmap<K,T>::getvar(int i) const
{
  return(evar((T*)&values(i)));
}
template <class K,class T>
evar ehashmap<K,T>::getvarkey(int i) const
{
  return(evar((K*)&keys(i)));
}


#include "logger.h"

template <class K,class T>
ehashitem<K,T>::ehashitem(const K& _key,T* _value,ehashitem<K,T>* _next):key(_key),value(_value),next(_next),prev(0x00)
{
  if (next)
    next->prev=this;
}

template <class K,class T>
ehashitem<K,T>::~ehashitem()
{
/*
  if (next)
    next->prev=prev;
  if (prev)
    prev->next=next;
*/
}

const unsigned int HASH_INIT_MASK=0xFF;

template <class K,class T>
ehashmap<K,T>::ehashmap(unsigned int (*_hashfunc)(const K&)): hashfunc(_hashfunc)
{
  _hashmask = HASH_INIT_MASK;
  _hashitems=new ehashitem<K,T>*[_hashmask+1];
  unsigned int i;
  for (i=0; i<_hashmask+1; ++i)
    _hashitems[i]=0x00;
}

template <class K,class T>
ehashmap<K,T>::~ehashmap()
{
  clear();
  delete _hashitems;
}

template <class K,class T>
void ehashmap<K,T>::reserve(unsigned int i)
{
  _keys.reserve(i);
  
  unsigned int a;
  a=0x01;
  while (i>0){
    i=i>>1;a=(a<<1)|0x01;
  }
  
  resizehash(a);
}

template <class K,class T>
void ehashmap<K,T>::resizehash(unsigned int newmask) const
{
  unsigned int thashmask;
  ehashitem<K,T> **thashitems;

  ldinfo("resizing hash table");

  if (newmask==0 && newmask < _hashmask) 
    thashmask = (_hashmask << 1)|0x01;
  else
    thashmask = newmask;

  thashitems=new ehashitem<K,T>*[thashmask+1];
  unsigned int i;
  for (i=0; i<thashmask+1; ++i)
    thashitems[i]=0x00;

  unsigned int khash;
  ehashitem<K,T>* hitem;

  for (i=0; i<_keys.size(); ++i){
    khash = hashfunc(_keys.at(i)) & thashmask;
    hitem = gethashitem(khash & _hashmask,_keys.at(i));

    if (hitem->prev)
      hitem->prev->next=hitem->next;
    else
      _hashitems[khash&_hashmask]=hitem->next;
    if (hitem->next)
      hitem->next->prev=hitem->prev;

    hitem->prev=0x00;
    hitem->next=thashitems[khash];
    thashitems[khash]=hitem;
    if (hitem->next)
      hitem->next->prev=hitem;
  } 

  delete _hashitems;
  _hashmask=thashmask;
  _hashitems=thashitems;
  ldinfo("finished resize");
}

template <class K,class T>
ehashitem<K,T>* ehashmap<K,T>::gethashitem(unsigned int khash,const K& key) const
{
  ehashitem<K,T>* hitem;
  hitem = _hashitems[khash];
  while (hitem != 0x00){
    if (hitem->key == key)
      return(hitem);
    hitem=hitem->next;
  }
  lderror("ehashmap: did not find key");
  return(0x00); 
}


template <class K,class T>
void ehashmap<K,T>::clear()
{
  int i;
  ehashitem<K,T> *hitem;
  for (i=0; i<_hashmask+1; ++i){
    if (_hashitems[i]){
      hitem=_hashitems[i];
      _hashitems[i]=hitem->next;
      delete hitem->value;
      delete hitem;
    }
  }
  _keys.clear();
    
/*
  while (_keys.size()){
    i=hash(_keys.at(0));
    if (_hashitems[i]){
      hitem=_hashitems[i];
      _hashitems[i]=hitem->next;
      delete hitem->value;
      delete hitem;
    }
    _keys.erase(0);
  }
*/
}

template <class K,class T>
bool ehashmap<K,T>::exists(const K& key) const
{
  int i;
  ehashitem<K,T>* hitem;

  i=hash(key);
  hitem=_hashitems[i];

  while (hitem!=0x00){
    if (key == hitem->key)
      return(true);
    hitem=hitem->next;
  }
  // non existent value
  return(false);
}

template <class K,class T>
void ehashmap<K,T>::erase(const K& key)
{
  int i;
  ehashitem<K,T>* hitem;

  i=hash(key);
  hitem=_hashitems[i];

  int j;
  while (hitem!=0x00){
    if (key == hitem->key){
      j=_keys.find(key);
      if (j!=-1) _keys.erase(j);
      if (hitem->prev) hitem->prev->next=hitem->next;
      else _hashitems[i]=hitem->next;
      if (hitem->next) hitem->next->prev=hitem->prev;
      delete hitem->value;
      delete hitem;
      return;
    }
    hitem=hitem->next;
  }
  lddie("tried to delete key from hashmap that does not exist");
  // non existent value
}

template <class K,class T>
void ehashmap<K,T>::erase(int i)
{
  erase(_keys.at(i));
}

template <class K,class T>
int ehashmap<K,T>::findkey(const K& key,int pos) const
{
  return(_keys.find(key,pos));
}

template <class K,class T>
ehashmap<K,T>& ehashmap<K,T>::operator+=(const ehashmap<K,T>& hm)
{
  int i;
  for (i=0; i<hm.size(); ++i)
    add(hm.keys(i),hm.values(hm.keys(i)));
  return(*this);
}


template <class K,class T>
T& ehashmap<K,T>::addref(const K& key,T* value)
{
  int i;
  ehashitem<K,T>* hitem;

  if (_keys.size() > (3u*(_hashmask+1))>>2u) resizehash();

  i=hash(key);
  hitem=_hashitems[i];

  while (hitem!=0x00){
    if (key == hitem->key){   // there is no collision
      hitem->value = value;
      return(*hitem->value);
    }
    hitem=hitem->next;
  }

  // non existent value
  _keys.add(key);
  _hashitems[i]=new ehashitem<K,T>(key,value,_hashitems[i]);
  return(*_hashitems[i]->value);
}

template <class K,class T>
T& ehashmap<K,T>::add(const K& key,const T& value)
{
  int i;
  ehashitem<K,T>* hitem;

  if (_keys.size() > (3u*(_hashmask+1))>>2u) resizehash();

  i=hash(key);
  hitem=_hashitems[i];

  while (hitem!=0x00){
    if (key == hitem->key){   // there is no collision
      hitem->value=new T(value);
      return(*hitem->value);
    }
    hitem=hitem->next;
  }

  // non existent value
  _keys.add(key);
  _hashitems[i]=new ehashitem<K,T>(key,new T(value),_hashitems[i]);
  return(*_hashitems[i]->value);
/*
  operator[](key) = value;
  return(operator[](key));
*/
}

template <class K,class T>
const T& ehashmap<K,T>::operator[](const K& key) const
{
  int i;
  ehashitem<K,T>* hitem;

  if (_keys.size() > (3u*(_hashmask+1))>>2u) resizehash();

  i=hash(key);
  hitem=_hashitems[i];

  while (hitem!=0x00){
    if (key == hitem->key)   // there is no collision
      return(*hitem->value);
    hitem=hitem->next;
  }

  // non existent value
  _keys.add(key);
  _hashitems[i]=new ehashitem<K,T>(key,new T,_hashitems[i]);
  return(*_hashitems[i]->value);
}

template <class K,class T>
const T& ehashmap<K,T>::operator[](int ind) const
{
  int i;
  ehashitem<K,T>* hitem;

  lddieif(ind > _keys.size(),"ehashmap: index out of bounds");
  i=hash(_keys.at(ind));
  hitem=_hashitems[i];

  while (hitem!=0x00){
    if (_keys.at(ind) == hitem->key)   // there is no collision
      return(*hitem->value);
    hitem=hitem->next;
  }

  ldie("ehashmap: index out of bounds: "+estr(ind));
//  return(*(T*)0x00);
}

template <class K,class T>
T& ehashmap<K,T>::operator[](const K& key)
{
  int i;
  ehashitem<K,T>* hitem;

  if (_keys.size() > (3u*(_hashmask+1))>>2u) resizehash();

  i=hash(key);
  hitem=_hashitems[i];

  while (hitem!=0x00){
    if (key == hitem->key)   // there is no collision
      return(*hitem->value);
    hitem=hitem->next;
  }

//  lerror("key not found");
//  throw "key not found";

  // non existent value
  _keys.add(key);
  _hashitems[i]=new ehashitem<K,T>(key,new T,_hashitems[i]);
  return(*_hashitems[i]->value);
}

//#pragma GCC diagnostic ignored "-Wreturn-type"
template <class K,class T>
const T& ehashmap<K,T>::values(const K& key) const
{
  int i;
  ehashitem<K,T>* hitem;

  if (_keys.size() > (3u*(_hashmask+1))>>2u) resizehash();

  i=hash(key);
  hitem=_hashitems[i];

  while (hitem!=0x00){
    if (key == hitem->key)   // there is no collision
      return(*hitem->value);
    hitem=hitem->next;
  }

  lerror("ehashmap: key not found");
  throw "ehashmap: key not found";
//  return(*(T*)0x00);
}

template <class K,class T>
T& ehashmap<K,T>::values(const K& key)
{
  int i;
  ehashitem<K,T>* hitem;

  if (_keys.size() > (3u*(_hashmask+1))>>2u) resizehash();

  i=hash(key);
  hitem=_hashitems[i];

  while (hitem!=0x00){
    if (key == hitem->key)   // there is no collision
      return(*hitem->value);
    hitem=hitem->next;
  }

  lerror("ehashmap: key not found");
  throw "ehashmap: key not found";
//  return(*(T*)0x00);
}

template <class K,class T>
T& ehashmap<K,T>::operator[](int ind)
{
  int i;
  ehashitem<K,T>* hitem;

  i=hash(_keys.at(ind));
  hitem=_hashitems[i];

  while (hitem!=0x00){
    if (_keys.at(ind) == hitem->key)   // there is no collision
      return(*hitem->value);
    hitem=hitem->next;
  }

  ldie("ehashmap: index out of bounds: "+estr(ind));
  return(*(T*)0x00);
}
//#pragma GCC diagnostic warning "-Wreturn-type"


#endif


#ifndef _SOUND_
#define _SOUND_

#include "eutils-config.h"

#include <linux/soundcard.h>

class csound
{
 public:
  int fd;
  int frate;
  int fchannels;
  int fsize;
 
  void setRate(int rate);
  void setChannels(int channels);
  void setSize(int size);

  int read(char *buf,int buflen);
  int write(char *buf,int buflen);
 
  csound();
  ~csound();
};

class csnd_mixer
{
 public:
  int fd;
 
  void setRecordingSource(int source);
  int  getRecordingSource();
 
  csnd_mixer();
  ~csnd_mixer();
};

#endif


#include "ebasichashmap.h"


template <>
void ebasichashmap<evar,evar>::addvar(evar& key,evar& var)
{
  add(key,var);
}

template <>
evar ebasichashmap<evar,evar>::getvar(int i) const
{
  return(evar());
//  return(values(i));
}

template <>
evar ebasichashmap<evar,evar>::getvarkey(int i) const
{
  return(evar());
//  return(keys(i));
}

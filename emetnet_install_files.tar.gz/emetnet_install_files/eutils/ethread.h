#ifndef ETHREAD_H
#define ETHREAD_H

#include <pthread.h>
#include "efunc.h"

class emutex
{
 public:
  emutex();
  ~emutex();

  void lock();
  void unlock();
  bool trylock();
 private:
  pthread_mutex_t _mutex;
};

/*
class econdsig
{
 public:
  econdsig();
  ~econdsig();

  bool wait();
  bool signal();
 private:
  pthread_cond_t _condsig;
};
*/

class ethread
{
 public:
  bool active;
  evar result;

  ethread();
  ~ethread();
  bool run(const efunc& func,const evararray& args);

  void wait();
  bool isBusy();
 protected:
  static void *entrypoint(void*);
 private:
  bool _isbusy;
  efunc _func;
  evararray _args;
  pthread_t _pthread;
  pthread_mutex_t _waitmutex;
  pthread_cond_t _waitcond;

  int _runJob();
  int _runThread();
};



class etask
{
 public:
  int status;
  efunc func;
  evararray args;
  evar result;

  inline void setRunning(){ status=1; }
  inline void setDone(){ status=2; }

  inline bool isPending(){ return(status==0); }
  inline bool isRunning(){ return(status==1); }
  inline bool isDone(){ return(status==2); }
  
  etask(const efunc& func,const evararray& args);
};

class etaskman;

class etaskthread
{
 public:
  bool active;

  etaskthread(etaskman& taskman);
  ~etaskthread();
  bool wake();

  inline void setFree() { _isBusy=false; }
  inline bool isBusy() { return(_isBusy); }
 protected:
  static void *entrypoint(void*);
 private:
  etaskman& taskman;
  
  bool _isBusy;
  pthread_t _pthread;
  pthread_mutex_t _waitmutex;
  pthread_cond_t _waitcond;

  int _runJob(etask& task);
  int _runThread();
};

class etaskman
{
 public:
  emutex taskMutex;
  emutex runThreadsMutex;
  earray<etaskthread> threads;
  earray<etask>   tasks;

  int runningThreads;
  int pendingTasks;

  etaskman();
  ~etaskman();

  efunc onTaskDone;
  efunc onAllDone;

  void doAllTasksDone();

  void createThread(int n=1);
  etask& addTask(const efunc& func,const evararray& args);
  etask* getTask(etaskthread& thread);
  void wait();

 private:
  pthread_mutex_t _waitmutex;
  pthread_cond_t _waitcond;
};

#endif


#ifndef EPARSERINTERPRETER_H
#define EPARSERINTERPRETER_H

#include "eutils.h"

class evar;
class estr;

template <class T>
class estrhashof;

//void code_interpret(estrarrayof<evar*>& env,const estr& str);

evar code_interpret(estrhashof<evar>& env,const estr& str);
evar epinterpret(const estr& str);
void epruninterpret();

#endif

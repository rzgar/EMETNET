#include "efuncinfo.h"

void efuncinfo(void (*pfunc)(),efunc& func)
{
  func.fReturn = 0x00;
}



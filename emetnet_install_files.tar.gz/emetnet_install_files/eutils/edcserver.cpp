#include "edcserver.h"
#include "esystem.h"
#include "eparser.h"
#include "eparserinterpreter.h"

#include <unistd.h>

void edcclient::doRecv()
{
  estr tmpdata;
  if (0==recv(tmpdata)){ lwarn("client disconnected"); return; }
  data+=tmpdata;

  unsigned int v;
  int i;
  do {
    i=0;
    i=unserialint(v,data,i);
    if (i==-1) return;
    if (data.len()-i<v) { data.reserve(v+i); return; }

    i=unserialint(v,data,i);
    ldieif(i==-1,"not supposed to happen");

    switch (v){
      case 0:
        i=doHandleEval(data,i);
        ldieif(i==-1,"not supposed to happen");
       break;
      case 1:
        i=doHandleCall(data,i);
        ldieif(i==-1,"not supposed to happen");
       break;
      default:
        lerror("unknown command: "+estr(v));
    }
    data.del(0,i);
  } while(data.len()>0);
}

void edcclient::doClose()
{
  exit(0);
}

int edcclient::doHandleCall(const estr& evaldata,int i)
{
  estr cmd;
  i=cmd.unserial(evaldata,i);
  if (i==-1) return(-1);

  evararray args;
  i=args.unserial(evaldata,i);
  if (i==-1) return(-1);

  evar var;
  evar varfunc(epinterpret(cmd));
  if (varfunc.getTypeid()==typeid(efunc)){
    efunc func(varfunc.get<efunc>());
    var.set(func(args));
  }else{
    lerror("call is not of type efunc");
  }
//  if (getParser()->funcs.exists(cmd))
//    var.set(getParser()->funcs[cmd].at(0).call(arr));

  sendResult(var);
  return(i);
}

int edcclient::doHandleEval(const estr& evaldata,int i)
{
  estr cmd;
  i=cmd.unserial(evaldata,i);
  if (i==-1) return(-1);

  evar var(epinterpret(cmd));
  sendResult(var);
  return(i);
}

void edcclient::sendResult(const evar& var)
{
  estr sendstr;
  serialint(51,sendstr);
  var.serial(sendstr);
  estr sizestr;
  serialint(sendstr.len(),sizestr);
  send(sizestr+sendstr);
}

void edcclient::sendOutput()
{
  int len;
  estr output;
  output.reserve(1024);
  len=read(outpipe,output._str,1024);
  ldieif(len==-1,"error reading from outpipe");
  lwarnif(len==1024,"TODO: make sure to read all data from pipe");
  output._strlen=len;

  estr sendstr;
  serialint(50,sendstr);
  output.serial(sendstr);
  estr sizestr;
  serialint(sendstr.len(),sizestr);
  send(sizestr+sendstr);
}

edcserverClient::edcserverClient(edcserver* _server): isBusy(false),server(_server) {}

void edcserverClient::call(const estr& cmd,const evararray& arr)
{
  if (isBusy) { lwarn("dclient is busy"); return; }
  isBusy=true;
  estr sendstr;
  serialint(1,sendstr);
  cmd.serial(sendstr);
  arr.serial(sendstr);
  estr sizestr;
  serialint(sendstr.len(),sizestr);
  send(sizestr+sendstr);
}

void edcserverClient::eval(const estr& cmd)
{
  if (isBusy) { lwarn("dclient is busy"); return; }
  isBusy=true;
  estr sendstr;
  serialint(0,sendstr);
  cmd.serial(sendstr);
  estr sizestr;
  serialint(sendstr.len(),sizestr);
  send(sizestr+sendstr);
}

void edcserverClient::doRecv()
{
  estr tmpdata;
  if (0==recv(tmpdata)){ lwarn("client disconnected"); return; }
  data+=tmpdata;

  unsigned int v,mlen;
  int i;
  do {
    i=0;
    i=unserialint(mlen,data,i);
    if (i==-1) return;
    if (data.len()-i<mlen) { data.reserve(mlen+i); return; }
    i=unserialint(v,data,i);
    ldieif(i==-1,"not supposed to happen, mlen: "+estr(mlen));
    if (i==-1) return;
    switch(v){
      case 50:
        i=doHandleOutput(data,i);
        ldieif(i==-1,"not supposed to happen: "+estr(v)+" mlen: "+estr(mlen));
        if (i==-1) return;
       break;
      case 51:
        i=doHandleResult(data,i);
        ldieif(i==-1,"not supposed to happen: "+estr(v)+" mlen: "+estr(mlen));
        if (i==-1) return;
       break;
      default:
       lerror("unknown code: "+estr(v)+" data.len: "+data.len()+" i: "+i);
       exit(0);
    }
    data.del(0,i);
  } while (data.len());
}

int edcserverClient::doHandleOutput(const estr& msgdata,int i)
{
  estr msg;
  i=msg.unserial(msgdata,i);
  if (i==-1) return(i);

  if (server->showResult)
    cout << "[remote] " << msg << endl;
  return(i);
}

int edcserverClient::doHandleResult(const estr& resdata,int i)
{
  result.clear();
  i=result.unserial(resdata,i);
  if (i==-1) return(i);

  if (server->showResult)
    cout << "[remote] result: " << result << endl;
  isBusy=false;
  server->doReady(this);
  return(i);
}


edcserver::edcserver(): showResult(false) {}

edcserverClient& edcserver::getClient(int i)
{
  return(dynamic_cast<edcserverClient&>(sockets.at(i)));
}

void edcserver::doIncoming()
{
  edcserverClient *client=new edcserverClient(this);
  accept(*client);
  cout << "client connected" << endl;
  if (onIncoming.isSet())
    onIncoming.call(evararray(*this));
}

void edcserver::doAllReady()
{
}

void edcserver::doReady(edcserverClient *dclient)
{
  int i;
  bool allReady=true;
  for (i=0; i<sockets.size(); ++i)
    if (getClient(i).isBusy) allReady=false;
  if (allReady)
    { doAllReady(); if (onAllReady.isSet()) onAllReady.call(evararray(*this)); }
}


void registerServer()
{
  epregisterClassMethod(edcserverClient,call);
  epregisterClassMethod(edcserverClient,eval);
  epregisterClassProperty(edcserverClient,isBusy);
  epregisterClassProperty(edcserverClient,result);

  epregisterClass(edcserver);
  epregisterClassInheritance(edcserver,eserver);
  epregisterClassMethodA(edcserver,getClient,"operator[]");
  epregisterClassMethod(edcserver,getClient);
  epregisterClassProperty(edcserver,showResult);
}

void startServer(int port)
{
  edcserver* server=new edcserver;
  server->listen(port);

  registerServer();
//  epregisterClass(edcserverClient);
  epregister(server);
//  epruninterpret();
}



void startClient(const estr& host,int port)
{
  edcclient client;

  int pipefd[2];
  pipe(pipefd);
  dup2(pipefd[1],1);

  client.outpipe=pipefd[0];
  getSystem()->add(client.outpipe,efunc(client,&edcclient::sendOutput));

  client.connect(host,port);

  getSystem()->run();
}

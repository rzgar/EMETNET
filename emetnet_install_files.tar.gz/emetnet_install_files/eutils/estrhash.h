#ifndef ESTRHASH_H
#define ESTRHASH_H

#include "eutils.h"

#include "estrhashof.h"
#include "estr.h"

class estrhash : public estrhashof<estr>
{
 public:
  estr join(const estr& vdelm=";",const estr& fdelm="=");
};

#endif


#include "esystem_osx.h"

#include "ebasicarray.h"
#include "evar.h"

#include <stdio.h>
#include <MacMemory.h>

#import <Cocoa/Cocoa.h>

esystem *esystem::cursystem=0x00;

esystem *getSystem()
{
  if (!esystem::cursystem)
    esystem::cursystem=new esystem;
  return(esystem::cursystem);
}

esystem::esystem(): waiting(false),waitfd(-1)
{
  GetCurrentProcess(&PSN);
  SetFrontProcess(&PSN);
  [NSApplication sharedApplication];
}

void esystem::handleSocketCallback(CFSocketRef sref, CFSocketCallBackType callBackTypes, CFDataRef address, const void *data, void *info)
{
//  cout << "handleSocketCallback"<<endl;
  int i;
  int ifd=-1;
  esystem *psystem=(esystem*)info;
  for (i=0; i<psystem->fdrefs.size(); ++i){
//    cout << " handleSocketCallback: " << psystem->fdrefs.size() << ": " << psystem->fdrefs[i] << " == " << sref << endl;
    if (psystem->fdrefs[i]==sref){
      evararray arr;
      ifd=psystem->fds[i];
      if (psystem->funcs[i]==0x00) break;

      if (psystem->datas[i]){
        arr.add(psystem->datas[i]->var);
        psystem->funcs[i]->call(arr);
      }else
        psystem->funcs[i]->call(arr);
      break;
    }
  }
  // stops the loop from running and returns if the user called the ::wait function
  ldieif(ifd==-1,"fdref not found");
//  cout << " end handleSocketCallback: " << i << " : " <<psystem->fds.size() << " : "<<psystem->fdrefs.size() << endl;
  if (psystem->waiting){
    if (psystem->waitfd==-1 || psystem->waitfd==ifd)
      { psystem->waiting=false; CFRunLoopStop(CFRunLoopGetMain()); }
  }
}

void esystem::handleFileCallback(CFFileDescriptorRef fdref, CFOptionFlags callBackTypes, void *info)
{

  int i;
  esystem *psystem=(esystem*)info;
  for (i=0; i<psystem->fdrefs.size(); ++i){
    if (psystem->fdrefs[i]==fdref){
      evararray arr;
      if (psystem->funcs[i]==0x00) break;

      if (psystem->datas[i]){
        arr.add(psystem->datas[i]->var);
        psystem->funcs[i]->call(arr);
      }else
        psystem->funcs[i]->call(arr);

      CFFileDescriptorEnableCallBacks(fdref, kCFFileDescriptorReadCallBack);
      break;
    }
  }
  // stops the loop from running and returns if the user called the ::wait function

  linfo("got handle file callback: "+estr(i)+" fd: "+estr(psystem->fds[i])+" system: "+estr(psystem->waiting)+" sysfd: "+estr(psystem->waitfd));

  lddieif(i>=psystem->fds.size(),"i is out of bounds");
  if (psystem->waiting){
    if (psystem->waitfd==-1 || psystem->waitfd==psystem->fds[i])
      { psystem->waiting=false; CFRunLoopStop(CFRunLoopGetMain()); }
  }
}

void esystem::handleTimerCallback(CFRunLoopTimerRef tmref, void *info)
{
  int i;
  esystem *psystem=(esystem*)info;
  for (i=0; i<psystem->tmrefs.size(); ++i){
    if (psystem->tmrefs[i]==tmref){
      evararray arr;
      if (psystem->tmfuncs[i]==0x00) break;
      psystem->tmfuncs[i]->call(arr);
      break;
    }
  }
}

void esystem::addSocket(int fd,CFOptionFlags flags,efunc *func,evar *data)
{
  fds.add(fd);
  funcs.add(func);
  datas.add(data);

  CFSocketContext sContext;
  bzero(&sContext,sizeof(sContext));
  sContext.version=0;
  sContext.info=(void*)this;

/*
   kCFSocketNoCallBack = 0,
   kCFSocketReadCallBack = 1,
   kCFSocketAcceptCallBack = 2,
   kCFSocketDataCallBack = 3,
   kCFSocketConnectCallBack = 4,
   kCFSocketWriteCallBack = 8
*/

  CFSocketRef sref = CFSocketCreateWithNative(kCFAllocatorDefault,fd,flags,esystem::handleSocketCallback,&sContext);
  ldieif(sref==NULL,"sref is NULL");

  fdrefs.push_back(sref);

//  CFFileDescriptorEnableCallBacks(fdref, kCFFileDescriptorReadCallBack);
  CFRunLoopSourceRef source = CFSocketCreateRunLoopSource(kCFAllocatorDefault, sref, 0);
  CFRunLoopAddSource(CFRunLoopGetMain(), source, kCFRunLoopDefaultMode);
  fdsources.push_back(source);
}

void esystem::removeSocket(int fd)
{
  int i;
  i=fds.find(fd);
  lerrorifr(i==-1,"file descriptor not found",);

  fds.erase(i);
  CFRunLoopRemoveSource(CFRunLoopGetMain(), fdsources[i], kCFRunLoopDefaultMode);
  CFRelease(fdsources[i]);
  CFSocketInvalidate((CFSocketRef)fdrefs[i]);
  CFRelease((CFSocketRef)fdrefs[i]);
  delete funcs[i];
  fdrefs.erase(fdrefs.begin()+i);
  funcs.erase(i);
  datas.erase(i);
  fdsources.erase(fdsources.begin()+i);
}

void esystem::addtimer(const efunc& func,double secs,double repeat)
{
  tmfuncs.add(new efunc(func));

  CFRunLoopTimerContext tmContext;
  bzero(&tmContext,sizeof(tmContext));
  tmContext.version=0;
  tmContext.info=(void*)this;

  CFRunLoopTimerRef tmref = CFRunLoopTimerCreate(kCFAllocatorDefault, CFAbsoluteTimeGetCurrent()+secs, repeat , 0, 0, esystem::handleTimerCallback, &tmContext);
  ldieif(tmref==NULL,"fdref is NULL");

  tmrefs.push_back(tmref);
  CFRunLoopAddTimer(CFRunLoopGetMain(), tmref, kCFRunLoopDefaultMode);
}

void esystem::add(int fd,const efunc& func,evar *data)
{
  fds.add(fd);
  funcs.add(new efunc(func));
  datas.add(data);

  CFFileDescriptorContext fdContext;
  bzero(&fdContext,sizeof(fdContext));
  fdContext.version=0;
  fdContext.info=(void*)this;

  CFFileDescriptorRef fdref = CFFileDescriptorCreate(kCFAllocatorDefault, fd, true, esystem::handleFileCallback, &fdContext);
  ldieif(fdref==NULL,"fdref is NULL");

  fdrefs.push_back(fdref);

  CFFileDescriptorEnableCallBacks(fdref, kCFFileDescriptorReadCallBack);
  CFRunLoopSourceRef source = CFFileDescriptorCreateRunLoopSource(kCFAllocatorDefault, fdref, 0);
  CFRunLoopAddSource(CFRunLoopGetMain(), source, kCFRunLoopDefaultMode);
  fdsources.push_back(source);
//  CFRelease(source);
}

void esystem::addfunc(int fd,efunc *func)
{
  fds.add(fd);
  funcs.add(func);
  datas.add(0x00);

  CFFileDescriptorContext fdContext;
  bzero(&fdContext,sizeof(fdContext));
  fdContext.version=0;
  fdContext.info=(void*)this;

  CFFileDescriptorRef fdref = CFFileDescriptorCreate(kCFAllocatorDefault, fd, false, esystem::handleFileCallback, &fdContext);
  ldieif(fdref==NULL,"fdref is NULL");

  fdrefs.push_back(fdref);

  CFFileDescriptorEnableCallBacks(fdref, kCFFileDescriptorReadCallBack);
  CFRunLoopSourceRef source = CFFileDescriptorCreateRunLoopSource(kCFAllocatorDefault, fdref, 0);
  CFRunLoopAddSource(CFRunLoopGetMain(), source, kCFRunLoopDefaultMode);
  fdsources.push_back(source);
//  CFRelease(source);
}

void esystem::remove(int fd)
{
  int i;
  i=fds.find(fd);
  lerrorifr(i==-1,"file descriptor not found",);

  fds.erase(i);
  CFRunLoopRemoveSource(CFRunLoopGetMain(), fdsources[i], kCFRunLoopDefaultMode);
  CFRelease(fdsources[i]);

  CFFileDescriptorInvalidate((CFFileDescriptorRef)fdrefs[i]);
  CFRelease((CFFileDescriptorRef)fdrefs[i]);
  delete funcs[i];
  fdrefs.erase(fdrefs.begin()+i);
  funcs.erase(i);
  datas.erase(i);
  fdsources.erase(fdsources.begin()+i);
}

void esystem::run()
{
  [NSApp run];
/*
  EventRef theEvent;
  EventTargetRef theTarget;

  theTarget = GetEventDispatcherTarget();
  while  (ReceiveNextEvent(0, NULL,kEventDurationForever,true,&theEvent) == noErr){
    SendEventToEventTarget (theEvent, theTarget);
    ReleaseEvent(theEvent);
  }
*/
}

void esystem::process()
{
  EventRef theEvent;
  EventTargetRef theTarget;

  theTarget = GetEventDispatcherTarget();
  while ( ReceiveNextEvent(0, NULL,0,true, &theEvent) == noErr ){
    SendEventToEventTarget (theEvent, theTarget);
    ReleaseEvent(theEvent);
  }

//  return(true);
//  CFRunLoopRunInMode(kCFRunLoopDefaultMode,0,false);
}

void esystem::wait(int fd)
{
  waiting=true;
  if (fd!=-1){
    waitfd=fd;
    addfunc(fd,0x00);
    linfo("waiting: "+estr(fd)+", runnning loop");
  }

//  run();

//  RunCurrentEventLoop(kEventDurationForever);
  CFRunLoopRun();

  linfo("ended loop");

  if (fd!=-1){
    remove(fd);
    waitfd=-1;
  }
  waiting=false;
}

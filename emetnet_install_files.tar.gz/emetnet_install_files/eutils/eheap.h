#ifndef EHEAP_H
#define EHEAP_H

#include "eutils.h"

#include "earray.h"
#include "eintarray.h"

#undef check

/*
template <class T>
class eheap : public earray<T>
{
 private:
  int _size;
//  earray<T> *_arr;
//  bool internal;
//  int _size;
 public:
  eheap();
  ~eheap();
  
  void add(const T& value);
  void delroot();
  void check(int i);

  bool exists(const T& value);

//  inline T& operator[](int i){ return(_arr->operator[](i)); }
  inline T& root() { return(earray<T>::operator[](0)); }
  inline int size() { return(_size); }
};
*/

//#define SWAP(arr,i,j) { int tmpi; tmpi=arr[i]; arr[i]=arr[j]; arr[j]=tmpi; }

template <class T>
void mergesorted(const earray<T>& arr1,const earray<T>& arr2,earray<T>& res)
{
  int i=0;
  int j=0;
  res.reserve(arr1.size()+arr2.size());
  while (i<arr1.size() && j<arr2.size()){
    if (arr1[i]<arr2[j])
      { res.add(arr1[i]); ++i; }
    else
      { res.add(arr2[j]); ++j; }
  }
  while (i<arr1.size())
    { res.add(arr1[i]); ++i; }
  while (j<arr2.size())
    { res.add(arr2[j]); ++j; }
}

template <class T>
ebasicarray<T> mergesorted(const ebasicarray<T>& arr1,const ebasicarray<T>& arr2,ebasicarray<T>& res)
{
  int i=0;
  int j=0;
  res.reserve(arr1.size()+arr2.size());
  while (i<arr1.size() && j<arr2.size()){
    if (arr1[i]<arr2[j])
      { res.add(arr1[i]); ++i; }
    else
      { res.add(arr2[j]); ++j; }
  }
  while (i<arr1.size())
    { res.add(arr1[i]); ++i; }
  while (j<arr2.size())
    { res.add(arr2[j]); ++j; }
}


template <class T>
earray<T> mergesorted(const earray<T>& arr1,const earray<T>& arr2)
{
  earray<T> res;
  int i=0;
  int j=0;
  res.reserve(arr1.size()+arr2.size());
  while (i<arr1.size() && j<arr2.size()){
    if (arr1[i]<arr2[j])
      { res.add(arr1[i]); ++i; }
    else
      { res.add(arr2[j]); ++j; }
  }
  while (i<arr1.size())
    { res.add(arr1[i]); ++i; }
  while (j<arr2.size())
    { res.add(arr2[j]); ++j; }
  return(res);
}

template <class T>
ebasicarray<T> mergesorted(const ebasicarray<T>& arr1,const ebasicarray<T>& arr2)
{
  ebasicarray<T> res;
  int i=0;
  int j=0;
  res.reserve(arr1.size()+arr2.size());
  while (i<arr1.size() && j<arr2.size()){
    if (arr1[i]<arr2[j])
      { res.add(arr1[i]); ++i; }
    else
      { res.add(arr2[j]); ++j; }
  }
  while (i<arr1.size())
    { res.add(arr1[i]); ++i; }
  while (j<arr2.size())
    { res.add(arr2[j]); ++j; }
  return(res);
}

template <class T>
void heapsort(ebasicarray<T>& array)
{
  int i;
  int root,child;
  int tmpsize;

  // heapify
  tmpsize=array.size();
  for (i=array.size()/2; i>=0; --i){
    root=i;
    while (root<<1 < tmpsize){
      child=root<<1;
      if (child+1<tmpsize && array[child] < array[child+1])
        ++child;
      if (array[root] < array[child]){
        array.swap(root,child);
        root=child;
      } else
        break;
    }
  }

  // build sorted array
  for (tmpsize=array.size()-1; tmpsize>0; --tmpsize){
    array.swap(0,tmpsize);
    root=0;
    while (root<<1 < tmpsize){
      child=root<<1;
      if (child+1<tmpsize && array[child] < array[child+1])
        ++child;
      if (array[root] < array[child]){
        array.swap(root,child);
        root=child;
      } else
        break;
    }
  }
}

template <class T>
void heapsort(earray<T>& array)
{
  int i;
  int root,child;
  int tmpsize;

  tmpsize=array.size();
  for (i=array.size()/2; i>=0; --i){
    root=i;
    while (root<<1 < tmpsize){
      child=root<<1;
      if (child+1<tmpsize && array[child] < array[child+1])
        ++child;
      if (array[root] < array[child]){
        array.swap(root,child);
        root=child;
      } else
        break;
    }
  }

  for (tmpsize=array.size()-1; tmpsize>0; --tmpsize){
    array.swap(0,tmpsize);
    root=0;
    while (root<<1 < tmpsize){
      child=root<<1;
      if (child+1<tmpsize && array[child] < array[child+1])
        ++child;
      if (array[root] < array[child]){
        array.swap(root,child);
        root=child;
      } else
        break;
    }
  }
}

template <class T>
eintarray mergesort(const earray<T>& arr1,const earray<T>& arr2)
{
  eintarray res;
  int i=0;
  int j=0;
  res.reserve(arr1.size()+arr2.size());
  while (i<arr1.size() && j<arr2.size()){
    if (arr1[i]<arr2[j])
      { res.add(i); ++i; }
    else
      { res.add(arr1.size()+j); ++j; }
  }
  while (i<arr1.size())
    { res.add(i); ++i; }
  while (j<arr2.size())
    { res.add(arr1.size()+j); ++j; }
  return(res);
}

template <class T>
eintarray mergesort(const ebasicarray<T>& arr1,const ebasicarray<T>& arr2)
{
  eintarray res;
  int i=0;
  int j=0;
  res.reserve(arr1.size()+arr2.size());
  while (i<arr1.size() && j<arr2.size()){
    if (arr1[i]<arr2[j])
      { res.add(i); ++i; }
    else
      { res.add(arr1.size()+j); ++j; }
  }
  while (i<arr1.size())
    { res.add(i); ++i; }
  while (j<arr2.size())
    { res.add(arr1.size()+j); ++j; }
  return(res);
}



template <class T>
eintarray sort(const ebasicarray<T>& array)
{
  int i;
  eintarray sorti;
  for (i=0; i<array.size(); ++i)
    sorti.add(i);

  int root,child;
  int tmpsize;

  tmpsize=array.size();
  for (i=array.size()/2; i>=0; --i){
    root=i;
    while (root<<1 < tmpsize){
      child=root<<1;
      if (child+1<tmpsize && array[sorti[child]] < array[sorti[child+1]])
        ++child;
      if (array[sorti[root]] < array[sorti[child]]){
        sorti.swap(root,child);
        root=child;
      } else
        break;
    }
  }

  for (tmpsize=array.size()-1; tmpsize>0; --tmpsize){
    sorti.swap(0,tmpsize);
    root=0;
    while (root<<1 < tmpsize){
      child=root<<1;
      if (child+1<tmpsize && array[sorti[child]] < array[sorti[child+1]])
        ++child;
      if (array[sorti[root]] < array[sorti[child]]){
        sorti.swap(root,child);
        root=child;
      } else
        break;
    }
  }
  return(sorti);
}

template <class T>
eintarray sort(const earray<T>& array)
{
/*
  eheap<T> heap(array);
  int i;
  for (i=array.size()-1; i>0; --i)
    { array[i]=heap.root(); array.delroot(); }
*/
  int i;
  eintarray sorti;
  for (i=0; i<array.size(); ++i)
    sorti.add(i);

  int root,child;
  int tmpsize;

  tmpsize=array.size();
  for (i=array.size()/2; i>=0; --i){
    root=i;
    while (root<<1 < tmpsize){
      child=root<<1;
      if (child+1<tmpsize && array[sorti[child]] < array[sorti[child+1]])
        ++child;
      if (array[sorti[root]] < array[sorti[child]]){
        sorti.swap(root,child);
        root=child;
      } else
        break;
    }
    
  }

  for (tmpsize=array.size()-1; tmpsize>0; --tmpsize){
    sorti.swap(0,tmpsize);
    root=0;
    while (root<<1 < tmpsize){
      child=root<<1;
      if (child+1<tmpsize && array[sorti[child]] < array[sorti[child+1]])
        ++child;
      if (array[sorti[root]] < array[sorti[child]]){
        sorti.swap(root,child);
        root=child;
      } else
        break;
    }
  }
  return(sorti);
}



/*
template <class T>
eheap<T>::eheap(): _size(0) {} //: _size(0),_arr(new earray<T>()),internal(true) {}

template <class T>
eheap<T>::eheap(earray<T>* arr): _size(1),_arr(arr),internal(false)
{
  int i;
  for (i=1; i<_arr->size(); ++i)
    { ++_size; check(i); }
  if (!_arr->size()) _size=0;
}

template <class T>
eheap<T>::~eheap(){
//  if (internal)
//    delete _arr;
}

template <class T>
void eheap<T>::check(int i)
{
//  ++i;
  while ((i>>1)-1>=0 && earray<T>::operator[]((i>>1)-1)<earray<T>::operator[](i-1)){
    earray<T>::swap(i-1,(i>>1)-1);
    i=i>>1;
  }
}

template <class T>
bool eheap<T>::exists(const T& value)
{
  for (i=0; i<earray<T>::size(); ++i){
    if (earray<T>::operator[](i) == value) return(true);
    if (earray<T>::operator[](i) <
  }

  int i;
  i=earray<T>::size();
  while ((i>>1)-1>=0 && earray<T>::operator[]((i>>1)-1)<value){
    i=i>>1;
  }

  
  if ((i>>1)-1<0) return(false);
  return(earray<T>::operator[]((i>>1)-1)==value || earray<T>::operator[](i>>1)==value);
  return(false);
}

template <class T>
void eheap<T>::add(const T& value)
{
  if (_size==earray<T>::size())
    earray<T>::add(value);
  else
    earray<T>::operator[](_size)=value;
  ++_size;
  check(_size);
}

template <class T>
void eheap<T>::delroot()
{
  int i;

  earray<T>::operator[](0)=earray<T>::operator[](_size-1);
  i=1;
  while (1){
    if ((i<<1)-1<_size && earray<T>::operator[](i-1)<earray<T>::operator[]((i<<1)-1) && ((i<<1)>=_size || earray<T>::operator[](i<<1) < earray<T>::operator[]((i<<1)-1) )){
      earray<T>::swap(i-1,(i<<1)-1);
      i=i<<1;
    }else if ((i<<1)<_size && earray<T>::operator[](i-1)<earray<T>::operator[](i<<1)){
      earray<T>::swap(i-1,i<<1);
      i=(i<<1)+1;
    }else
      break;
  }
  --_size;
//  earray<T>::erase(earray<T>::size()-1);
}
*/

#endif


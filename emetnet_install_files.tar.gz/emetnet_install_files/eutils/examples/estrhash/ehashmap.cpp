#include <eutils/estr.h>
#include <eutils/ebasichashmap.h>
#include <eutils/estrhash.h>
#include <eutils/emain.h>
#include <stdio.h>

int emain()
{
  ebasicstrhashof<estr> hashmap;

  hashmap["teste"] = "abc";

  cout << "teste = "<<hashmap["teste"] << endl;

  cout << endl;

  hashmap["teste2"] = "cabeca";
  cout << "teste2 = "<<hashmap["teste2"] << endl;
  cout << "teste = "<<hashmap["teste"] << endl;
  cout << endl;


  cout << hashmap << endl;

  cout <<endl;

  hashmap["vinho"] = "roxo";

  cout << "vinho = "<<hashmap["vinho"] << endl;
  cout << "teste2 = "<<hashmap["teste2"] << endl;
  cout << "teste = "<<hashmap["teste"] << endl;
  cout << endl;

  hashmap["test"] = "amarelo";

  cout << "vinho = "<<hashmap["vinho"] << endl;
  cout << "teste2 = "<<hashmap["teste2"] << endl;
  cout << "teste = "<<hashmap["teste"] << endl;
  cout << "test = "<<hashmap["test"] << endl;
  cout << endl;

  hashmap["test"] = "verde";

  cout << "vinho = "<<hashmap["vinho"] << endl;
  cout << "teste2 = "<<hashmap["teste2"] << endl;
  cout << "teste = "<<hashmap["teste"] << endl;
  cout << "test = "<<hashmap["test"] << endl;
  cout << endl;

  hashmap.erase("vinho");
  cout << hashmap << endl;

  return(0);
}


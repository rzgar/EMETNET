#include <eutils/ecsv.h>


int main()
{
  ecsv csv;

  csv.load("example.csv");

  cout << csv;

  if ( csv.size() )
  	cout << csv.size() <<  (csv.size() == 1 ? " row" : " rows") << endl; 


  return(0);
}

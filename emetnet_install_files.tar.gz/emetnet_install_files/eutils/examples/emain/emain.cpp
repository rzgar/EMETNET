#include <eutils/emain.h>
#include <eutils/logger.h>


int emain()
{
  linfo("this is an info");

  lwarn("this is a warning");

  lerror("this is an error");


  int a=0;

  epregister(a);

  cout << "a="<<a<<endl;


  return(0);
}

#include <stdio.h>

#include <eutils/estrarray.h>


#define se(a) { cout << #a << endl; a; }

int main(int argvc, char *argv[])
{

  estrarray strs;

  // funciona tudo como o PHP, como seria de esperar
  se(strs["hello"] = "world");
  se(strs.add("isto","e um teste"));
  se(cout << " out: "<<strs["isto"] << endl);

  cout << endl;

  se(strs["isto"] = "e outro teste");
  se(cout << " out: "<<strs["isto"] << endl);
 
  cout << endl;

  // outra forma de adicionar 
  se(strs += "qualquer coisa");
  // tb se pode fazer o cout do array
  se(cout << " out: "<< strs << endl);


  cout << endl;

/*
{ 
"hello" = "world", 
"isto" = "e outro teste",
"qualquer coisa"
}
*/


  // a outra coisa interessante � inicializar o objecto de uma string

  se(strs = "peras,macas,laranjas,bananas");
  se(strs = estrarray("peras,macas,laranjas,bananas"));  //sao equivalentes

  se(cout << " out: "<<strs << endl);

/*
{ 
"peras", 
"macas", 
"laranjas", 
"bananas"
 }
*/


  // a outra coisa interessante � inicializar o objecto de uma string

  se(strs = "peras=verdes,macas=vermelhas,laranjas=laranja,bananas=amarelas");
   
  se(cout << " out: "<<strs << endl);

/*
{ 
"peras" = "verdes", 
"macas" = "vermelhas", 
"laranjas" = "laranja", 
"bananas" = "amarelas"
 }
*/  


  // e claro a funcao "implode" est� c� tambem:

  se(cout << " out: "<<strs.implode(",") << endl);


  // a funcao sub para selecionar apenas um certo "range"

//  cout << strs.subset(1,2) << endl; // ainda n implementei, mas j� existe no earray.h


  // subtracao de grupos
//  cout << (strs - estrarray("verdes,vermelhas")) << endl; // tb n implementei, mas existe o -= ou o - no earray.h

  // tambem existe a funcao "find" e "ffind" (fuzzy find)

  se(cout << " out: "<< strs.find("amarelas") << endl);

  se(cout << " out: "<<strs.find("ama") << endl);

 
  int i;
  for (i=0; i<strs.size(); ++i){ 
    cout << " "<<i <<" "<< strs[i] << endl;
  }



  return(0);
}


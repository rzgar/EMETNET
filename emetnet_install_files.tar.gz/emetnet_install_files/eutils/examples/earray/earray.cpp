#include <eutils/estrarray.h>
#include <stdio.h>

int main()
{
  estrarray a;

  a["hello"] = "world";
  a["heys"] = 20;

  cout << "a[\"hello\"] == " << a["hello"] << endl;
  cout << "a[\"heys\"] == " << a["heys"] << endl;

  return(0);
}

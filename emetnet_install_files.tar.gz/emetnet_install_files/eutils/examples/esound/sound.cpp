#include <csound.h>
#include <logger.h>

int main()
{
  int time = 5;
  int rate = 11000;
  int size = 8;
  int channels = 1;

  csnd_mixer mixer;
  csound sound;

  if (!(mixer.getRecordingSource() & SOUND_MIXER_MIC))
    logger(error("warning recording source not set for mic line"));

  sound.setRate(rate);
  sound.setSize(size);
  sound.setChannels(channels);

  int buflen = time * rate * channels * (size/8);
  char buffer[buflen];

  sound.read(buffer,buflen);
  sound.write(buffer,buflen);

  return(0);
}



#include <eutils/ecgi.h>

#include <eutils/efile.h>
#include <eutils/efilesys.h>

int main(int argvc,char *argv[])
{
  ecgi cgi;
  cgi.init();

  cgi << "== Arguments: " << argvc << endl;
  int i;
  for (i=0; i<argvc; ++i)
    cgi << argv[i] << endl;

  cgi << "== GET variables:"<<endl;
  cgi << cgi.GET << endl;

  cgi << "== POST variables:"<<endl;
  cgi << cgi.POST << endl;

  cgi << "== FILES variables:"<<endl;
  cgi << cgi.FILES << endl;

  cgi << "== SERVER variables:"<<endl;
  cgi << cgi.SERVER << endl;

  cgi << "== Output from http server: "<<endl;
  estr s;
  efile file(stdin);
  while (file.readln(s))
    cgi << s << endl;

  return(0);
}

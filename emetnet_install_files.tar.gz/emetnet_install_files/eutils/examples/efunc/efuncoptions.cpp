#include <eutils/efunc.h>
#include <eutils/estrhashof.h>


void helloworld()
{
  cout << "hello world" << endl;
}

void hellojoao()
{
  cout << "hello joao" << endl;
}

void hellonyone()
{
  cout << "hello nyone" << endl;
}


int main()
{
  estrhashof<efunc> funcs;

  cout << "> adding functions " << endl;
  funcs.add("world",helloworld);
  funcs.add("joao",hellojoao);
  funcs.add("nyone",hellonyone);

  cout << "> calling functions " << endl;
  funcs["world"]();
  funcs["joao"]();
  funcs["nyone"]();

  return(0);
}

#include <eutils/ehttp.h>
#include <eutils/emain.h>

int emain()
{
  ldieif(argvc<2,"syntax: ehttp <url>");

  ehttp http;
  http.get(argv[1]);

  cout << http.data << endl;

  return(0);
}

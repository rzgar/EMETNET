#include <stdio.h>

#include <eutils/estrarray.h>
#include <eutils/estr.h>

void some_function (estr str)  // podes chamar esta funcao com some_function ( "fdsfsd" ); que � um char
{
  cout << str << endl;
}


int main(int argvc, char *argv[])
{
  estr teste("isto e um teste, vamos ver se funciona");

   // ainda n arranjei maneira de transformar isto num char *, por isso acedo ao char * interno
  printf("%s\n",teste._str);

  // no entano o melhor � usar o cout << 
  cout << teste << endl;

 
/*
isto e um teste, vamos ver se funciona
"isto e um teste, vamos ver se funciona"
*/



  teste.del("teste");  // procura na str e apaga o texto 
  cout << teste << endl;

/* 
"isto e um , vamos ver se funciona"
*/




  // outras funcoes sao: substr, find, delete

  cout << teste.substr(-5) << endl;  // copia desde o length-5 at� ao fim da string
  cout << teste.substr(-5,-2) << endl;  // copia desde o length-5 at� length-2 da string
  cout << teste.substr(0,-8) << endl;  // copia desde o inicio at� length-8 da string

/*
"ciona"
"cion"
"isto e um , vamos ver se f"
*/



  // podes somar numeros e texto e char * (mas tens q ter cuidado a somar char* com int, pq ele incrementa o ponteiro em vez)

  cout << (teste+"textdsfdsf ") << endl;
  
  cout << (teste+26+estr("textdsfdsf ")) << endl;

/*
"isto e um , vamos ver se funcionatextdsfdsf "
"isto e um , vamos ver se funciona26textdsfdsf "
*/



  // a funcao find

  cout << teste.find("vamos") << endl;
  cout << teste.find("vamos",13) << endl; //procura a partir do char 13

/*
12
-1
*/


  // por fim nada como a nossa amiga funcao "explode" que faz return de um estrarray acho

  cout << teste.explode(" ") << endl;

/*
{ 
"isto", 
"e", 
"um", 
",", 
"vamos", 
"ver", 
"se", 
"funciona"
 }
*/



  estr a;
  a = 20;

  printf("a = %i\n",a.i()); // podes obter a mesma funcionalidade do scanf com esta funcao
  cout << "a = " << a << endl;

/*
a = 20
a = "20"
*/

  a += 20;
  printf("a = %i\n",a.i());
  cout << "a = " << a << endl;

/*
a = 2020
a = "2020"
*/

  a = "2.0";
  printf("a = %f\n",a.f());
  cout << "a = " << a << endl;

/*
a = 2.000000
a = "2.0"
*/

  a += "hello";
  printf("a = %f\n",a.f());
  cout << "a = " << a << endl;

/*
a = 2.000000
a = "2.0hello"
*/


  


  return(0);
}


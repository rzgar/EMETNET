#include <eutils/empint.h>
#include <eutils/emain.h>

int emain(){
  empint a,b;
  ldieif(argvc<3,"syntax: ./empint <prime1> <prime2>");

  gmp_sscanf(argv[1],"%Zx",&a.num);
  gmp_sscanf(argv[2],"%Zx",&b.num);

  empint pq=a;
  pq.multiply(b);

//  gmp_printf("%Zx\n",pq.num);

  empint r,s;
  mpz_sqrtrem(s.num,r.num,pq.num);

  empint o;
  o=s; o-=a; a=o;
  o=s; o-=b; b=o;

  empint s2;
  mpz_sqrt(s2.num,s.num);

  mpf_t tmpf2;
  mpf_init(tmpf2);
  mpf_set_z(tmpf2,s2.num);

  mpf_t tmpf;
  mpf_init(tmpf);
  mpf_set_z(tmpf,s.num);

  mpf_t x;
  mpf_init(x);
  mpf_set_z(x,a.num);
  mpf_div(x,x,tmpf);
  gmp_printf("(sqrt(p1*p2)-p1)/sqrt(p1*p2): %Fe\n",x);
  mpf_set_z(x,a.num);
  mpf_div(x,x,tmpf2);
  gmp_printf("(sqrt(p1*p2)-p1)/sqrt2(p1*p2): %Fe\n",x);

  mpf_set_z(x,b.num);
  mpf_div(x,x,tmpf);
  gmp_printf("(sqrt(p1*p2)-p2)/sqrt(p1*p2): %Fe\n",x);
  mpf_set_z(x,b.num);
  mpf_div(x,x,tmpf2);
  gmp_printf("(sqrt(p1*p2)-p2)/sqrt2(p1*p2): %Fe\n",x);


  s.multiply(2);
  s+=1;

  mpf_t y;
  mpf_init(y);
  mpf_set_z(y,r.num);
  mpf_set_z(tmpf,s.num);
  mpf_div(y,y,tmpf);
  gmp_printf("[p1*p2-floor(sqrt(p1*p2)^2)]/(2*sqrt(p1*p2)+1): %Fe\n",y);

  

  return(0);
}

#include <eutils/emain.h>
#include <eutils/eudl.h>

int emain()
{
  eparseArgs(argvc,argv);

  ldieif (argvc<2,"syntax: eudl <udl>");

  etable data;

  data=udl_load(argv[1]);

  cout << data.size() << endl; 

  cout << data << endl;


  return(0);
}

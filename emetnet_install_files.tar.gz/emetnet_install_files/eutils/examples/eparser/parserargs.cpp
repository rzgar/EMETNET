#include <eutils/eparser.h>
#include <eutils/estr.h>
#include <eutils/estrarray.h>
#include <eutils/efile.h>
#include <eutils/emain.h>
#include <eutils/evarclassconstructor.h>


/////////////////////////////////
//
//    Class example
//

class client
{
 public:
  estrarray basket;
  estr name;
  estr phone;
  int orders;
  float rating;
  bool vip; 

  client();
  client(const estr& name);

  void order(const estr& type,int quantity);
  void showbasket();
};

client::client(): orders(0), rating(0.0), vip(false) {}
client::client(const estr& _name): name(_name),orders(0), rating(0.0), vip(false)  {}

void client::order(const estr& type,int quantity)
{
  basket.add(type,quantity);
}

void client::showbasket()
{
  cout << basket << endl;
}



/////////////////////////////////
//
//    Function example
//

void showclient(const client& c)
{
  cout << "Name: "<<c.name<<endl;
  cout << "Phone: "<<c.phone<<endl;
}


void interpretscript(const estr& filename)
{
  efile file(filename);

  estr code;

  while (file.readln(code))
    epinterpret(code);
}


int emain()
{
//  getLogger()->level=1;

  // registering class methods and properties:
  epregisterClassConstructor(client,());                // allows creation of client objects:  c = client();
  epregisterClassConstructor(client,(const client&));   // same as above but: client("client name") 

  epregisterClassMethod(client,order);
  epregisterClassMethod(client,showbasket);
  epregisterClassProperty(client,name);
  epregisterClassProperty(client,phone);
  epregisterClassProperty(client,basket);
  epregisterClassProperty(client,orders);
  epregisterClassProperty(client,rating);
  epregisterClassProperty(client,vip);


  // registering the functions
  epregisterFunc(showclient);

  epregisterFunc(interpretscript);

  client c;

  epregister(c);
  eparseArgs(argvc,argv);

  getLogger()->level=1;


  cout << "c.name: " << c.name << endl;
  cout << "c.phone: " << c.phone << endl;
  cout << "c.basket: " << c.basket << endl;
  cout << "c.orders: " << c.orders << endl;
  cout << "c.rating: " << c.rating << endl;
  cout << "c.vip: " << c.vip << endl;

  epruninterpret();

  return(0);
}

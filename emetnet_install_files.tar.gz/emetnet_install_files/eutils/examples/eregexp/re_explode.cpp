#include <eutils/eregexp.h>
#include <eutils/logger.h>

int main(int argvc,char *argv[])
{
  dieif(argvc < 3,"syntax: re_explode <text> <pattern>");

  cout << re_explode(argv[1],argv[2]) << endl;


  return(0);
}


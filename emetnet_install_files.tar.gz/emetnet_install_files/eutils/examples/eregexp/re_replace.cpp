#include <eutils/eregexp.h>
#include <eutils/logger.h>

int main(int argvc,char *argv[])
{
  dieif(argvc < 4,"syntax: re_replace <text> <text:pattern> <text:replace>");

  cout << re_replace(argv[1],argv[2],argv[3]) << endl;


  return(0);
}


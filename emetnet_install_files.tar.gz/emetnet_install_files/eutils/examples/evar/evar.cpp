#include <eutils/emain.h>
#include <eutils/evar.h>
#include <eutils/estr.h>

int emain()
{
  evar a="hello world";

  cout << a << endl;

  return(0);
}

#ifndef __EKSTRACT__
#define __EKSTRACT__

#include "eutils.h"

#include "estr.h"

class ekstract
{
 public:
  void create_template(const estr &text, const estr &var);

};

#endif


#include "buffer.h"

cbuffer::cbuffer(int size): bsize(size),bindex(0)
{
  fbuffer=(char*)malloc(bsize);
}

cbuffer::~cbuffer()
{
  free(fbuffer);
}



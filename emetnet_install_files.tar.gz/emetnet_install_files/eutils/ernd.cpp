
#include "ernd.h"

#include <sys/types.h>
#include <time.h>

#ifndef _MSC_VER
#include <sys/time.h>
#endif
#ifdef _WIN32
#include <windows.h>
#endif

cernd ernd;

#ifdef EUTILS_HAVE_LIBGSL

#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

gsl_rng *grng;

double cernd::uniform()
{
  return((double)gsl_rng_uniform(grng));
}

double cernd::gaussian(double sigma)
{
  return((double)gsl_ran_gaussian(grng,sigma));
}

double cernd::exponential(double rate)
{
  return((double)gsl_ran_exponential(grng,rate));
}

unsigned int cernd::geometric(double mean)
{
  return(gsl_ran_geometric(grng,mean));
}

cernd::cernd()
{
  grng = gsl_rng_alloc(gsl_rng_ranlxd2);
#ifdef _WIN32
  _LARGE_INTEGER tptime;
  QueryPerformanceCounter(&tptime);
  srand(tptime.LowPart);
  gsl_rng_set(grng,tptime.LowPart);
#else
  timeval tmptv;
  gettimeofday(&tmptv,0);

  gsl_rng_set(grng,tmptv.tv_usec);
#endif
}

cernd::~cernd()
{
  gsl_rng_free(grng);
}

#else

  #ifdef WIN32
    #include <windows.h>
  #endif
  #include <stdlib.h>

  
double cernd::uniform()
{
  return((double)rand()/((double)RAND_MAX+1.0));
}

/*
double cernd::gaussian(double sigma)
{
  lerror("eutils compiled without libgsl support, so gaussian is not implemented");
//  return((double)gsl_ran_gaussian(grng,sigma));
  return(1.0);
}
*/
cernd::cernd()
{
#ifdef _WIN32
  _LARGE_INTEGER tptime;
  QueryPerformanceCounter(&tptime);
  srand(tptime.LowPart);
#else
  timeval tmptv;
  gettimeofday(&tmptv,0);

  srand(tmptv.tv_usec);
#endif
}

cernd::~cernd()
{
}

#endif



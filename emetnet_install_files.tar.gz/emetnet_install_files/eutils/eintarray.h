#ifndef EINTARRAY_H
#define EINTARRAY_H

#include "eutils.h"

#include "ebasicarray_dec.h"

typedef ebasicarray<int> eintarray;

#endif


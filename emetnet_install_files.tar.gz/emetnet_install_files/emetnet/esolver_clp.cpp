
#include "esolver_clp.h"

//#define MAXFLUX COIN_DBL_MAX

esolver_clp::esolver_clp(): model(0x00)
{
  MMAXFLUX=COIN_DBL_MAX;
}

esolver_clp::~esolver_clp()
{
  if (model) delete model;
}

void esolver_clp::setobjective2(int i,double value)
{
  model->setObjCoeff(i,value);
}

void esolver_clp::setobjective(int i,double value)
{
  model->setObjCoeff(iobjective,0.0);
  model->setObjCoeff(i,value);
  iobjective=i;
}

void esolver_clp::setobjective(evector& objective)
{
  int i;

  for (i=0; i<objective.w; ++i)
    model->setObjCoeff(i,objective[i]);
}


void esolver_clp::setybounds(int i,double min,double max)
{
//  model->setRowBounds(i,min,max);
  setxbounds(i+net->links.size(),min,max);
}

void esolver_clp::setxbounds(int i,double fmin,double fmax)
{
  model->setColumnBounds(i,fmin,fmax);
}

void esolver_clp::setActive(const eintarray& arr)
{
  lerrorifr(arr.size() != net->links.size(),"setActive: active array mismatch",);
   
  int i;
  for (i=1; i<arr.size(); ++i){
    if (arr[i]!=0)
      activate(i);
    else
      disable(i);
  }
}

void esolver_clp::activate(int i)
{
  lddieif(!model,"activating node "+estr(i)+" before parsing model");
  double lower,upper;
  upper=COIN_DBL_MAX;
  lower=-COIN_DBL_MAX;
  if (net->links[i].irreversible)
    lower=0;

  net->links[i].active=true;

  model->setColumnBounds(i,lower,upper);
}

void esolver_clp::disable(int i)
{
  lddieif(!model,"disabling node "+estr(i)+" before parsing model");

  net->links[i].active=false;
  model->setColumnBounds(i,0.0,0.0);
}

void esolver_clp::parse(ematrix& m,evector& lower,evector& upper,evector& xlower,evector& xupper,evector& objective)
{
  int i,j;
  int t_elements;

  t_elements=0;
  for (i=0; i<m.w; ++i){
    for (j=0; j<m.h; ++j){
      if (m(j,i)!=0.0)
        ++t_elements;
    }
  }

  double * element = new double [t_elements];
  int * row = new int[t_elements];
  int * start = new int[m.w+1];
  int * length = new int[m.w+1];

  int k;

  // m.w ---> number of columns
  // m.h ---> number of rows

  ldinfo(" generating problem of " + estr(m.w) + " columns X " + estr(m.h) + " rows");

  i=0;
  k=0;
  start[m.w]=t_elements;
  for (i=0;i<m.w;++i) {
    start[i]=k;
    length[i]=0;

    // for each flux, write the row which it affects
    for (j=0; j<m.h; ++j){
      if (m(j,i)!=0.0){
        element[k]=m(j,i);
        row[k]=j;
        ++k;
        ++length[i];
      }
    }
  }
  ldieif(t_elements!=k,"something is wrong with t_elements! t_elements="+estr(t_elements)+" , k="+estr(k));

  ldinfo("creating clp model");

  if (model) delete model;
  model = new ClpSimplex;

  // Create Packed Matrix
  CoinPackedMatrix matrix;
  matrix.assignMatrix(true,m.h,m.w,t_elements,element,row,start,length);
	
  ldinfo("loading model from matrix");
  // load model
  model->loadProblem( matrix, lower.vector, upper.vector, objective.vector, xlower.vector, xupper.vector );
			
//  ldwarn("finding solution");
//  model->setLogLevel(0);
  model->setPrimalTolerance(1.0E-9);
  model->setOptimizationDirection(-1);

  delete [] element;
  delete [] start;
  delete [] length;
  delete [] row;
}

void esolver_clp::parse(enet& _net)
{
  net=&_net;
  int numberColumns;

  int i;
  int t_elements;

  t_elements=0;
  numberColumns=net->links.size()+net->nodes.size();
  for (i=0; i<net->links.size(); ++i){
    t_elements+=net->links[i].src.size()+net->links[i].dst.size();
  }

  //added for metabolite in/out reactions
  t_elements+=net->nodes.size();

  double * objective = new double[numberColumns];
  double * lowerColumn = new double[numberColumns];
  double * upperColumn = new double[numberColumns];

  double * element = new double [t_elements];
  int * row = new int[t_elements];
  int * start = new int[numberColumns+1];
  int * length = new int[numberColumns+1];

  int j,k;

  ldinfo(" generating problem of " + estr(numberColumns) + " columns X " + estr((int)net->nodes.size()) + " rows");


//int ri;
  i=0;
  k=0;
//  start[numberColumns]=2*numberColumns;
  start[numberColumns]=t_elements;
  for (i=0;i<net->links.size();++i) {
//    if (!links[ri].active) continue;
    start[i]=k;
    length[i]=net->links[i].src.size() + net->links[i].dst.size();

    // for each flux, write the row which it affects
    for (j=0; j<net->links[i].src.size(); ++j){
      element[k]=-net->links[i].src[j].rate;
      row[k]=net->links[i].src[j].node->i;
      ++k;
    }
    for (j=0; j<net->links[i].dst.size(); ++j){
      element[k]=net->links[i].dst[j].rate;
      row[k]=net->links[i].dst[j].node->i;
      ++k;
    }

    // maximum/minimum reaction fluxs
    if (net->links[i].active)
      upperColumn[i]=COIN_DBL_MAX;
    else
      upperColumn[i]=0.0;

    if (!net->links[i].active || net->links[i].irreversible)
      lowerColumn[i]=0.0;
    else
      lowerColumn[i]=-COIN_DBL_MAX;

    // we dont want to maximize any other fluxes
    // but the first one
    objective[i]=0.0;
  }


  int ifbounds,inode;
  for (; i<net->links.size()+net->nodes.size(); ++i){
    inode=i-net->links.size();
    objective[i]=0.0;
    start[i]=k;
    length[i]=1;
    element[k]=-1.0;
    row[k]=inode;
    ++k;
    ifbounds=net->fluxbounds.findkey(net->nodes[inode].id);
    lowerColumn[i]=0.0;
    upperColumn[i]=0.0;
    if (ifbounds != -1){
      lowerColumn[i]=net->fluxbounds[ifbounds].x;
      upperColumn[i]=net->fluxbounds[ifbounds].y;
    }else if (net->nodes[inode].id.find("_external") != -1 || net->nodes[inode].id.find("[e]") != -1 || internal_secretion){
      lowerColumn[i]=0.0;
      upperColumn[i]=COIN_DBL_MAX;
    }
  }

  objective[0] = 1.0;
  iobjective=0;

  ldieif(t_elements!=k,"something is wrong with t_elements! t_elements="+estr(t_elements)+" , k="+estr(k));

//  ldwarn("creating model and matrix");

//  linfo("creating Clp Model");

  if (model) delete model;

  model = new ClpSimplex();

  model->setLogLevel(0);

  // Create Packed Matrix
  CoinPackedMatrix matrix;
  matrix.assignMatrix(true,net->nodes.size(),numberColumns,
	  	        t_elements,element,row,start,length);
	
  double *upper = new double[net->nodes.size()];
  double *lower = new double[net->nodes.size()];
	
  // we do not use slack variable bounds but instead sink and source limits
  for (i=0;i<net->nodes.size();++i){
    lower[i]=0.0;
    upper[i]=0.0;
  }
  
//  ldwarn("loading model");
  // load model
  model->loadProblem(matrix,
           lowerColumn,upperColumn,objective,
			    lower,upper);

//  ClpPresolve presolveInfo; 
//  ClpSimplex * presolvedModel = presolveInfo.presolvedModel(model); 
			
  delete [] lower;
  delete [] upper;
  delete [] objective;
  delete [] lowerColumn;
  delete [] upperColumn;
  delete [] element;
  delete [] start;
  delete [] length;
  delete [] row;

//  ldwarn("finding solution");
  model->setPrimalTolerance(1.0E-9);
//  model->setDualTolerance(1.0E-12);
  model->setOptimizationDirection(-1);
	model -> scaling(0);
}


double esolver_clp::solve()
{

  lddieif(!model,"solve method called before model was parsed");


  ClpSolve solve;
  solve.setSolveType( ClpSolve::usePrimal );
  solve.setPresolveType( ClpSolve::presolveOn );
  solve.setSpecialOption(2,1); // Turn off signal handler
  
  model->initialSolve(solve);
//  model->primal();
//  model->dual();

  double r;

  int status;
  status = model->status();

//  ldwarn("showing solution");
  switch(status){
    case 0:
/*
      y = model->dualRowSolution();
      x = model->dualColumnSolution();
*/
      y = model->primalRowSolution();
      x = model->primalColumnSolution();
//      for(i=0; i<nodes.size();++i){
//        if (fluxbounds.findkey(nodes[i].id) != -1)
//          cout << nodes[i].id<<": "<<rowPrimal[i]<<endl;
//      }
//      cout << "target found: "<<columnPrimal[0]<<endl;
      r=model->objectiveValue(); //x[iobjective];
      if (fabs(r)<=1.0e-8) r=0.0;
//      delete rowPrimal; delete columnPrimal;
      return(r);
     break;
    case 1:
      cerr << "Model is infeasible!" << endl;
     break;
    case 2:
      cerr << "Model is dual infeasible!" << endl;
     break;
    case 3:
      cerr << "Limit number of iterations reached" << endl;
     break;
    default:
     cerr << "Unknown status: " << status << endl;
  }

  return(-1);
}


#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <vector>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
using std::vector;

int emain()
{
  ldieif(argvc<2,"syntax: ./density_surfacing   <inputfile> ");
  eparseArgs(argvc,argv);

  //Reading input files and saving in the corresponding arrays
  efile fin;
  efile fout;
  estr str;
  estr filename_in=argv[1];
  estr filename_out=filename_in+"_final";
  estrarray parts;

  float mat[46][11];
  for (int i=0;i<46;++i){for (int j=0;j<11;++j){mat[i][j]=0;}}

  fin.open(filename_in,"r");
  while (fin.readln(str)) {
         parts=str.explode(" ");
         int x1=parts[0].i();
         int x2=parts[1].i();
         mat[x1][x2]=mat[x1][x2]+1;
  }
  fin.close();

  fout.open(filename_out,"a");
  for (int i=0;i<46;++i){
       for (int j=0;j<11;++j){
            if (mat[i][j]>0){
                double i_d=(double) i;
                double j_d=(double) j;
                float n_d=mat[i][j];
                estr strx1=i_d;
                estr strx2=j_d;
                estr strx3=n_d;
                estr intstr=strx1+" "+strx2+" "+strx3+"\n";
                fout.write(intstr);
            }
      }
  }

  fout.close();

}  

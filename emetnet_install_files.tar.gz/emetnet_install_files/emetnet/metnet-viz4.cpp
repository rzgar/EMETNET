
#include "enet.h"
#include <eutils/eudi.h>

#include <eutils/logger.h>
#include <eutils/vector2.h>
#include <eutils/ernd.h>

#include <edlib-2/ewindow.h>
#include <edlib-2/ewinarray.h>
#include <edlib-2/ewinscrollbar.h>
#include <edlib-2/ecolor.h>
#include <edlib-2/ewinpopup.h>


#include "edrawnet.h"

estrarray ignore("C00080,C00001,C00002,C00009,C00003,C00004,C00006,C00008,C00013,C00011,C00014,C00005,C00007");

etable reactions;
etable kegg;
etable ijr904;

ewinsys winsys;
ewinarray winarray;





int main(int argvc,char *argv[])
{
  dieif(argvc<2,"syntax: metnet-viz <file.net>");

//  kegg=udi_load("mysql://root@localhost/kegg_ligand.compound");

  reactions=udi_load("kegg-reactions.csv");
//  reactions=udi_load("mysql://root@localhost/kegg_ligand.reaction");
//  ijr904=udi_load("mysql://root@localhost/ijr904.compound");

//  int k;
//  k=ijr904.fields.find("abbreviation")
//  if (k!=-1)
//    ijr904.fields.value(k) = "entry";

  enet net;
  net.load(argv[1]);

  int i;
  edrawnet drawnet(net);

  drawnet.nodeinfo = kegg;

  drawnet.create(1024,786);
  drawnet.scale = evector2(1024.0,786.0);

/*
  ewindow winsettings;
  winsettings.create(400,400);

  earray<escrollbar> sliders;
  sliders.addref(new escrollbar("forcefactor",drawnet.forcefactor,0.0,5.0));
  sliders.addref(new escrollbar("Repulsion force",drawnet.ffactorRepulsion,0.0,5.0));
  sliders.addref(new escrollbar("Repulsion range",drawnet.frangeRepulsion,0.0,1.0));
  sliders.addref(new escrollbar("Attraction force",drawnet.ffactorAttraction,0.0,5.0));
  sliders.addref(new escrollbar("Attraction range",drawnet.frangeAttraction,0.0,1.0));
  sliders.addref(new escrollbar("Middle Link force",drawnet.ffactorMLink,0.0,5.0));
  sliders.addref(new escrollbar("End Link force",drawnet.ffactorTLink,0.0,5.0));
  sliders.addref(new escrollbar("SrcDst Repulsion force",drawnet.ffactorSDRepulsion,0.0,5.0));
  for (i=0; i<sliders.size(); ++i)
    sliders[i].create(winsettings,10,20+20*i,380,15);
*/

  while(winsys.processMessages()){
    drawnet.clear(ecBlack);
    drawnet.draw();
    drawnet.update();

    drawnet.flip();
  }

  return(0);
}

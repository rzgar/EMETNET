// This program checks if each genotype has any disconnected reactions. If none, it saves the genotype. After all genotypes have been checked, it checks to see the connectivity of genotypes with all connected reactions. 

#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
#include <igraph/igraph.h>



estr output="connectedness";
estr solver="esolver_clp";
int netsize=-1;
int strict=0;
int force_away=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
int savenet=0;
enet net;

erandomWalk *prw=0x00;

using std::vector;

// array that will store pre-computed number of "on" bits in a 16bit value
char precomp_count_16bits[0x1u<<16];
 // function to compute how many "on" bits exist in a 32bit (int) value
inline char count_bits(unsigned int i) {
  int cbits=0;
  while (i){
    cbits += i&0x1u;
    i>>=1;
  }
  return(cbits);
}

// function that needs to be called at the beginning of a program (before any other code) to initialize the array with pre-computed values (bits_in_16bits)
void init_precomp_count()
{
  unsigned int i;
  // iterates through all possible 16 bit values and initializes the array to the number of "on" bits in that value
  for (i=0; i<0x1u<<16; ++i)
    precomp_count_16bits[i]=count_bits(i);
}

// function to compute how many "on" bits exist in a 64bit (long int) value using the pre-computed table. Basically this takes the first the 64 bits and splits it into 16 + 16 + 16 + 16. For each of those 16 bits sums the count using the table to look them up. 
int count_bits16(unsigned long i)
{
  return( precomp_count_16bits[i & 0xfffful] + precomp_count_16bits[(i>>16) & 0xfffful] +precomp_count_16bits[(i>>32) & 0xfffful] + precomp_count_16bits[(i>>48) & 0xfffful] );
}

// This function will return the hamming distance between two networks represented by 64bit values
inline int mnets_dist(unsigned long x,unsigned long y)
{
  return(count_bits16(x^y));
}


int emain() {


  ldieif(argvc<4,"syntax: ./check-connectedness [--output connectedness] <universe.net> <size.dat> <fluxbounds.flx>");
  
  epregister(output);
  epregister(solver);
  epregister(savenet);
  eparseArgs(argvc,argv);

//  cout << "# environment: "<<argv[3] << endl;
//	cout << "# input file: "<<argv[2] << endl;

  net.load(argv[1]); 
//  cout << "# global network: "<<argv[1] << endl;
//  cout << "# reactions (global): " << net.links.size() << endl;
  net.correct_malformed();
//  cout << "# non-malformed reactions: " << net.links.size() << endl;

  erandomWalk rw(net,solver,strict);
  prw=&rw; 

  rw.periphery_only=periphery_only;
  rw.mutate_transport=mutate_transport;
  rw.internal_secretion=internal_secretion;
  rw.only_viable=only_viable;
  rw.setRSize(netsize);
  rw.getEnv(argvc,argv);

  rw.load(net);
  rw.calcPhenotype();
  rw.viablePhenotype=rw.phenotype;
  estr unigR = rw.printGrowthRate();


  int transport_count,i,j;
  transport_count=0;

  for (i=0; i<net.links.size(); ++i){
      if (net.links[i].transport)
      ++transport_count;
  }
//  cout << "# phenotype: "<< intarr2str(rw.phenotype)<<endl;
//  cout << "# transport reactions: "<<transport_count<<endl;
//	cout << "# Number of nontransport reactions: " << net.links.size()-transport_count-1 << endl;
	estrarray parts;
	int startindex=26;
	int tmp, index;
	int linecounter=0;
	estr str;
	efile f;
	f.open(argv[2],"r");
  int numconnectedgenotypes=0;
  init_precomp_count();  // initialize the precomp_count array
  earray <unsigned long> connnetworks;
  unsigned long genbits=0x00ul; // start with a 64bit value representing the network with all bits set to zero
 
 
//  efile files;  	
//	files.open(output,"a");


	while (f.readln(str)) {
		++linecounter;
  	parts=str.explode(" ");
		eintarray numarray;
		for (j=0; j<parts.size(); ++j) {
			tmp = parts[j].i();
			numarray.add(tmp);
		}

    /* numarray has the locations of zeros. Disable those reactions from the universe */
		for (i=0; i<numarray.size(); ++i) {
			index=numarray[i]+startindex;
			rw.disable(index);
		}
		rw.calcPhenotype();
//		if (!rw.isViable()) {
//		  cout << "ERROR: Genotype not viable. " << endl;
//		}

		/* genotype ready to be analyzed. Analyzing connectedness of reactions */
		int numconnectedreactions=0;
		int numreactions=0;
    for (j=1; j<rw.genotype.size(); ++j) {
      if (rw.genotype[j]==1 && !net.links[j].transport) {
        ++numreactions;
        rw.disable(j);
        if (rw.is_connected(net.links[j])==1) {++numconnectedreactions;}
        
       // else if (linecounter==5){cout << "reaction" << linecounter << ","<< j << endl; }
        
        rw.activate(j);
      }
  }
    if (numreactions == numconnectedreactions) {
//      cout << "# Active genotype: " << numreactions << " " << linecounter <<endl;
      for (int m=0; m<parts.size(); ++m){ genbits|=(0x01ul<<(parts[m].i()-1));}
      connnetworks.add(genbits);
      ++numconnectedgenotypes;
 //     estr intstr = linecounter;
// 			files.write(intstr+"\n");
//      cout << linecounter  << endl;
    }
     else {cout << linecounter << "," << endl;}

    
    /* Reactivate the disabled reactions */
		for (j=0; j<numarray.size(); ++j) {
			index=numarray[j]+startindex;
			rw.activate(index);
		}
		
	}// File reading while loop closes
//  files.close();

	cout << "# Fraction of connected genotypes: " << double(numconnectedgenotypes)/double(linecounter) << endl;
	
}

#ifndef __ESOLVER_CLP__
#define __ESOLVER_CLP__

#include "esolver.h"

#include <ipopt/IpStdCInterface.h>

class eqnlsolver_ipopt : public esolver
{
 public:
  IpoptProblem nlp;
  Number* x;                    /* starting point and solution vector */
  Number* mult_x_L;             /* lower bound multipliers
  					  at the solution */
  Number* mult_x_U;             /* upper bound multipliers
  					  at the solution */
  enet* net;
  
  eqnlsolver_ipopt();
  ~eqnlsolver_ipopt();

  void parse(enet& net);
  double solve();

  void setxbounds(int i,double min,double max);
  void setybounds(int i,double min,double max);

  void activateQ(int i);
  void disableQ(int i);

  void setActive(const eintarray& arr);
  void activate(int i);
  void disable(int i);

  void setobjective(int i,double value=1.0);
  void setobjective(evector& obj);
  void parse(ematrix& m,evector& lower,evector& upper,evector& xlower,evector& xupper,evector& objective);
};

#endif


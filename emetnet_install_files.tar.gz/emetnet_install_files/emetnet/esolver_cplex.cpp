
#include "esolver_cplex.h"
#include <eutils/logger.h>

CPXENVptr esolver_cplex::env=0x00;

void esolver_cplex::setybounds(int i,double min,double max)
{
  lddieif(!lp,"setybounds "+estr(i)+" before parsing model");

  int status;
  char sense;

  if (min==max){
    sense='E';
    CPXchgsense(env,lp,1,&i,&sense);
    CPXchgrhs(env,lp,1,&i,&min);
    return;
  }

  if (max>=MMAXFLUX){

    if (min<=-MMAXFLUX)
      min=-1.0e10;
    sense='G';
    status=CPXchgsense(env,lp,1,&i,&sense);
    lwarnif(status,"Error changing sense for y bound: "+estr(i));
    status=CPXchgrhs(env,lp,1,&i,&min);
    lwarnif(status,"Error changing rhs for y bound: "+estr(i));
    return;
  }


  if (min<=-MMAXFLUX){
    sense='L';
    status=CPXchgsense(env,lp,1,&i,&sense);
    lwarnif(status,"Error changing sense for y bound: "+estr(i));
    status=CPXchgrhs(env,lp,1,&i,&max);
    lwarnif(status,"Error changing rhs for y bound: "+estr(i));
    return;
  }

  sense='R';
  max-=min;


  status=CPXchgsense(env,lp,1,&i,&sense);
  lwarnif(status,"Error changing sense for y bound: "+estr(i));
  status=CPXchgrhs(env,lp,1,&i,&min);
  lwarnif(status,"Error changing rhs for y bound: "+estr(i));
  status=CPXchgrngval(env,lp,1,&i,&max);
  lwarnif(status,"Error changing range for y bound: "+estr(i));
}

void esolver_cplex::setxbounds(int i,double min,double max)
{
  lddieif(!lp,"setxbounds "+estr(i)+" before parsing model");


  int ind[2];
  char lu[2];
  double bd[2];

  ind[0]=i;         ind[1]=i;
   lu[0]='L';        lu[1]='U';
   bd[0]=min;        bd[1]=max;

  int status;
  if (min==max){
    lu[0]='B';
    status=CPXchgbds(env,lp,1,&ind[0],&lu[0],&bd[0]);
  }else
    status=CPXchgbds(env,lp,2,ind,lu,bd);

  lwarnif(status,"Error changing for x bound: "+estr(i)+" "+estr(min)+","+estr(max));
}

void esolver_cplex::setobjective(evector& objective)
{
  int ind[objective.w];
  int i,status;

  for (i=0; i<objective.w; ++i)
    ind[i]=i;

  status = CPXchgobj(env,lp,objective.w,ind,objective.vector);
 
  ldieif(status,"error setting objective vector");
}

void esolver_cplex::setobjective(int i,double value)
{
  int ind[2];
  double val[2];

  ind[0]=i;
  val[0]=value;

  ind[1]=iobjective;
  val[1]=0.0;

  int status;
  if (i==iobjective)
    status = CPXchgobj (env, lp, 1, ind, val);
  else
    status = CPXchgobj (env, lp, 2, ind, val);

  ldieif(status,"error changing objective: "+estr(i)+" ("+estr(value)+")  oldobjective: "+estr(iobjective));

  iobjective=i;
}

void esolver_cplex::setActive(const eintarray& arr)
{
  lerrorifr(arr.size() != net->links.size(),"setActive: active array mismatch",);
   
  int i;
  for (i=1; i<arr.size(); ++i){
    if (arr[i]!=0)
      activate(i);
    else
      disable(i);
  }
}

void esolver_cplex::activate(int i)
{
  lddieif(!lp,"activating node "+estr(i)+" before parsing model");
  lddieif(!net,"activating node "+estr(i)+" when no network loaded");

  net->links[i].active=true;


  if (net->links[i].irreversible)
    setxbounds(i,0.0,MMAXFLUX);
  else
    setxbounds(i,-MMAXFLUX,MMAXFLUX);
}

void esolver_cplex::disable(int i)
{
  lddieif(!lp,"disabling node "+estr(i)+" before parsing model");
  lddieif(!net,"disabling node "+estr(i)+" when no network loaded");

  net->links[i].active=false;

  setxbounds(i,0.0,0.0);
}

bool esolver_cplex::openEnv()
{
  if (env) return(true);

  int status = 0;

  env = CPXopenCPLEX(&status);
  if ( env == NULL ) {
    char errmsg[1024];
    CPXgeterrorstring (env, status, errmsg);
    lerror("Could not open CPLEX environment: "+estr( errmsg));
    return(false);
  }
//    status = CPXsetintparam (env, CPX_PARAM_SCRIND, CPX_ON);
//    ldieif(status,"Failure to turn on screen indicator, error "+estr(status));
  status = CPXsetintparam (env, CPX_PARAM_DATACHECK, CPX_ON);
  ldieif(status,"Failure to turn on data checking, error "+estr(status));
    status = CPXsetintparam (env, CPX_PARAM_PREIND, CPX_OFF);
    ldieif(status,"Failure to turn off presolve, error "+estr(status));
  status = CPXsetdblparam (env, CPX_PARAM_TILIM,60.0);
  ldieif(status,"Failure to set time limit to 60 seconds, error "+estr(status));
  status = CPXsetintparam (env, CPX_PARAM_PREPASS, 0);
  ldieif(status,"Failure to turn on only Linear Reductions, error "+estr(status));
  status = CPXsetintparam (env, CPX_PARAM_PRELINEAR, 0);
  ldieif(status,"Failure to turn on only Linear Reductions, error "+estr(status));

  return(true);
}

bool esolver_cplex::isAvailable()
{
  return(openEnv());
}

void esolver_cplex::parse(ematrix& m,evector& lower,evector& upper,evector& xlower,evector& xupper,evector& objective)
{
  int status = 0;

  ldieif(!openEnv(),"unable to open CPLEX environment");
   
  lp = CPXcreateprob (env, &status, "lpex1");
  ldieif(lp==NULL,"Failed to create LP.");


  int numberColumns;

  int i,j;
  int t_elements;

  t_elements=0;
  numberColumns=m.w;
  for (i=0; i<m.w; ++i){
    for (j=0; j<m.h; ++j){
      if (m(j,i)!=0.0)
        ++t_elements;
//      t_elements+=net->links[i].src.size()+net->links[i].dst.size();
    }
  }

  double *range = new double[m.h];
  char sense[m.h];
	
  for (i=0;i<lower.w;++i){
    if (lower(i)==upper(i)){
      sense[i]='E';
    }else{
      sense[i]='R';
      range[i]=upper(i)-lower(i);
    }
  }

  status = CPXnewrows(env,lp,lower.w,lower.vector,sense,range,NULL);

  double * element = new double [t_elements];
  int * row = new int[t_elements];
  int * start = new int[m.w+1];
  int * length = new int[m.w+1];

  int k;

  ldinfo(" generating problem of " + estr(numberColumns) + " columns X " + estr(m.h) + " rows");

  i=0;
  k=0;
  start[numberColumns]=t_elements;
  for (i=0;i<m.w;++i) {
    start[i]=k;
    length[i]=0;

    // for each flux, write the row which it affects
    for (j=0; j<m.h; ++j){
      if (m(j,i)!=0.0){
        element[k]=m(j,i);
        row[k]=j;
        ++k;
        ++length[i];
      }
    }
  }
  status = CPXaddcols(env,lp,m.w,t_elements,objective.vector,start,row,element,xlower.vector,xupper.vector,NULL);


  ldieif(t_elements!=k,"something is wrong with t_elements! t_elements="+estr(t_elements)+" , k="+estr(k));

//  ldwarn("creating model and matrix");

			
  delete [] range;
  delete [] element;
  delete [] start;
  delete [] length;
  delete [] row;


  CPXchgobjsen (env, lp, CPX_MAX);

  int numcols;
  int numrows;

  numcols = m.w;
  numrows = m.h;

  x = new double[numcols];
  y = new double[numrows];
  dj = new double[numcols];
  pi = new double[numrows];
}

void esolver_cplex::parse(enet& _net)
{
  net=&_net;

  int status = 0;

  ldieif(!openEnv(),"unable to open CPLEX environment");

  lp = CPXcreateprob (env, &status, "lpex1");
  ldieif(lp==NULL,"Failed to create LP.");



  int numberColumns;

  int i;
  int t_elements;

  t_elements=0;
  numberColumns=net->links.size();
  for (i=0; i<net->links.size(); ++i){
    t_elements+=net->links[i].src.size()+net->links[i].dst.size();
  }

  double *range = new double[net->nodes.size()];
  double *lower = new double[net->nodes.size()];
  char *rlabel[net->nodes.size()];
  char sense[net->nodes.size()];
	
  for (i=0;i<net->nodes.size();++i){
    if (net->fluxbounds.findkey(net->nodes[i].id) != -1){
      if (net->fluxbounds[net->nodes[i].id].x<=-MMAXFLUX)
        lower[i]=-1.0e10;
      else
        lower[i]=net->fluxbounds[net->nodes[i].id].x;
      if (net->fluxbounds[net->nodes[i].id].y >= MMAXFLUX)
        { range[i]=0.0; sense[i]='G'; }
      else
        { range[i]=net->fluxbounds[net->nodes[i].id].y - net->fluxbounds[net->nodes[i].id].x; sense[i] ='R';}
    }
    else if (net->nodes[i].id.find("_external") != -1 || net->nodes[i].id.find("[e]") != -1 || internal_secretion)
      {lower[i]=0.0; range[i]=0.0; sense[i]='G'; } // allow output of _external metabolites
    else
      {lower[i]=0.0; range[i]=0.0; sense[i]='E'; }
    rlabel[i]=net->nodes[i].id._str;
  }

  status = CPXnewrows(env,lp,net->nodes.size(),lower,sense,range,rlabel);

  double * objective = new double[numberColumns];
  double * lowerColumn = new double[numberColumns];
  double * upperColumn = new double[numberColumns];
  char *clabel[numberColumns];

  double * element = new double [t_elements];
  int * row = new int[t_elements];
  int * start = new int[numberColumns+1];
  int * length = new int[numberColumns+1];

  int j,k;

  ldinfo(" generating problem of " + estr(numberColumns) + " columns X " + estr((int)net->nodes.size()) + " rows");



//int ri;
  i=0;
  k=0;
//  start[numberColumns]=2*numberColumns;
  start[numberColumns]=t_elements;
  for (i=0;i<net->links.size();++i) {
//    if (!links[ri].active) continue;
    start[i]=k;
    length[i]=net->links[i].src.size() + net->links[i].dst.size();

    // for each flux, write the row which it affects
    for (j=0; j<net->links[i].src.size(); ++j){
      element[k]=-net->links[i].src[j].rate;
      row[k]=net->links[i].src[j].node->i;
      ++k;
    }
    for (j=0; j<net->links[i].dst.size(); ++j){
      element[k]=net->links[i].dst[j].rate;
      row[k]=net->links[i].dst[j].node->i;
      ++k;
    }

    // maximum/minimum reaction fluxs
    if (net->links[i].active)
      upperColumn[i]=MMAXFLUX;
    else
      upperColumn[i]=0.0;

    if (!net->links[i].active || net->links[i].irreversible)
      lowerColumn[i]=0.0;
    else
      lowerColumn[i]=-MMAXFLUX;

    clabel[i]=net->links[i].info[0]._str;

    // we dont want to maximize any other fluxes
    // but the first one
    objective[i]=0.0;
  }
  objective[0] = 1.0;
  iobjective=0;


  status = CPXaddcols(env,lp,net->links.size(),t_elements,objective,start,row,element,lowerColumn,upperColumn,clabel);


  ldieif(t_elements!=k,"something is wrong with t_elements! t_elements="+estr(t_elements)+" , k="+estr(k));

//  ldwarn("creating model and matrix");

			
  delete [] lower;
  delete [] range;
  delete [] objective;
  delete [] lowerColumn;
  delete [] upperColumn;
  delete [] element;
  delete [] start;
  delete [] length;
  delete [] row;


  CPXchgobjsen (env, lp, CPX_MAX);

  int numcols;
  int numrows;

  numcols = net->links.size();
  numrows = net->nodes.size();

  x = new double[numcols];
  y = new double[numrows];
  dj = new double[numcols];
  pi = new double[numrows];
}


esolver_cplex::esolver_cplex(): lp(0x00),dj(0x00),pi(0x00)
{
  MMAXFLUX=CPX_INFBOUND;
}

esolver_cplex::~esolver_cplex()
{
  if (x) delete x;
  if (y) delete y;
  if (dj) delete dj;
  if (pi) delete pi;
}

double esolver_cplex::solve()
{
  lddieif(!lp,"solve method called before model was parsed");

  int status;

//  status = CPXpresolve(env,lp,CPX_ALG_DUAL);
//  ldieif(status,"Failed presolve of LP");


  status = CPXsetdblparam (env, CPX_PARAM_EPRHS, 1.0e-9);
  
  status = CPXsetdblparam (env, CPX_PARAM_EPOPT, 1.0e-9);

  status = CPXsetintparam (env, CPX_PARAM_NUMERICALEMPHASIS, 1);

//  status = CPXdualopt(env,lp);
  status = CPXprimopt(env,lp);
  ldieif(status,"Failed to optimize LP");

/*
  int numrows,numcols;

  numrows = CPXgetnumrows(env,lp);
  numcols = CPXgetnumcols(env,lp);
*/

  int      solstat;
  double   objval;

  ldieif(x==NULL || y==NULL || dj==NULL || pi==NULL,"Could not allocate memory for solution");

  solstat=0;
  objval=-3.0;

  status = CPXsolution (env, lp, &solstat, &objval, x, pi, y, dj);
  if (status) { lwarn("problem geting solution"); return(-4.0); }
//  ldieif(status,"Failed to obtain solution");

  switch(solstat){
   case CPX_STAT_OPTIMAL:
     return(objval);
//     return(1.0);
    break;
   case CPX_STAT_UNBOUNDED:
     lwarn("model is unbounded");
     return(-1.0);
    break;
   case CPX_STAT_INForUNBD:
     lwarn("model is infeasible or unbounded");
     return(-1.0);
    break;
   case CPX_STAT_INFEASIBLE:
     lwarn("model is infeasible");
     return(-1.0);
    break;
   case CPX_STAT_OPTIMAL_INFEAS:
     lwarn("model is optimal infeasible");
     return(-1.0);
    break;
   case CPX_STAT_ABORT_TIME_LIM:
     lwarn("model computation aborted due to time limit");
     return(-1.0);
    break;
   case CPX_STAT_ABORT_IT_LIM:
     lwarn("model computation aborted due to iterations limit");
    break;
   default:
     lwarn("model was not solved, unknown return code: "+estr(solstat));
     return(-1.0);
  }

  return(-2.0);
}

void esolver_cplex::write(const estr& filename)
{
  int status;
  status=CPXwriteprob(env, lp, filename._str , NULL);
  lwarnif(status,"unable to write problem to file: "+filename);
}


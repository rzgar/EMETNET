#include "enet.h"
#include "erandomwalk.h"

#include <eutils/logger.h>
#include <eutils/emain.h>

#include <signal.h>

estr outnet="randomw-default.net";
estr solver="esolver_clp";
int netsize=-1;
int strict=0;
int force_away=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
int niter=10000;
enet net;
enet net2;


erandomWalk *prw=0x00;

void save_state(int)
{
  efile f1("state.dat");
  f1.open("w");

  f1.write("strictViable="+estr(strict)+"\n");
  f1.write("periphery_only="+estr(periphery_only)+"\n");
  f1.write("mutate_transport"+estr(mutate_transport)+"\n");
  f1.write("internal_secretion="+estr(internal_secretion)+"\n");
  f1.write("iterations="+estr(niter)+"\n");
  if (prw)
    f1.write("net=eintarray("+intarr2str(prw->genotype)+")\n"); 
  f1.close();
  exit(0);
}


int emain()
{
  ldieif(argvc<4,"syntax: ./metnet-randomw [--mingenotypes <file>] [--outnet output.net] [--force_away <1|0>] [--rsize ref_size] [--niter iterations] <kegg.net> <genotype.net> <fluxbounds.flx>");


  estr mingenotypes="mingenotypes.dat";
	int nsample=1;

  epregister(mingenotypes);
  epregister(outnet);
  epregister(solver);
  epregister(netsize);
  epregister(strict);
  epregister(force_away);
  epregister(periphery_only);
  epregister(mutate_transport);
  epregister(internal_secretion);
  epregister(only_viable);
  epregister(niter);
	epregister(nsample);
  eparseArgs(argvc,argv);


  struct sigaction sa;
  sa.sa_handler=&save_state;
  sigaction(SIGINT,&sa,0x00);

  cout << "# environment: "<<argv[3] << endl;

  net.load(argv[1]); 
  cout << "# global network: "<<argv[1] << endl;
  cout << "# reactions (global): " << net.links.size() << endl;
  net.correct_malformed();
  cout << "# non-malformed reactions: " << net.links.size() << endl;

  net2.load(argv[2]);
  cout << "# initial network: "<<argv[2] << endl;
  cout << "# reactions (initial): " << net2.links.size() << endl;

  erandomWalk rw(net,solver,strict);
  prw=&rw; 

  rw.periphery_only=periphery_only;
  rw.mutate_transport=mutate_transport;
  rw.internal_secretion=internal_secretion;
  rw.only_viable=only_viable;
  rw.setRSize(netsize);

  rw.getEnv(argvc,argv);

  if (mingenotypes.len())
    rw.mingenotype.load(mingenotypes);

  cout << "# mingenotypes: " << rw.mingenotype.size() << endl;

  rw.load(net2);
  rw.calcPhenotype();

  rw.viablePhenotype=rw.phenotype;
  if (net2.info.findkey("phetarget")!=-1){
    net.info.add("phetarget",net2.info["phetarget"]);
    str2intarr(net2.info["phetarget"],rw.viablePhenotype);
    cout << "# using phetarget from initial network file!"<<endl;
  }

  cout << "# viablePhenotype: " << intarr2str(rw.viablePhenotype) << endl;

  cout << "# strictViable: "<<strict<<endl;
  cout << "# force_away: "<< force_away<<endl;
  cout << "# periphery_only: "<<rw.periphery_only<<endl;
  cout << "# mutate_transport: "<<rw.mutate_transport<<endl;
  cout << "# internal_secretion: "<<rw.internal_secretion<<endl;
  cout << "# only_viable: "<<rw.only_viable<<endl;
  cout << "# phenotype: "<< intarr2str(rw.phenotype)<<endl;

  cout << "# iterations: " << niter<<endl;

  rw.calcSuperess();
//  rw.load(net2);
//  rw.findmin();

//  rw.runmin(net2,niter);
  int i;
  rw.load(net);
  for (i=0; i<nsample; ++i) {
    rw.findmin();
	  if (outnet.len())
		net.saveactive(outnet+"-"+i+".net");
	}
//  rw.mingenotype.save(mingenotypes);

  return(0);
}

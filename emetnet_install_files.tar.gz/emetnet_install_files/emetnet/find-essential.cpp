#include "enet.h"
#include "erandomwalk.h"

#include <eutils/emain.h>

estr intarr2str(const eintarray& arr);
enet net;
int emain()
{
	getLogger()->level=6;
  ldieif (argvc<3,"syntax: ./find-essential [-print_noness 1|0] <network.net> <env.flx>"); 

  estr solver="esolver_clp";
  int internal_secretion=0;
	int print_noness=0;
  estr obj="Biomass";
  epregister(obj);
  epregister(solver);
  epregister(internal_secretion);
	epregister(print_noness);
  eparseArgs(argvc,argv);

  net.load(argv[1]);
  net.correct_malformed();

//  cout << "# solver: "<<solver<<endl;
//  cout << "# internal_secretion: "<<internal_secretion<<endl;
  erandomWalk rw(net,solver,0);
  rw.internal_secretion=internal_secretion;
  rw.getEnv(argvc,argv);
	int i;		
  if (obj.len()){
    i=net.links.findkey(obj);
    ldieif(i==-1,"objective reaction: "+obj+" not found");
    rw.setobjective(i);
    cout << "# objective: " << net.links[i].info[0] << endl;
  }else{
    cout << "# objective: " << net.links[0].info[0] << endl;
  }

  int transport_count,ess_count, noness_count;
  transport_count=0;
	ess_count=noness_count=0;
	eintarray essential, nonessential;
  for (i=0; i<net.links.size(); ++i){
    if (net.links[i].transport)
      ++transport_count;
			essential.add(0);
			nonessential.add(0);
  }


  rw.calcPhenotype();
	rw.viablePhenotype=rw.phenotype;

  cout << "# Network: "<<argv[1]<<endl;
  cout << "# Environment: "<<argv[1]<<endl;
  cout << "# Total reactions: "<<net.links.size()-1<<endl;
//  cout << "# Transport reactions: "<<transport_count<<endl;

  for (i=0; i<rw.phenotype.size(); ++i){
    cout << "# Growth Rate" << ": " << efile(rw.solvers.keys(i)).basename() <<": "<< rw.growthRate[i] << endl;
  }
  cout << "# Essential reactions: "<< endl;
	
	for (i=1; i<net.links.size(); ++i){
    //if (net.links[i].transport) continue;
		rw.disable(i);
		rw.calcPhenotype();
		if (!rw.isViable()){
			essential[i]=1;
			++ess_count;
			cout << net.links[i].info[0] << endl;
		}
		else {
			nonessential[i]=1;
			++noness_count;
		}
		rw.activate(i);
		rw.calcPhenotype();
	}
  cout << "# Number of essential reactions: " << ess_count << endl;

	if (print_noness==1) {
	  cout << "# Nonssential reactions: "<< endl;
		for (i=1; i<net.links.size(); ++i){
			if (nonessential[i]==1) {cout << net.links[i].info[0] << endl;}
		}
		cout << "# Number of nonessential reactions: " << noness_count << endl;
	}
/*
cout << "# Nonessential reactions: "<< endl;
	
	for (i=1; i<=net.links.size(); ++i){
    //if (net.links[i].transport) continue;
		if (essential[i]==0){
			cout << net.links[i].info[0] << endl;
			
		}
	}*/
  return(0);
}


#include "enet.h"
#include "erandomwalk.h"

#include <eutils/logger.h>
#include <eutils/emain.h>

#include <signal.h>

estr solver="esolver_clp";
int netsize=-1;
enet net;
enet net2;


erandomWalk *prw=0x00;
/*
void save_state(int)
{
  efile f1("state.dat");
  f1.open("w");

  f1.write("strictViable="+estr(strict)+"\n");
  f1.write("periphery_only="+estr(periphery_only)+"\n");
  f1.write("mutate_transport"+estr(mutate_transport)+"\n");
  f1.write("internal_secretion="+estr(internal_secretion)+"\n");
  f1.write("iterations="+estr(niter)+"\n");
  if (prw)
    f1.write("net=eintarray("+intarr2str(prw->genotype)+")\n"); 
  f1.close();
  exit(0);
}
*/

int emain()
{
  ldieif(argvc<3,"syntax: ./metnet-printVector <kegg.net> <genotype.net> ");

  epregister(solver);
  epregister(netsize);
  eparseArgs(argvc,argv);

  struct sigaction sa;
//  sa.sa_handler=&save_state;
  sigaction(SIGINT,&sa,0x00);
  net.load(argv[1]); 


/*  cout << "# environment: "<<argv[3] << endl;
  cout << "# global network: "<<argv[1] << endl;
  cout << "# reactions (global): " << net.links.size() << endl;
  net.correct_malformed();
  cout << "# non-malformed reactions: " << net.links.size() << endl;
  cout << "# initial network: "<<argv[2] << endl;
  cout << "# reactions (initial): " << net2.links.size() << endl;
*/
  net2.load(argv[2]);
  cout << "# reactions (initial): " << net2.links.size() << endl;

  erandomWalk rw(net,solver,0);
  prw=&rw; 

/*  rw.periphery_only=periphery_only;
  rw.mutate_transport=mutate_transport;
  rw.internal_secretion=internal_secretion;
  rw.only_viable=only_viable;
*/
  rw.setRSize(netsize);
  rw.getEnv(argvc,argv);

  rw.load(net2);


  cout << intarr2str(rw.genotype)<<endl;
	int i, sizevec;
	eintarray vec;
	sizevec=0;
	for (i=26; i<rw.net->links.size(); ++i) {
		vec.add(0);	
		++sizevec;
	}
	cout << sizevec << endl;
	for (i=26; i<rw.genotype.size(); ++i) {
		cout <<  rw.net->links[i].info[0] << " : " << rw.genotype[i] << endl;		
		vec[i]=rw.genotype[i];
	}

	cout << intarr2str(vec) << endl;
  return(0);
}

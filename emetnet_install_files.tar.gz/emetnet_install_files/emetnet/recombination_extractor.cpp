#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <vector>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
using std::vector;


double D=-1;
double d=-1;
int carbon_source=-1;
int emain()
{
ldieif(argvc<6,"syntax: ./recombination_extractor <inputfile> <outputfile> -D <x> -d <y> -carbon_source <z>" );
epregister(D);
epregister(d);
epregister(carbon_source);
eparseArgs(argvc,argv);
/////////////////////////////////////////////////////////////////////////////////
double x=D;
double y=d;
int z=carbon_source;
estr infile1=argv[1];
estr infile2=infile1+"_phen";
estr outfile=argv[2];
efile fin1;
efile fin2;
efile fout;
estr str1;
estr str2;
estrarray parts;
double phenotype[500][50];
for (int i=0;i<500;i++){
     for (int j=0;j<50;j++){phenotype[i][j]=0;}
}
double gain_loss[500][4];
for (int i=0;i<500;i++){
     for (int j=0;j<4;j++){gain_loss[i][j]=0;}
}
int count1=0;
int count2=0;
fin1.open(infile1,"r");
fin2.open(infile2,"r");

while (fin1.readln(str1)) {
      parts=str1.explode(" ");
      for (int i=0; i<parts.size();++i){int gg1=parts[i].i();double gg2=(double) (gg1); gain_loss[count1][i]=gg2;}
      count1++;
}
fin1.close();

while (fin2.readln(str2)) {
      parts=str2.explode(" ");
      if (count2>1){for (int i=0; i<parts.size();++i){int gg1=parts[i].i();double gg2=(double) (gg1);phenotype[count2-2][i]=gg2;}}
      count2++;
}
fin2.close();

double robust_gain=0;
double robust_loss=0;
double gain=0;
double loss=0;
double counter=0;
for (int i=0;i<500;i++){
     gain=gain+gain_loss[i][0];
     loss=loss+gain_loss[i][2];
     if (phenotype[i][z]==1){robust_gain=robust_gain+gain_loss[i][0];robust_loss=robust_loss+gain_loss[i][2];counter++;}
}
double ave_robustness=(double) (counter/500);
double ave_gain=(double) (gain/500);
double ave_loss=(double) (loss/500);
double ave_robust_gain=(double) (robust_gain/counter);
double ave_robust_loss=(double) (robust_loss/counter);

estr D_str=D;
estr d_str=d;
estr ave_robustness_str=ave_robustness;
estr ave_gain_str=ave_gain;
estr ave_loss_str=ave_loss;
estr ave_robust_gain_str=ave_robust_gain;
estr ave_robust_loss_str=ave_robust_loss;


cout<<"/////////////////////////////////"<<endl;
cout<<D_str<<endl;
cout<<d_str<<endl;
cout<<ave_robustness_str<<endl;
cout<<ave_gain_str<<endl;
cout<<ave_loss_str<<endl;
cout<<ave_robust_gain_str<<endl;
cout<<ave_robust_loss_str<<endl;
cout<<"/////////////////////////////////"<<endl;


fout.open(outfile,"a");
fout.write(D_str+" "+d_str+" "+ave_robustness_str+" "+ave_gain_str+" "+ave_loss_str+" "+ave_robust_gain_str+" "+ave_robust_loss_str+"\n");
fout.close();
return(0);
}

#include "enet.h"
#include "erandomwalk.h"

#include <eutils/logger.h>
#include <eutils/emain.h>

#include <signal.h>

estr solver="esolver_clp";
int strict=0;
int mutate_transport=0;
int internal_secretion=0;
int savenet=0;
estr outnet="allactive.net";

enet net;

erandomWalk *prw=0x00;

int emain()
{
  ldieif(argvc<2,"syntax: ./metnet-idblocked <network.net> <fluxbounds.flx>");

  epregister(solver);
  epregister(strict);
  epregister(mutate_transport);
  epregister(internal_secretion);
	epregister(savenet);
	epregister(outnet);
  eparseArgs(argvc,argv);

  cout << "# environment: "<<argv[2] << endl;

  net.load(argv[1]); 
  cout << "# network: "<<argv[1] << endl;
  cout << "# reactions : " << net.links.size() << endl;
  net.correct_malformed();
  cout << "# non-malformed reactions: " << net.links.size() << endl;
  erandomWalk rw(net,solver,strict);
  prw=&rw; 

  rw.mutate_transport=mutate_transport;
  rw.getEnv(argvc,argv);
	rw.calcPhenotype();

  rw.viablePhenotype=rw.phenotype;

  cout << "# viablePhenotype: " << intarr2str(rw.viablePhenotype) << endl;
  cout << "# strictViable: "<<strict<<endl;
  cout << "# mutate_transport: "<<rw.mutate_transport<<endl;
	cout << "# phenotype: "<< intarr2str(rw.phenotype)<<endl;

	double fluxmin,fluxmax;
	eintarray bluni;
	int i=0;
	int r=0;
  for (i=0; i<rw.net->links.size(); ++i) {
		bluni.add(0);
	}
	
	int transport=0;
  for (i=0; i<rw.net->links.size(); ++i){
    if (rw.net->links[i].transport)
      ++transport;
  }
  cout << "# transport reactions: " << transport << endl;
	
	cout << "# Finding blocked reactions ... " << endl;
		for (i=1; i<rw.net->links.size(); ++i) {
			if (!rw.net->links[i].transport)	{
				if (rw.fluxVar(i,fluxmin,fluxmax)) {bluni[i]=0;} 
				else {
					bluni[i]=1; ++r;
//					cout << i << endl;
					cout << "# blocked rxn " << argv[1] <<": " << rw.net->links[i].info[0] << " " << i << " ";
  				cout << " min: " << fluxmin <<" max: " << fluxmax << endl;
					if (savenet==1) {rw.disable(i);}
				}
			}
		}
		if (savenet==1) {
			rw.calcPhenotype();
			if (!rw.isViable()) {ldie("something wrong. Network not viable after removing blocked reactions");}
			else {
				net.saveactive(outnet);
			}
		}
		cout << " number of bl rxns: " << r << endl;

  return(0);
}

#include "enet.h"
#include "esolver.h"
#include <eutils/emain.h>
#include <eutils/eregexp.h>
#include <fstream>
#include <iomanip>
#include <eutils/logger.h>
#include <eutils/emain.h>
#include "erandomwalk.h"
#include <eutils/eheap.h>
#include <algorithm>
#include <eutils/ernd.h>
estr solver="esolver_clp";

erandomWalk *prw=0x00;

//esolver_clp solver;

int emain()
{
  ldieif(argvc<5,"syntax: ./metnet-recomb [--recomb 0-1] [--csource 1-50] <kegg.net> <network1.net> <network2.net> <env.flx> [env2.flx env3.flx ...]");  
  
	//estr solver="esolver_clp";
  epregister(solver);
  
	estr outnet="recomb-output.net";
  epregister(outnet);

  int periphery_only=0;
  epregister(periphery_only);

  int internal_secretion=0;
  epregister(internal_secretion);

  int mutate_transport=0;
  epregister(mutate_transport);
	
	int csource=0;
	epregister(csource);

	int recomb=0;
	epregister(recomb);

  eparseArgs(argvc,argv);

  int niter;
  niter=0;

  ldieif(recomb==0,"Number of reactions to be recombined is 0, set --recomb");

//   if (csource==0) {lwarn("no csource specified, viablePhenotype=phe(parent2) ");	}

// load the global network/universe
	enet net; 
  net.load(argv[1]); 
  cout << "# global network: "<<argv[1] << endl;
	cout << "# reactions (global): " << net.links.size() << endl;
	cout << "# reactions to be recombined: " << recomb << endl;
  net.correct_malformed();

//Initiate rw object/method
	erandomWalk rw(net,solver,0);
  prw=&rw; 
	rw.getEnv(argvc,argv);
	

	int i, r, j, gnet1size, randnum;
	eintarray commonrxns,	addedrxns,tmp;
	double tsize = 0.0;

  for (i=0; i<rw.net->links.size(); ++i) {
		commonrxns.add(0);
		addedrxns.add(0);
	}
	
//Counting the number of transport reactions
	double numtransport=0.0;
  for (i=1; i<rw.net->links.size(); ++i){
    if (rw.net->links[i].transport) {
//		cout << rw.net->links[i].info[0] << endl;
//			transportr[i]=1;
      ++numtransport;
		}
  }
  cout << "# transport reactions: " << numtransport << endl;

//////////////////////---------------------////////////////////////////////////////////////////


// Load the first network
  enet net2;
  net2.load(argv[2]);
	rw.load(net2);
	rw.calcPhenotype();
	rw.viablePhenotype=rw.phenotype;
  cout << "# first parent: "<<argv[2] << endl;
  cout << "# reactions (initial): " << net2.links.size() << endl;
	cout << "# phenotype of the first network: " << rw.printPhenotype() << endl;
  cout << "# viablePhenotype: " << intarr2str(rw.viablePhenotype) << endl;
	estr phe_parent1 = intarr2str(rw.phenotype);
	eintarray gnet1 = rw.genotype;	


//................................ work with network 1 done ................................//

// Load the second network
	cout << endl;
	cout << "# Loading the second network" << endl;
  enet net3;
  net3.load(argv[3]);
	rw.load(net3);
	rw.calcPhenotype();

  cout << "# second parent: "<<argv[3] << endl;
  cout << "# reactions (initial): " << net3.links.size() << endl;
	cout << "# phenotype of the second network: " << rw.printPhenotype() << endl;

	
	ldieif(csource>0 && rw.phenotype[csource-1]==0,"The specified csource does not support growth of parent two. Specify correct csource [1-50]");

	if (csource>0 && rw.phenotype[csource-1]==1) {
		for (i=0; 1<rw.viablePhenotype.size(); ++i) {rw.viablePhenotype[i]=0;}

		rw.viablePhenotype[csource-1]=1;
		cout << "# Setting viable phenotype to the specified carbon source, number: " << csource << endl;
	  cout << "# viablePhenotype: " << intarr2str(rw.viablePhenotype) << endl;
	}
	if (csource==0) {rw.viablePhenotype=rw.phenotype; cout << "no csource specified, viablePhenotype=phe(parent2) " <<endl;}
	
	
	eintarray gnet2 = rw.genotype;
	estr phe_parent2 = intarr2str(rw.phenotype);
	tsize = net3.links.size();

//................................ work with network 2 done ................................//



// Finding the common reactions between net1 and net2 
	int creactions=0;
	for (i=0; i<rw.genotype.size(); ++i) {
		if	(gnet1[i]==1 && gnet2[i]==1 && rw.net->links[i].transport==false)	{
			commonrxns[i] = 1; 
			++creactions;
		}
	}
	cout << "# Number of common reactions: " << creactions << endl;

// Calculating distance between the two networks
	double gendist=0.0;
	gendist=gendistance(gnet2,gnet1,&rw); 

	gendist=((double)(tsize - numtransport) * (double) gendist);
	int numdiffrxns1 = 0;
	int numdiffrxns2 = 0;
	
//	int recomb = gendist*dist;
	

  for (i=1; i<gnet1.size(); ++i){  // i starts in 1 (instead of 0) because we dont count the objective function as a reaction
		if (rw.net->links[i].transport==false) {
    	if (gnet1[i]-gnet2[i]==-1) ++numdiffrxns1;
			if (gnet1[i]-gnet2[i]==1) ++numdiffrxns2;
		}
  }
  cout << "# Distance between net1 and net2 for cytoplasmic reactions: " << gendist << " " << numdiffrxns1 << " " << numdiffrxns2 << endl;
//  cout << "# Number of reactions to be recombined: " << recomb << endl;


// recombination - mutating genotype 2

	for (i=1; i <= recomb; ++i) {
		while (1) {
				randnum=(int)(ernd.uniform() * rw.net->links.size());
				if (rw.genotype[randnum]==0 && gnet1[randnum]==1 && rw.net->links[randnum].transport==false) {break;}
			}
		rw.activate(randnum);	
		addedrxns[randnum]=1;
//		cout << "# Activating reactions, total reactions "  << rw.acount << endl;
	}
	cout << "# Added reactions from parent 1, total reactions " << rw.acount << endl;


	for (i=1; i <= recomb; ++i) {
		while (1) {
				randnum=(int)(ernd.uniform() * rw.net->links.size());
//				if (rw.genotype[randnum]==1 && commonrxns[randnum]==0 && addedrxns[randnum]==0 && rw.net->links[randnum].transport==false) {break;}
				if (rw.genotype[randnum]==1 && rw.net->links[randnum].transport==false) {break;}
			}
		rw.disable(randnum);
//		cout << "# Disabling reactions, total reactions "  << rw.acount << endl;
	}
	cout << "# Removed reactions from genotype, total reactions " << rw.acount << endl;

	rw.calcPhenotype();
	cout << "# phenotype of the progeny: " << rw.printPhenotype() << endl;
	
	if (rw.isViable()) {
		estr phe_progeny = intarr2str(rw.phenotype);
	  net.info.add("phe_parent1",phe_parent1);
  	net.info.add("phe_parent2",phe_parent2);
	  net.info.add("phe_progeny",phe_progeny);
  	net.saveactive(outnet);
	}
  return(0);

}

//
#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>

int emain() {
//  ldieif(argvc<2,"syntax: ./classifier <inputfilename.dat>");
	estr sizestr=argv[1];
	epregister(sizestr);
	estrarray parts;
	estr str;
  eparseArgs(argvc,argv);
	efile f;
	f.open(argv[1],"r");
	int tmp;
  int intcounter,intcounter1,intcounter2,intcounter3,intcounter4,intcounter5;
  intcounter=0;
  intcounter1=0;
  intcounter2=0;
  intcounter3=0;
  intcounter4=0;
  intcounter5=0;
	while (f.readln(str)) {			// While the file isn't finished, read line by line
  	parts=str.explode(" ");		// cut the string based on delimiter, here a space, and assign the resulting fields into an array called "parts"
    tmp = parts[0].i();						// convert index j in parts to integer and assign to integer called tmp 
    intcounter++;
    if (tmp==1){
       intcounter1++;
    }	
    if (tmp==2){
       intcounter2++;
       printf("group2:%i\n",intcounter);
    }	
    if (tmp==3){
		   intcounter3++;
		   printf("group3:%i\n",intcounter);
    }	
    if (tmp==4){
       intcounter4++;
       printf("group4:%i\n",intcounter);
    }	
    if (tmp==5){
       intcounter5++;
       printf("group5:%i\n",intcounter);
    }								
	}
   printf("number of group 1:%i\n",intcounter1);
   printf("number of group 2:%i\n",intcounter2);
   printf("number of group 3:%i\n",intcounter3);
   printf("number of group 4:%i\n",intcounter4);
   printf("number of group 5:%i\n",intcounter5);
}


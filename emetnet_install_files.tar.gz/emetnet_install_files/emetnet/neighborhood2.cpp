#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <vector>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
using std::vector;


// array that will store pre-computed number of "on" bits in a 16bit value
char precomp_count_16bits[0x1u<<16];
// function to compute how many "on" bits exist in a 32bit (int) value
inline char count_bits(unsigned int i)
{
  int cbits=0;
  while (i){
    cbits += i&0x1u;
    i>>=1;
  }
  return(cbits);
}

// function that needs to be called at the beginning of a program (before any other code) to initialize the array with pre-computed values (bits_in_16bits)
void init_precomp_count()
{
  unsigned int i;
// iterates through all possible 16 bit values and initializes the array to the number of "on" bits in that value
  for (i=0; i<0x1u<<16; ++i)
    precomp_count_16bits[i]=count_bits(i);
}

// function to compute how many "on" bits exist in a 64bit (long int) value using the pre-computed table. Basically this takes the first the 64 bits and splits it into 16 + 16 + 16 +16. For each of those 16 bits sums the count using the table to look them up. 
int count_bits16(unsigned long i)
{
  return( precomp_count_16bits[i & 0xfffful] + precomp_count_16bits[(i>>16) & 0xfffful] +precomp_count_16bits[(i>>32) & 0xfffful] + precomp_count_16bits[(i>>48) & 0xfffful] );
}

// This function will return the hamming distance between two networks represented by 64bit values
inline int mnets_dist(unsigned long x,unsigned long y)
{
  return(count_bits16(x^y));
}

//Initialization stuff
estr solver="esolver_clp";
int netsize=-1;
int strict=0;
int force_away=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
enet net;
erandomWalk *prw=0x00;
int sample_size=0;
int genotype_size=0;
int carbon_source=-1;

int emain()
{

ldieif(argvc<8,"syntax: ./neighborhood2  <universe.net>  <inputfile1> <inputfile2> <outputfile> -sample_size <x> -genotype_size <y> -carbon_sourse <index> <fluxbounds.flx>");
epregister(solver);
epregister(sample_size);
epregister(genotype_size);
epregister(carbon_source);
eparseArgs(argvc,argv);
//Must be done rw stuff
net.load(argv[1]); 
net.correct_malformed();
erandomWalk rw(net,solver,strict);
prw=&rw; 
rw.periphery_only=periphery_only;
rw.mutate_transport=mutate_transport;
rw.internal_secretion=internal_secretion;
rw.only_viable=only_viable;
rw.setRSize(netsize);
rw.getEnv(argvc,argv);
rw.load(net);
rw.calcPhenotype();
rw.viablePhenotype=rw.phenotype;

//Initialization
estr outfile=argv[4];
int x=sample_size;
int y=genotype_size;
int z=45-y;
int index=carbon_source;
efile fin1;
efile fin2;
efile fout;
estr str1;
estr str2;
estrarray parts1;
estrarray parts2;
int i;
int j;
int counter1=0;
int counter2=0;
int tmp1;
int tmp2;

init_precomp_count();  // initialize the precomp_count array
unsigned long allnetworks1[x];  
unsigned long allnetworks2[x];
 
unsigned long genbits=0x00ul; // start with a 64bit value representing the network with all bits set to zero

int absent1[x][z];
for (i=0; i<x; ++i){
    for (j=0; j<z; ++j){
        absent1[i][j]=0;
    }
}

int absent2[x][z];
for (i=0; i<x; ++i){
    for (j=0; j<z; ++j){
        absent2[i][j]=0;
    }
}

int present1[x][y];
for (i=0; i<x; ++i){
    for (j=0; j<y; ++j){
        present1[i][j]=0;
    }
}

int present2[x][y];
for (i=0; i<x; ++i){
    for (j=0; j<y; ++j){
        present2[i][j]=0;
    }
}

//Reading input files and saving in the corresponding arrays

fin1.open(argv[2],"r");
while (fin1.readln(str1)) {
      parts1=str1.explode(" ");
      genbits=0x00ul;
      for (i=0; i<parts1.size(); ++i){
      genbits|=(0x01ul<<(parts1[i].i()-1));
			tmp1 =parts1[i].i();
      absent1[counter1][i]=tmp1;
      }
      allnetworks1[counter1]=genbits;
      counter1=counter1++;
}
fin1.close();

fin2.open(argv[3],"r");
while (fin2.readln(str2)) {
      parts2=str2.explode(" ");
      genbits=0x00ul;
      for (i=0; i<parts2.size(); ++i){
      genbits|=(0x01ul<<(parts2[i].i()-1));
			tmp2 =parts2[i].i();
      absent2[counter2][i]=tmp2;
      }
      allnetworks2[counter2]=genbits;
      counter2=counter2++;
}
fin2.close();

int temp_vec1[x][45];
for (i=0;i<x;++i){
    for (j=0; j<45; ++j){
        temp_vec1[i][j]=1;
    }
}

int temp_vec2[x][45];
for (i=0;i<x;++i){
    for (j=0; j<45; ++j){
        temp_vec2[i][j]=1;
    }
}

for (i=0; i<x; ++i){
    for (j=0;j<z;++j){
        temp_vec1[i][(absent1[i][j])]=0;
    }
}


for (i=0; i<x; ++i){
    for (j=0;j<z;++j){
        temp_vec2[i][(absent2[i][j])]=0;
    }
}

for (i=0; i<x; ++i){
    int counted1=0;
    int counted2=0;
    for (j=0;j<45;++j){
        if (temp_vec1[i][j]==1){
           present1[i][counted1]=j;
           counted1=counted1++;
        }
        if (temp_vec2[i][j]==1){
           present2[i][counted2]=j;
           counted2=counted2++;
        }
    }
}     
       
/////////////////////////////////////////////////////// Neighborhood analysis ///////////////////////////////////////////////////////////////////////////
int k;
int l;
int m;

fout.open(outfile,"a");

for (i=0;i<x;++i){
        //Initialization
        int semi_final1[z];for (m=0;m<z;++m){semi_final1[m]=0;}
        for (m=0;m<z;++m){semi_final1[m]=absent1[i][m];}
        int semi_final2[z];for (m=0;m<z;++m){semi_final2[m]=0;}
        for (m=0;m<z;++m){semi_final2[m]=absent2[i][m];}
        //processing the neighborhood of the first genotype
        int f_vector1[1024];for (m=0;m<1024;++m){f_vector1[m]=0;}
        for (k=0;k<z;++k){
            for (l=0;l<y;++l) {
                int final1[z];for (m=0;m<z;++m){final1[m]=0;}
                for (m=0;m<z;++m){final1[m]=semi_final1[m];}
                final1[k]=present1[i][l];
                for (m=0;m<z;++m){int tmp=final1[m]+26;rw.disable(tmp);}
                rw.calcPhenotype();
                eintarray f_temp1=rw.phenotype;
                for (m=0;m<z;++m){int tmp=final1[m]+26;rw.activate(tmp);}
                //binary conversion
                if (f_temp1[index]==0)// to select genotypes outside of the original genotype network
                {int ph=0;
                for (m=0;m<10;++m){ph+=(pow(2,m)*f_temp1[m]);}
                f_vector1[ph]=1;}
            }
        } 
        //processing the neighborhood of the second genotype
        int f_vector2[1024];for (m=0;m<1024;++m){f_vector2[m]=0;}
        for (k=0;k<z;++k){
            for (l=0;l<y;++l) {
                int final2[z];for (m=0;m<z;++m){final2[m]=0;}
                for (m=0;m<z;++m){final2[m]=semi_final2[m];}
                final2[k]=present2[i][l];
                for (m=0;m<z;++m){int tmp=final2[m]+26;rw.disable(tmp);}
                rw.calcPhenotype();
                eintarray f_temp2=rw.phenotype;
                for (m=0;m<z;++m){int tmp=final2[m]+26;rw.activate(tmp);}
                //binary conversion
                if (f_temp2[index]==0)// to select genotypes outside of the original genotype network
                {int ph=0;
                for (m=0;m<10;++m){ph+=(pow(2,m)*f_temp2[m]);}
                f_vector2[ph]=1;}
            }
        }  
       //final outputting
       double p1=0;//unique for p1
       double p2=0; //unique for p2
       double p12=0;//common for both
       for (m=0;m<1024;++m){
           if (f_vector1[m]==1) {if (f_vector2[m]==1){p12++;}
                                 else {p1++;}}
           else if (f_vector1[m]==0) {if (f_vector2[m]==1){p2++;}}          
       }
       int distance = mnets_dist(allnetworks1[i],allnetworks2[i]); //distance is defined
       double p_d=(double) distance;
       estr tempo1 = p1;
       estr tempo2 = p2;
       estr tempo12 = p12;
       estr tempo_d = p_d;
			 fout.write(tempo1+" "+tempo2+" "+tempo12+" "+tempo_d+"\n");      
              
  }

fout.close();
return(0);
}


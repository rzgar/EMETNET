#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <vector>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
using std::vector;
// array that will store pre-computed number of "on" bits in a 16bit value
char precomp_count_16bits[0x1u<<16];
// function to compute how many "on" bits exist in a 32bit (int) value
inline char count_bits(unsigned int i)
{
  int cbits=0;
  while (i){
    cbits += i&0x1u;
    i>>=1;
  }
  return(cbits);
}
// function that needs to be called at the beginning of a program (before any other code) to initialize the array with pre-computed values (bits_in_16bits)
void init_precomp_count()
{
  unsigned int i;
// iterates through all possible 16 bit values and initializes the array to the number of "on" bits in that value
  for (i=0; i<0x1u<<16; ++i)
    precomp_count_16bits[i]=count_bits(i);
}

// function to compute how many "on" bits exist in a 64bit (long int) value using the pre-computed table. Basically this takes the first the 64 bits and splits it into 16 + 16 + 16 +16. For each of those 16 bits sums the count using the table to look them up. 
int count_bits16(unsigned long i)
{
  return( precomp_count_16bits[i & 0xfffful] + precomp_count_16bits[(i>>16) & 0xfffful] +precomp_count_16bits[(i>>32) & 0xfffful] + precomp_count_16bits[(i>>48) & 0xfffful] );
}

// This function will return the hamming distance between two networks represented by 64bit values
inline int mnets_dist(unsigned long x,unsigned long y)
{
  return(count_bits16(x^y));
}

//Initialization stuff
int size1=0;
int size2=0;

int emain()
{ldieif(argvc<7,"syntax: ./neighborhood_distance7   <inputfile1> <inputfile2>  <outputfile1> <outputfile2> -size1 <x> -size2 <y> ");

epregister(size1);
epregister(size2);

eparseArgs(argvc,argv);

//Initialization
int x=size1;
int y=size2;
init_precomp_count();  // initialize the precomp_count array
 

unsigned long genbits=0x00ul; // start with a 64bit value representing the network with all bits set to zero

//Reading input files and saving in the corresponding arrays

efile fin1;
efile fin2;
efile fout;

estr str;

estr sizestr1=argv[1];
estr sizestr2=argv[2];
estr sizestr3=argv[3];
estr sizestr4=argv[4];

estr filename1="/home/rzgar/results/exaptation_results/giant_components/connectedness/complement/"+sizestr1;
estr filename2="/home/rzgar/results/exaptation_results/giant_components/connectedness/complement/"+sizestr2;
estr filename_out="/home/rzgar/results/exaptation_results/giant_components/connectedness/complement/combined/a___"+sizestr3+"___"+sizestr4;

estrarray parts1;
estrarray parts2;
double s=100;
if (x>y){
    int f1=y/500000;
    int f2=y%500000;
    double fd1=(double) f1;
    double fd2=(double) f2;
    estr fs1=fd1;
    estr fs2=fd2;
    cout<<fs1<<endl;
    cout<<fs2<<endl;
    /////////////////// step 1 ///////////////////////////
    for (int cc=0;cc<f1;++cc){
         int counter2=0;
         unsigned long allnetworks1[500000]; 
         cout<<"hapa1"<<endl;
         fin2.open(filename2,"r");
         while (fin2.readln(str)) {
                parts2=str.explode(" ");
                genbits=0x00ul;
                for (int i=0; i<parts2.size(); ++i){genbits|=(0x01ul<<(parts2[i].i()-1));}               
                if (counter2>=(500000*cc)){allnetworks1[(counter2-(500000*cc))]=genbits;}
                counter2++;
                if (counter2>=(500000*(cc+1))){break;}
         }
         fin2.close();
         cout<<filename_out<<endl;
         fin1.open(filename1,"r");
         cout<<"hapa2"<<endl;
         while (fin1.readln(str)) {
                parts1=str.explode(" ");
                genbits=0x00ul;
                for (int i=0; i<parts1.size(); ++i){genbits|=(0x01ul<<(parts1[i].i()-1));}
                for (int k=0; k<500000; ++k){
                     int distance=0; 
                     distance = mnets_dist(allnetworks1[k],genbits); //distance is defined
                     if (distance==2) {s=2;break;}
                     if (distance<s){s=distance;}
                }
                if (s==2){break;}     
         }
         fin1.close();
         if (s==2){break;}
    }
    /////////////////// step 2 ///////////////////////////
    if (s>2){
        int counter2=0;
        unsigned long allnetworks1[f2]; 
        cout<<"hapa1"<<endl;
        fin2.open(filename2,"r");
        while (fin2.readln(str)) {
               parts2=str.explode(" ");
               genbits=0x00ul;
               for (int i=0; i<parts2.size(); ++i){genbits|=(0x01ul<<(parts2[i].i()-1));}               
               if (counter2>=(500000*f1)){allnetworks1[(counter2-(500000*f1))]=genbits;}
               counter2++;
        }
        fin2.close();
        cout<<filename_out<<endl;
        fin1.open(filename1,"r");
        cout<<"hapa2"<<endl;
        while (fin1.readln(str)) {
               parts1=str.explode(" ");
               genbits=0x00ul;
               for (int i=0; i<parts1.size(); ++i){genbits|=(0x01ul<<(parts1[i].i()-1));}
               for (int k=0; k<f2; ++k){
                    int distance=0; 
                    distance = mnets_dist(allnetworks1[k],genbits); //distance is defined
                    if (distance==2) {s=2;break;}
                    if (distance<s){s=distance;}
               }
               if (s==2){break;}     
       }
       fin1.close();
    }
}


else {
    int f1=x/500000;
    int f2=x%500000;
    double fd1=(double) f1;
    double fd2=(double) f2;
    estr fs1=fd1;
    estr fs2=fd2;
    cout<<fs1<<endl;
    cout<<fs2<<endl;
    /////////////////// step 1 ///////////////////////////
    for (int cc=0;cc<f1;++cc){
         int counter2=0;
         unsigned long allnetworks1[500000]; 
         cout<<"hapa1"<<endl;
         fin1.open(filename1,"r");
         while (fin1.readln(str)) {
                parts2=str.explode(" ");
                genbits=0x00ul;
                for (int i=0; i<parts2.size(); ++i){genbits|=(0x01ul<<(parts2[i].i()-1));}               
                if (counter2>=(500000*cc)){allnetworks1[(counter2-(500000*cc))]=genbits;}
                counter2++;
                if (counter2>=(500000*(cc+1))){break;}
         }
         fin1.close();
         cout<<filename_out<<endl;
         fin2.open(filename2,"r");
         cout<<"hapa2"<<endl;
         while (fin2.readln(str)) {
                parts1=str.explode(" ");
                genbits=0x00ul;
                for (int i=0; i<parts1.size(); ++i){genbits|=(0x01ul<<(parts1[i].i()-1));}
                for (int k=0; k<500000; ++k){
                     int distance=0; 
                     distance = mnets_dist(allnetworks1[k],genbits); //distance is defined
                     if (distance==2) {s=2;break;}
                     if (distance<s){s=distance;}
                }
                if (s==2){break;}     
         }
         fin1.close();
         if (s==2){break;}
    }
    /////////////////// step 2 ///////////////////////////
    if (s>2){
        int counter2=0;
        unsigned long allnetworks1[f2]; 
        cout<<"hapa1"<<endl;
        fin1.open(filename1,"r");
        while (fin1.readln(str)) {
               parts2=str.explode(" ");
               genbits=0x00ul;
               for (int i=0; i<parts2.size(); ++i){genbits|=(0x01ul<<(parts2[i].i()-1));}               
               if (counter2>=(500000*f1)){allnetworks1[(counter2-(500000*f1))]=genbits;}
               counter2++;
        }
        fin1.close();
        cout<<filename_out<<endl;
        fin2.open(filename2,"r");
        cout<<"hapa2"<<endl;
        while (fin2.readln(str)) {
              parts1=str.explode(" ");
              genbits=0x00ul;
              for (int i=0; i<parts1.size(); ++i){genbits|=(0x01ul<<(parts1[i].i()-1));}
              for (int k=0; k<f2; ++k){
                   int distance=0; 
                   distance = mnets_dist(allnetworks1[k],genbits); //distance is defined
                   if (distance==2) {s=2;break;}
                   if (distance<s){s=distance;}
              }
              if (s==2){break;}     
       }
       fin2.close();
   }
}
//outputing
estr intstr=s;
fout.open(filename_out,"a");
fout.write(intstr+"\n");
fout.close();
}  

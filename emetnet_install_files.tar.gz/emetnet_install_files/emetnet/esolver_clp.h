#ifndef __ESOLVER_CLP__
#define __ESOLVER_CLP__

#include "esolver.h"

#include <coin/ClpSimplex.hpp>
#include <coin/ClpFactorization.hpp>
#include <coin/ClpNetworkMatrix.hpp>


class esolver_clp : public esolver
{
 public:
  ClpSimplex *model;
  
 
  esolver_clp();
  ~esolver_clp();

  void parse(ematrix& m,evector& lower,evector& upper,evector& xlower,evector& xupper,evector& objective);
  void parse(enet& net);
  double solve();

  int iobjective;
  void setobjective(int i,double value=1.0);
  void setobjective2(int i,double value=1.0);
  void setobjective(evector& obj);

  void setxbounds(int i,double min,double max);
  void setybounds(int i,double min,double max);

  void setActive(const eintarray& arr);
  void activate(int i);
  void disable(int i);
};

#endif


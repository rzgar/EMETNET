#include "enet.h"
#include "esolver_clp.h"

#include <eutils/emain.h>

  //   in the following loop, we will search for all neighboor links, that
  // are connected through one metabolite to the paulsson's model

  //   this is the first shell of reactions around the paulsson's model
  
  //   we will not take into account reactions that are connected through H, H2O, ATP, ADP, ...

esolver_clp solver;


void mark_adjacent(enet &net,estrarray &ignore)
{
  int i,j,k;

  for (i=0; i<net.links.size(); ++i){
    if (!net.links[i].info["M"].len()) continue;

    for (j=0; j<net.links[i].src.size(); ++j){
      if (ignore.find(net.links[i].src[j].node->id)!=-1) continue;

      for (k=0; k<net.links[i].src[j].node->links.size(); ++k){
        if (!net.links[i].src[j].node->links[k]->info["M"].len()){
          net.links[i].info["M"] = "1";
          break;
        }
      }
      if (net.links[i].info["M"] == "1") break;
    }

    if (net.links[i].info["M"] == "1") continue;
    
    for (j=0; j<net.links[i].dst.size(); ++j){
      if (ignore.find(net.links[i].dst[j].node->id)!=-1) continue;

      for (k=0; k<net.links[i].dst[j].node->links.size(); ++k){
        if (!net.links[i].dst[j].node->links[k]->info["M"].len()){
          net.links[i].info["M"] = "1";
          break;
        }
      }
      if (net.links[i].info["M"] == "1") break;
    }
  }
}

void add_marked(enet &net)
{
  int i;
  for (i=0; i<net.links.size(); ++i){
    if (net.links[i].info["M"]=="1"){
      solver.activate(i);
      net.links[i].info["M"]="";
    }
  }
}

int add_1reaction(enet &net)
{
  int i;
  for (i=0; i<net.links.size(); ++i){
    if (net.links[i].info["M"]=="1"){
      solver.activate(i);
      net.links[i].info["M"]="";
      return(i);
    }
  }
  ldie("Unable to add reaction");
  return(-1);
}

int count_marked(enet &net)
{
  int i;
  int acount;
  acount=0;
  for (i=0; i<net.links.size(); ++i){
    if (net.links[i].info["M"]=="1")
      ++acount;
  }
  return(acount);
}

int count_inmodel(enet &net)
{
  int i;
  int acount;
  acount=0;
  for (i=0; i<net.links.size(); ++i){
    if (!net.links[i].info["M"].len())
      ++acount;
  }
  return(acount);
}


int emain()
{
  ldieif (argvc<2,"syntax: ./emetnet-inc <file.net>");  

  enet net;
  net.load(argv[1]); 
  cout << "finished loading file: "<<argv[1] << endl;


  
  cout << "# Number of total reactions in model: "<<count_inmodel(net)<<endl;



  double v;
  
  solver.parse(net);
  solver.load_fluxbounds();

  v=solver.solve();
  cout << "Growth: "<< v << endl;


  estrarray ignore("C00080,C00001,C00002,C00009,C00003,C00004,C00006,C00008,C00013,C00011,C00014,C00005,C00007");

  int count;
  int acount;

  cout << "# added_reaction    growth    total_reactions" << endl;

  mark_adjacent(net,ignore);
  cout << endl;
  acount=count_marked(net);
  cout << "# Number of 1st shell adjacent reactions to paulsson's model: "<<acount<<endl;
  count = count_inmodel(net);

  add_marked(net);
  cout << "# Number of total reactions in new model: "<<count_inmodel(net)<<endl;

  v=solver.solve();
  cout << "Growth: "<< v << endl;

/*
  while (acount>0){
    --acount; ++count;
    cout << add_1reaction(net) << " ";
    cout << net.parse_clp_k() << " ";
    cout << count << endl;
  }
*/

/*
  mark_adjacent(net,ignore);
  cout << endl;
  acount=count_marked(net);
  cout << "# Number of 1st shell adjacent reactions to paulsson's model: "<<acount<<endl;
  count = count_inmodel(net);

  while (acount>0){
    --acount; ++count;
    cout << add_1reaction(net) << " ";
    v=net.parse_clp_k();
    cout << v << " ";
    cout << count << endl;
    if (v==-1.0) break;
  }
*/

//  add_marked(net);
//  cout << "Number of total reactions in new model: "<<count_inmodel(net)<<endl;

  return(0);
}

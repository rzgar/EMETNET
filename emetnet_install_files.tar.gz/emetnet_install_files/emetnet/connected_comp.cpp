#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
#include <vector>
using std::vector;

// array that will store pre-computed number of "on" bits in a 16bit value
char precomp_count_16bits[0x1u<<16];
// function to compute how many "on" bits exist in a 32bit (int) value
inline char count_bits(unsigned int i)
{
  int cbits=0;
  while (i){
    cbits += i&0x1u;
    i>>=1;
  }
  return(cbits);
}

// function that needs to be called at the beginning of a program (before any other code) to initialize the array with pre-computed values (bits_in_16bits)
void init_precomp_count()
{
  unsigned int i;
// iterates through all possible 16 bit values and initializes the array to the number of "on" bits in that value
  for (i=0; i<0x1u<<16; ++i)
    precomp_count_16bits[i]=count_bits(i);
}

// function to compute how many "on" bits exist in a 64bit (long int) value using the pre-computed table. Basically this takes the first the 64 bits and splits it into 16 + 16 + 16 +16. For each of those 16 bits sums the count using the table to look them up. 
int count_bits16(unsigned long i)
{
  return( precomp_count_16bits[i & 0xfffful] + precomp_count_16bits[(i>>16) & 0xfffful] +precomp_count_16bits[(i>>32) & 0xfffful] + precomp_count_16bits[(i>>48) & 0xfffful] );
}

// This function will return the hamming distance between two networks represented by 64bit values
inline int mnets_dist(unsigned long x,unsigned long y)
{
  return(count_bits16(x^y));
}

// Clust function definition //
void clust(int &count, vector<int> &vec, unsigned long allnetworks[], const int j1)
{
int ind=0;
int init=0;
int sum=0;
for (int i=0; i<j1;++i){
    if (vec[i]==0){
        vec[i]=count;
        ind=1;
        init=i;
        break;
    }
}
if (ind==1){
   for (int q=0;q<2;++q){
      for (int k=init;k<j1;++k){
        if (vec[k]==count){
            for (int l=init;l<j1;++l){
                if (vec[l]==0){
                    sum = mnets_dist(allnetworks[k],allnetworks[l]); //distance is defined
                    if (sum==2){
                        vec[l]=count;}
              }
            }
           }
        else if (vec[k]==0){
            for (int l=init; l<j1; ++l){
                if (vec[l]==count){
                    sum = mnets_dist(allnetworks[k],allnetworks[l]); // distance is defined
                    if (sum==2){
                        vec[k]=count;}
                   }
                }
            }
        else;
        }

    }
count++;
clust(count,vec,allnetworks,j1);
}
}

int emain() {
ldieif(argvc<3,"syntax: ./connected_comp.cpp <inputfilename.dat> <number of lines>");
// Arguments
estr sizestr=argv[1];
estr numb1=argv[2];
int j1;
estrarray parts1;
parts1=numb1.explode(" ");
j1=parts1[0].i();
epregister(sizestr);

cout<<sizestr<<endl;
if (j1<1000001){
init_precomp_count();  // initialize the precomp_count array
unsigned long allnetworks[j1];  // this is the array which will contain all networks (array of 64bit values). Make sure to set "netcount" to the proper number of networks you will be reading

// Reading the files and filling the arrays
estr str;
estrarray parts;
efile f;
int j,k,m,n;
int intcount;
unsigned long genbits=0x00ul; // start with a 64bit value representing the network with all bits set to zero
intcount=0;
f.open(argv[1],"r");
while (f.readln(str)) {
      parts=str.explode(" ");
      genbits=0x00ul; 
      for (int m=0; m<parts.size(); ++m){
      genbits|=(0x01ul<<(parts[m].i()-1));}
      allnetworks[intcount]=genbits;
      intcount++;
}
f.close();

// Clustering
int count=1;
vector<int> vec(j1);
for (int jj=0; jj<j1; ++jj){
vec[jj]=0;}
clust(count,vec,allnetworks,j1);

// Writing the result

estr outputing=sizestr+"_connectivity";
efile outfile;
outfile.open(outputing,"a");
for (int n=0;n<j1;++n){
int temp=vec[n];
double final=(double) temp;
estr toutput=final;
outfile.write(toutput+"\n");
}
outfile.close();
}
else{cout<<"Bye Bye"<<endl;}
}

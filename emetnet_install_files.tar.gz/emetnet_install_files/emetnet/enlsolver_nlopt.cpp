#include <math.h>
#include <nlopt.h>
#include "enlsolver_nlopt.h"

double fba_objective(unsigned n, const double *x, double *grad, void *my_func_data)
{
  printf("# fba_objective: %lf\n",x[0]);
//  cout << "# fba_objective called: "<< x[0] << endl;
  int i;
  if (grad){
    grad[0]=1.0;
    for (i=1; i<n; ++i)
      grad[i]=0.0;
  }
  
  return(x[0]);
}

void fba_constraints(unsigned m, double *result, unsigned n, const double* x, double* grad, void* f_data){
  cout << "# fba_constraints called: "<<grad << endl;
  int i,j;
  enet *net=(enet*)f_data;
  for (i=0; i<m; ++i)
    result[i]=0.0;

  for (i=0; i<net->links.size(); ++i){
    for (j=0; j<net->links[i].src.size(); ++j)
      result[ net->links[i].src[j].node->i ] -= net->links[i].src[j].rate * x[i];
    for (j=0; j<net->links[i].dst.size(); ++j)
      result[ net->links[i].dst[j].node->i ] += net->links[i].dst[j].rate * x[i];
  }
  for (i=0; i<net->nodes.size(); ++i)
    result[ i ] -= x[ i + net->links.size() ];

  if (grad){
    for (i=0; i<m*n; ++i)
      grad[i] = 0.0;
    for (i=0; i<net->links.size(); ++i){
      for (j=0; j<net->links[i].src.size(); ++j)
        grad[ net->links[i].src[j].node->i*n + i ] -= net->links[i].src[j].rate;
      for (j=0; j<net->links[i].dst.size(); ++j)
        grad[ net->links[i].dst[j].node->i*n + i ] += net->links[i].dst[j].rate;
    }
    for (i=0; i<m; ++i)
      grad[ i*n + i+net->links.size() ] -= 1;
  }
}

void enlsolver_nlopt::setobjective(int i,double value){}
void enlsolver_nlopt::setobjective(evector& obj){}

void enlsolver_nlopt::setxbounds(int i,double min,double max){}
void enlsolver_nlopt::setybounds(int i,double min,double max)
{
  ldieif(min>max,"min is larger than max!");
  ldieif(i>=net->nodes.size(),"index out of bounds");
  double *lb=new double[net->links.size()+net->nodes.size()];
  double *ub=new double[net->links.size()+net->nodes.size()];
  nlopt_get_lower_bounds(nlp, lb);
  nlopt_get_upper_bounds(nlp, ub);
  lb[net->links.size()+i]=min;
  ub[net->links.size()+i]=max;
  cout << net->links.size()+i <<" ["<<lb[net->links.size()+i]<<","<<ub[net->links.size()+i]<<"]"<<endl;
  nlopt_set_lower_bounds(nlp, lb);
  nlopt_set_upper_bounds(nlp, ub);
}

void enlsolver_nlopt::parse(ematrix& m,evector& lower,evector& upper,evector& xlower,evector& xupper,evector& objective){}

void enlsolver_nlopt::setActive(const eintarray& arr){}



enlsolver_nlopt::enlsolver_nlopt(): nlp(0x00) {}

enlsolver_nlopt::~enlsolver_nlopt()
{
  if (nlp){
    nlopt_destroy(nlp);
    nlp=0x00;
  }
}

void enlsolver_nlopt::activate(int i)
{
/*
  lddieif(!model,"activating node "+estr(i)+" before parsing model");
  double lower,upper;
  upper=COIN_DBL_MAX;
  lower=-COIN_DBL_MAX;
  if (net->links[i].irreversible)
    lower=0;

  net->links[i].active=true;

  model->setColumnBounds(i,lower,upper);
*/
}

void enlsolver_nlopt::disable(int i)
{
/*
  lddieif(!model,"disabling node "+estr(i)+" before parsing model");

  net->links[i].active=false;
  model->setColumnBounds(i,0.0,0.0);
*/
}

void enlsolver_nlopt::parse(enet& _net)
{
  net = &_net;

  int n,m;

  /* set the number of variables and allocate space for the bounds */
  n=net->links.size();
  m=net->nodes.size();

  double *ub;
  double *lb;

  lb=new double[n+m];
  ub=new double[n+m];
  /* set the values for the variable bounds */
  int i;


  cout << "flux bounds:" << endl;

  for (i=0;i<n;++i) {
//    nele_jac += net->links[i].src.size() + net->links[i].dst.size();

    // maximum/minimum reaction fluxs
    if (net->links[i].active)
      ub[i]=1000;
    else
      ub[i]=0.0;

    if (!net->links[i].active || net->links[i].irreversible)
      lb[i]=0.0;
    else
      lb[i]=-1000;
    cout << i <<" ["<<lb[i]<<","<<ub[i]<<"]"<<endl;
  }


  cout << "metabolite flux bounds:" << endl;
  /* set the values of the constraint bounds */
  for (i=0;i<m;++i){
    if (net->fluxbounds.findkey(net->nodes[i].id) != -1)
      {lb[i+n]=net->fluxbounds[net->nodes[i].id].x; ub[i+n]=net->fluxbounds[net->nodes[i].id].y; }
    else if (net->nodes[i].id.find("_external") != -1 || net->nodes[i].id.find("[e]") != -1)
      {lb[i+n]=0.0; ub[i+n]=1000;} // allow output of _external metabolites
    else
      {lb[i+n]=0.0; ub[i+n]=0.0; }
    cout << i+n <<" ["<<lb[i+n]<<","<<ub[i+n]<<"]"<<endl;
  }

//  nlp = nlopt_create(NLOPT_LN_SBPLX, n+m); /* algorithm and dimensionality */
//  nlp = nlopt_create(NLOPT_LD_MMA, n+m); /* algorithm and dimensionality */

  nlp = nlopt_create(NLOPT_LD_SLSQP, n+m); /* algorithm and dimensionality */
//  nlp = nlopt_create(NLOPT_GN_ISRES, n+m); /* algorithm and dimensionality */
//  nlp = nlopt_create(NLOPT_LN_COBYLA, n+m); /* algorithm and dimensionality */

/*
  nlp = nlopt_create(NLOPT_AUGLAG, n+m);
  nlopt_opt nlp_local;
  nlp_local = nlopt_create(NLOPT_LN_SBPLX, n+m);
  nlopt_set_ftol_rel(nlp_local, 1e-4);
  nlopt_set_local_optimizer(nlp,nlp_local);
*/

  ldieif(nlp==0x00,"error");
  nlopt_set_lower_bounds(nlp, lb);
  nlopt_set_upper_bounds(nlp, ub);
  nlopt_set_max_objective(nlp, fba_objective, NULL);

  double *tols=new double[m];
  for (i=0; i<m; ++i)
    tols[i]=1e-6;

  nlopt_add_equality_mconstraint(nlp, m, fba_constraints, net, tols);

  delete(ub);
  delete(lb);
  delete(tols);
}


double enlsolver_nlopt::solve()
{
  double *x=new double[net->links.size()+net->nodes.size()];   //[2] = { 1.234, 5.678 };  /* some initial guess */
  double maxf; /* the maximum objective value, upon return */

  int i;
  for (i=0; i<net->links.size()+net->nodes.size(); ++i)
    x[i]=0.0;
  x[0]=0.0;

  int ret;
//  nlopt_set_xtol_rel(nlp, 1e-4);
  nlopt_set_ftol_rel(nlp, 1e-4);
  ret=nlopt_optimize(nlp, x, &maxf);
  if (ret < 0) {
    printf("nlopt failed: %i\n",ret);
  }
  else {
    printf("max: %0.10g\n", maxf);
  }
  delete(x);
}



/*
int emain(){
  eparseArgs(argvc,argv);

  double lb[2] = { -HUGE_VAL, 0 };
  double ub[2] = { HUGE_VAL, 0 };
  nlopt_opt opt;

  opt = nlopt_create(NLOPT_LD_MMA, 2);
  nlopt_set_lower_bounds(opt, lb);
  nlopt_set_lower_bounds(opt, ub);
  nlopt_set_max_objective(opt, fba_objective, NULL);

  double tols[2]={1e-8,1e-8};

  nlopt_add_equality_mconstraint(opt, 2, fba_constraints, net, tols);

  nlopt_set_xtol_rel(opt, 1e-4);

  double x[2] = { 1.234, 5.678 };
  double minf;

  if (nlopt_optimize(opt, x, &minf) < 0) {
    printf("nlopt failed!\n");
  }
  else {
    printf("found minimum at f(%g,%g) = %0.10g\n", x[0], x[1], minf);
  }

  nlopt_destroy(opt);

  return(0);
}
*/


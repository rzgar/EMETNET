#include "enet.h"
#include "erandomwalk.h"

#include <eutils/emain.h>
#include <eutils/ernd.h>

/*
void setup_rw(erandomWalk& rw)
{
  int i=3;
  while (i<argvc && estr(argv[i]).substr(-4) == ".flx"){
    rw.addEnv(argv[i]);
    ++i;
  }
}
*/

estr intarr2str(const eintarray&);

int get_individual_phe(earray<eintarray> &phenotypes,int j,int r)
{
  int i;
  for (i=0; i<phenotypes.size(); ++i){
    if (phenotypes[i][j]==1 && phenotypes[i][i/5]==1){
      if (r==0) return(i);
      --r;
    }
  }
  ldie("something wrong in get_ind_phe");
  return(-1);
}

int get_viablecount(earray<eintarray> &phenotypes,int j)
{
  int k,viablecount;
  viablecount=0;
  for (k=0; k<phenotypes.size(); ++k){
    if (phenotypes[k][j]==1 && phenotypes[k][k/5]==1)
      ++viablecount;
  }
  return(viablecount);
}


int emain()
{
  ldieif (argvc<4,"syntax: ./metnet-genphedist <file.net> <starter.net> <env.flx env2.flx ...>"); 

  estr outnet="default.net";
  estr solver="cplex";
  int strict=0;
  int mstep=10;
  int popsize=20;
  int iter=200;
  int netsize=-1;
  int isolate=0;

  epregister(outnet);
  epregister(solver);
  epregister(strict);
  epregister(mstep);
  epregister(popsize);
  epregister(iter);
  epregister(netsize);
  epregister(isolate);

  enet net;
  net.load(argv[1]); 
  net.correct_malformed();

  enet net2;
  net2.load(argv[2]);

//  enet net3;
//  net3.load(argv[3]);

  erandomWalk rw(net,solver,strict);
  rw.setRSize(netsize);
  cout << "# isolate: "<<isolate<<endl;
  cout << "# strict: "<<strict<<endl;
  cout << "# using solver: "<<solver<<endl;
//  cout << "# number of total reactions: " << net.links.size() << endl;
  cout << "# finished loading file: "<<argv[1] << endl;
  cout << "# Number of total reactions in world network: "<<net.links.size()<<endl;

  rw.getEnv(argvc,argv);

  eintarray phe_f,gen_f; //,phe_f2,gen_f2;

  rw.load(net2);
  rw.calcPhenotype();
  rw.viablePhenotype=rw.phenotype;
  gen_f = rw.genotype;
  phe_f=rw.phenotype;
  cout << "# icount: "<<1.0/rw.icount<<endl;
  cout << "# Reactions in net #1: "<<net2.links.size() << endl;
  cout << "# Phenotype for net #1: "<<intarr2str(rw.phenotype)<<endl;
  popsize=5*rw.phenotype.size(); // we want 5 sites per sulfur source

/*
  rw.load(net3);
  rw.calcPhenotype();
  rw.viablePhenotype=rw.phenotype;
  phe_f2=rw.phenotype;
  gen_f2=rw.genotype;

  cout << "# Reactions in net #2: "<<net3.links.size() << endl;
  cout << "# Phenotype for net #2: "<<intarr2str(rw.phenotype)<<endl;
*/

  int i;

//  net.saveactive(outnet);

  earrayof<int,eintarray> pop_phenotypes;
  earrayof<int,eintarray> all_phenotypes;
  earrayof<int,eintarray> tphenotypes;

  int np=0;
  int op=1;
  earray<eintarray> genotypes[2];
  earray<eintarray> phenotypes[2];
  eintarray survivors;
  int j;
  int k;
  int l;
  double gendist;
  int gencount;

  cout << "# Populating world" << endl;
  for (i=0; i<popsize; ++i){
    genotypes[0].add(gen_f);
    phenotypes[0].add(phe_f);
    genotypes[1].add(gen_f);
    phenotypes[1].add(phe_f);
  }
/*
  for (;i<popsize; ++i){
    genotypes[0].add(gen_f2);
    phenotypes[0].add(phe_f2);
    genotypes[1].add(gen_f2);
    phenotypes[1].add(phe_f2);
  }
*/

  int viablecount;
  int pheviable;
  cout << "# Starting evolution" << endl;
  for (i=0; i<iter; ++i){
    pheviable=0;
    cout << "# ";
    for (j=0; j<phe_f.size(); ++j){
      viablecount=get_viablecount(phenotypes[op],j);
      cout << viablecount << " ";
      linfo(" -| looking for individuals for sulfur source: "+estr(j)+" viable: "+viablecount);
      if (viablecount==0) continue;
      pheviable++;
      for (k=0; k<5; ++k){
        do {
          if (isolate==0 || viablecount<5)
            l=get_individual_phe(phenotypes[op],j,ernd.uniform()*viablecount);
          else
            l=j*5+ernd.uniform()*5;
      
          rw.phenotype=phenotypes[op][l];
          rw.load(genotypes[op][l]);
          rw.mutate();
          rw.updatePhenotype();
          linfo(" -| testing "+estr(l));
        }while (rw.phenotype[j]==0);
        linfo(" -| "+estr(k)+" is viable");
        genotypes[np][j*5+k]=rw.genotype;
        phenotypes[np][j*5+k]=rw.phenotype;
      }
    }
    cout <<endl;

    op=np;
    np=(np+1)%2;

    gendist=0.0;
    gencount=0;
    for (j=0; j<genotypes[op].size(); ++j){
      if (phenotypes[op][j][j/10]==0) continue;
      for (k=j+1; k<genotypes[op].size(); ++k){
        if (phenotypes[op][k][k/10]==0) continue;
        gendist+=gendistance(genotypes[op][j],genotypes[op][k]);
        ++gencount;
      }
    }
    cout << i << " " << pheviable<< " "<<gendist/gencount<<endl;
  }

  for (j=0; j<genotypes[op].size(); ++j){
    if (phenotypes[op][j][j/5]==1)
      net.saveactive(genotypes[op][j],outnet+estr(i)+"-"+estr(j)+".net");
  }

  return(0);
}

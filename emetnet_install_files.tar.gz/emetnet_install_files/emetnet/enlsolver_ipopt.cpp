#include "enlsolver_ipopt.h"




/* Function Implementations */
Bool eval_f(Index n, Number* x, Bool new_x,
            Number* obj_value, UserDataPtr user_data)
{
  *obj_value = -x[0];
  return TRUE;
}

Bool eval_grad_f(Index n, Number* x, Bool new_x,
                 Number* grad_f, UserDataPtr user_data)
{
  int i;
  grad_f[0] = -1.0;
  for (i=1; i<n; ++i)
    grad_f[i]=0.0;
  return TRUE;
}

Bool eval_g(Index n, Number* x, Bool new_x,
            Index m, Number* g, UserDataPtr user_data)
{
  int i,j;
  for (i=0; i<((enet*)user_data)->nodes.size(); ++i)
    g[i]=0.0;

  for (i=0; i<((enet*)user_data)->links.size(); ++i){
    for (j=0; j<((enet*)user_data)->links[i].src.size(); ++j)
      g[ ((enet*)user_data)->links[i].src[j].node->i ] -= ((enet*)user_data)->links[i].src[j].rate * x[i];
    for (j=0; j<((enet*)user_data)->links[i].dst.size(); ++j)
      g[ ((enet*)user_data)->links[i].dst[j].node->i ] += ((enet*)user_data)->links[i].dst[j].rate * x[i];
  }
  return TRUE;
}

Bool eval_jac_g(Index n, Number *x, Bool new_x,
                Index m, Index nele_jac,
                Index *iRow, Index *jCol, Number *values,
                UserDataPtr user_data)
{
  int i,j,t;
  if (values == NULL) {
    /* return the structure of the jacobian */
    t=0;
    for (i=0; i<((enet*)user_data)->links.size(); ++i){
      for (j=0; j<((enet*)user_data)->links[i].src.size(); ++j){
        jCol[t] = i;
        iRow[t] = ((enet*)user_data)->links[i].src[j].node->i;
        ++t;
      }
      for (j=0; j<((enet*)user_data)->links[i].dst.size(); ++j){
        jCol[t] = i;
        iRow[t] = ((enet*)user_data)->links[i].dst[j].node->i;
        ++t;
      }
    }
  }
  else {
    t=0;
    for (i=0; i<((enet*)user_data)->links.size(); ++i){
      for (j=0; j<((enet*)user_data)->links[i].src.size(); ++j){
        values[t] = -((enet*)user_data)->links[i].src[j].rate;
        ++t;
      }
      for (j=0; j<((enet*)user_data)->links[i].dst.size(); ++j){
        values[t] = ((enet*)user_data)->links[i].dst[j].rate;
        ++t;
      }
    }
  }
  return TRUE;
}

Bool eval_h(Index n, Number *x, Bool new_x, Number obj_factor,
            Index m, Number *lambda, Bool new_lambda,
            Index nele_hess, Index *iRow, Index *jCol,
            Number *values, UserDataPtr user_data)
{
  return TRUE;
}















enlsolver_ipopt::enlsolver_ipopt(): nlp(0x00) {}

enlsolver_ipopt::~enlsolver_ipopt()
{
  if (nlp){
    FreeIpoptProblem(nlp);
    nlp=0x00;
  }
}

void enlsolver_ipopt::activate(int i)
{
/*
  lddieif(!model,"activating node "+estr(i)+" before parsing model");
  double lower,upper;
  upper=COIN_DBL_MAX;
  lower=-COIN_DBL_MAX;
  if (net->links[i].irreversible)
    lower=0;

  net->links[i].active=true;

  model->setColumnBounds(i,lower,upper);
*/
}

void enlsolver_ipopt::disable(int i)
{
/*
  lddieif(!model,"disabling node "+estr(i)+" before parsing model");

  net->links[i].active=false;
  model->setColumnBounds(i,0.0,0.0);
*/
}

void enlsolver_ipopt::parse(enet& _net)
{
/*
  net=&_net;
  int numberColumns;

  int i;
  int t_elements;

  t_elements=0;
  numberColumns=net->links.size();
  for (i=0; i<net->links.size(); ++i){
    t_elements+=net->links[i].src.size()+net->links[i].dst.size();
  }

  double * objective = new double[numberColumns];
  double * lowerColumn = new double[numberColumns];
  double * upperColumn = new double[numberColumns];

  double * element = new double [t_elements];
  int * row = new int[t_elements];
  int * start = new int[numberColumns+1];
  int * length = new int[numberColumns+1];

  int j,k;

  ldinfo(" generating problem of " + estr(numberColumns) + " columns X " + estr((int)net->nodes.size()) + " rows");


//int ri;
  i=0;
  k=0;
//  start[numberColumns]=2*numberColumns;
  start[numberColumns]=t_elements;
  for (i=0;i<net->links.size();++i) {
//    if (!links[ri].active) continue;
    start[i]=k;
    length[i]=net->links[i].src.size() + net->links[i].dst.size();

    // for each flux, write the row which it affects
    for (j=0; j<net->links[i].src.size(); ++j){
      element[k]=-net->links[i].src[j].rate;
      row[k]=net->links[i].src[j].node->i;
      ++k;
    }
    for (j=0; j<net->links[i].dst.size(); ++j){
      element[k]=net->links[i].dst[j].rate;
      row[k]=net->links[i].dst[j].node->i;
      ++k;
    }

    // maximum/minimum reaction fluxs
    if (net->links[i].active)
      upperColumn[i]=COIN_DBL_MAX;
    else
      upperColumn[i]=0.0;

    if (!net->links[i].active || net->links[i].irreversible)
      lowerColumn[i]=0.0;
    else
      lowerColumn[i]=-COIN_DBL_MAX;

    // we dont want to maximize any other fluxes
    // but the first one
    objective[i]=0.0;
  }
  objective[0] = 1.0;


  dieif(t_elements!=k,"something is wrong with t_elements! t_elements="+estr(t_elements)+" , k="+estr(k));

//  ldwarn("creating model and matrix");

  linfo("creating Clp Model");

  if (model) delete model;

  model = new ClpSimplex;

  // Create Packed Matrix
  CoinPackedMatrix matrix;
  matrix.assignMatrix(true,net->nodes.size(),numberColumns,
	  	        t_elements,element,row,start,length);
	
  double *upper = new double[net->nodes.size()];
  double *lower = new double[net->nodes.size()];
	
  for (i=0;i<net->nodes.size();++i){
    if (net->fluxbounds.findkey(net->nodes[i].id) != -1)
      {lower[i]=net->fluxbounds[net->nodes[i].id].x; upper[i]=net->fluxbounds[net->nodes[i].id].y; }
    else if (net->nodes[i].id.find("_external") != -1 || net->nodes[i].id.find("[e]") != -1)
      {lower[i]=0.0; upper[i]=COIN_DBL_MAX;} // allow output of _external metabolites
    else
      {lower[i]=0.0; upper[i]=0.0; }
  }
  
//  ldwarn("loading model");
  // load model
  model->loadProblem(matrix,
           lowerColumn,upperColumn,objective,
			    lower,upper);
			
  delete [] lower;
  delete [] upper;
  delete [] objective;
  delete [] lowerColumn;
  delete [] upperColumn;
  delete [] element;
  delete [] start;
  delete [] length;
  delete [] row;

//  ldwarn("finding solution");
  model->setLogLevel(0);
  model->setPrimalTolerance(1.0E-12);
  model->setOptimizationDirection(-1);
*/

  #define FLUX_MAX 2.0e19

  net = &_net;

  Index n=-1;                          /* number of variables */
  Index m=-1;                          /* number of constraints */
  Number* x_L = NULL;                  /* lower bounds on x */
  Number* x_U = NULL;                  /* upper bounds on x */
  Number* g_L = NULL;                  /* lower bounds on g */
  Number* g_U = NULL;                  /* upper bounds on g */

  Index i;                             /* generic counter */

  /* Number of nonzeros in the Jacobian of the constraints */
  Index nele_jac = 0;
  /* Number of nonzeros in the Hessian of the Lagrangian (lower or
     upper triangual part only) */
  Index nele_hess = 0;
  /* indexing style for matrices */
  Index index_style = 0; /* C-style; start counting of rows and column
  			    indices at 0 */

  /* set the number of variables and allocate space for the bounds */
  n=net->links.size();
  x_L = (Number*)malloc(sizeof(Number)*n);
  x_U = (Number*)malloc(sizeof(Number)*n);
  /* set the values for the variable bounds */
  for (i=0;i<n;++i) {
    nele_jac += net->links[i].src.size() + net->links[i].dst.size();

    // maximum/minimum reaction fluxs
    if (net->links[i].active)
      x_U[i]=FLUX_MAX;
    else
      x_U[i]=0.0;

    if (!net->links[i].active || net->links[i].irreversible)
      x_L[i]=0.0;
    else
      x_L[i]=-FLUX_MAX;
  }

  /* set the number of constraints and allocate space for the bounds */
  m=net->nodes.size();
  g_L = (Number*)malloc(sizeof(Number)*m);
  g_U = (Number*)malloc(sizeof(Number)*m);
  /* set the values of the constraint bounds */
  for (i=0;i<m;++i){
    if (net->fluxbounds.findkey(net->nodes[i].id) != -1)
      {g_L[i]=net->fluxbounds[net->nodes[i].id].x; g_U[i]=net->fluxbounds[net->nodes[i].id].y; }
    else if (net->nodes[i].id.find("_external") != -1 || net->nodes[i].id.find("[e]") != -1)
      {g_L[i]=0.0; g_U[i]=FLUX_MAX;} // allow output of _external metabolites
    else
      {g_L[i]=0.0; g_U[i]=0.0; }
  }

  /* create the IpoptProblem */
  nlp = CreateIpoptProblem(n, x_L, x_U, m, g_L, g_U, nele_jac, nele_hess,
                           index_style, &eval_f, &eval_g, &eval_grad_f,
                           &eval_jac_g, &eval_h);

  /* We can free the memory now - the values for the bounds have been
     copied internally in CreateIpoptProblem */
  free(x_L);
  free(x_U);
  free(g_L);
  free(g_U);
}


double enlsolver_ipopt::solve()
{
  double res;

  getLogger()->level = 0;
  ApplicationReturnStatus status; /* Solve return code */
  Number* x = NULL;                    /* starting point and solution vector */
  Number* mult_x_L = NULL;             /* lower bound multipliers
  					  at the solution */
  Number* mult_x_U = NULL;             /* upper bound multipliers
  					  at the solution */
  Number obj;                          /* objective value */
  Index i;                             /* generic counter */

  Index n;
  Index m;

  n = net->links.size();
  m = net->nodes.size();


  /* Set some options.  Note the following ones are only examples,
     they might not be suitable for your problem. */
  AddIpoptNumOption(nlp, "tol", 1e-7);
  AddIpoptStrOption(nlp, "mu_strategy", "adaptive");
  AddIpoptStrOption(nlp, "output_file", "ipopt.out");

  /* allocate space for the initial point and set the values */
  x = (Number*)malloc(sizeof(Number)*n);

  for (i=0; i<n; ++i)
    x[i]=0.0;

  /* allocate space to store the bound multipliers at the solution */
  mult_x_L = (Number*)malloc(sizeof(Number)*n);
  mult_x_U = (Number*)malloc(sizeof(Number)*n);

  /* solve the problem */
  status = IpoptSolve(nlp, x, NULL, &obj, NULL, mult_x_L, mult_x_U, net);

  if (status == Solve_Succeeded) {
/*
    printf("\n\nSolution of the primal variables, x\n");
    for (i=0; i<n; i++) {
      printf("x[%d] = %e\n", i, x[i]);
    }

    printf("\n\nSolution of the bound multipliers, z_L and z_U\n");
    for (i=0; i<n; i++) {
      printf("z_L[%d] = %e\n", i, mult_x_L[i]);
    }
    for (i=0; i<n; i++) {
      printf("z_U[%d] = %e\n", i, mult_x_U[i]);
    }

    printf("\n\nObjective value\n");
    printf("f(x*) = %e\n", obj);
*/
    res = obj;
  } else
    res = -1.0;

  /* free allocated memory */
//  FreeIpoptProblem(nlp);
  free(x);
  free(mult_x_L);
  free(mult_x_U);

  return(res);


/*
  lddieif(!model,"solve method called before model was parsed");

  model->primal();

  double r;

  int status;
  status = model->status();

//  ldwarn("showing solution");
  double * columnPrimal;
  double * rowPrimal;
  switch(status){
    case 0:
      rowPrimal = model->primalRowSolution();
      columnPrimal = model->primalColumnSolution();
//      for(i=0; i<nodes.size();++i){
//        if (fluxbounds.findkey(nodes[i].id) != -1)
//          cout << nodes[i].id<<": "<<rowPrimal[i]<<endl;
//      }
//      cout << "target found: "<<columnPrimal[0]<<endl;
      r=columnPrimal[0];
//      delete rowPrimal; delete columnPrimal;
      lstop();
      return(r);
     break;
    case 1:
      cerr << "Model is infeasible!" << endl;
     break;
    case 2:
      cerr << "Model is dual infeasible!" << endl;
     break;
    case 3:
      cerr << "Limit number of iterations reached" << endl;
     break;
    default:
     cerr << "Unknown status: " << status << endl;
  }

  lstop();
  return(-1);
*/
}


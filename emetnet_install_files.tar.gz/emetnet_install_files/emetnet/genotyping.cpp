#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/eheap.h>
#include <algorithm>
#include <eutils/ernd.h>

estr solver="esolver_clp";
int netsize=-1;
int strict=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
double gendist=0.0;
enet net;
erandomWalk *prw=0x00;


int emain()
{ ldieif(argvc<3,"syntax: ./genotyping  <universe.net> <file.net> <file.dat> <fluxbounds.flx>");  
  eparseArgs(argvc,argv);
////////////////////////////////////////////////////////////// Genotyping /////////////////////////////////////////////////////////////////
  net.load(argv[1]); 
  net.correct_malformed();
  erandomWalk rw(net,solver,strict);
  prw=&rw; 
  
  rw.setRSize(netsize);
  rw.getEnv(argvc,argv);
  rw.load(net);
  
  enet net2;
  net2.load(argv[2]);
  rw.load(net2);

  estr filein=argv[2];
  estr fileout=argv[3];
  eintarray gen = rw.genotype;

  estr intstr = intarr2str2(gen);
  efile fout;
  fout.open(fileout,"w");
  fout.write(intstr+"\n"); 
  cout<<intstr<<endl;
  fout.close();
  return(0);
}

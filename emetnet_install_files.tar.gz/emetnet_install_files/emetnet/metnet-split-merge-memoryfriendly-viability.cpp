#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
#include <eutils/eheap.h>
#include <algorithm>
#include <stdio.h>
#include <stdlib.h>

estr solver="esolver_clp";
int netsize=-1;
int strict=0;
int force_away=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
int s1=0;
int s2=0;
enet net;
erandomWalk *prw=0x00;

int emain() {

  ldieif(argvc<7,"syntax: metnet-merge-viability universe.net <inputfilename1.dat> <inputfilename2.dat> --s1 [>1] --s2 [>1] <env.flx> <--outfile <filename>> ");

  estr fileclass=argv[5];
  estr numb=argv[6];

	
  epregister(solver);
  epregister(s1);
	epregister(s2);
  eparseArgs(argvc,argv);

  ldieif(s1<1,"syntax: Size 1 is not declared. Aborting");
  ldieif(s2<1,"syntax: Size 2 is not declared. Aborting");

//	cout << "# input file1: "<<argv[2] << endl;
  cout << "# input file1: "<<argv[2] << endl;
	cout << "# input file2: "<<argv[3] << endl;
  cout << "# environment: "<<argv[4] << endl;

  net.load(argv[1]); // loading the network in the object "net" which is of type enet. 
  cout << "# global network: "<<argv[1] << endl;
  cout << "# reactions (global): " << net.links.size() << endl;
  net.correct_malformed();
  cout << "# non-malformed reactions: " << net.links.size() << endl;
  erandomWalk rw(net,solver,strict);
  prw=&rw;
  rw.periphery_only=periphery_only;
  rw.mutate_transport=mutate_transport;
  rw.internal_secretion=internal_secretion;
  rw.only_viable=only_viable;
  rw.setRSize(netsize);

  rw.getEnv(argvc,argv);
  rw.load(net); // load network in object "net" into the erandomwalk 
  rw.calcPhenotype(); // 
  rw.viablePhenotype=rw.phenotype;
  cout << "# universe phenotype: " << intarr2str(rw.phenotype) << endl;

	efile f1;
	efile f2;
	int file2[s2][45];
  int alaki[1][45];
	int i;
	int linecounter=0;
	estr str;
	estrarray parts;


	f2.open(argv[3],"r");
	linecounter=0;

	while (f2.readln(str)) {			// While the file isn't finished, read line by line
    int flag1 = str.find("#");
		int flag2 = str.find("<");
		if (flag1==-1 && flag2==-1){
			parts=str.explode(" ");
	
			for (i=0; i<45; i++) {file2[linecounter][i]=0;}
	
			for (i=0; i<parts.size(); ++i) {
 		 	  file2[linecounter][i]=parts[i].i();  
			}
			linecounter++;
		}
	}
	f2.close();
	int file2size = linecounter;


// Merging step
	int k=0;

	int startindex=26;

  estr outfile=fileclass+numb;
	cout << "# output file: "<<outfile << endl;
  efile fout;
 	fout.open(outfile,"w");
  int j;
	estrarray parts2;
  parts2=numb.explode(" ");
  j=parts2[0].i();


  f1.open(argv[2],"r");

	while (f1.readln(str)) {			// While the file isn't finished, read line by line
		int flag1 = str.find("#");
		int flag2 = str.find("<");
		if (flag1==-1 && flag2==-1){
			parts=str.explode(" ");

			for (i=0; i<45; i++) {alaki[1][i]=0;}

			for (i=0; i<parts.size(); ++i) {
			  alaki[1][i]=parts[i].i();} 

		  int tmp;
		  eintarray numarr1; 
		  for (k=0; k<45; ++k) {
			  if (alaki[1][k]>0) {
				  tmp = alaki[1][k];
				  tmp = tmp+startindex;
				  numarr1.add(tmp);
			   }
		   }

			eintarray finalarray = numarr1;
			for (k=0; k<45; ++k) {
				if (file2[j][k]>0) {
					tmp = file2[j][k];
					tmp = tmp+startindex;
					finalarray.add(tmp);
				}
			}

			// Check viability
			for (k = 0; k<finalarray.size(); ++k) {
				rw.disable(finalarray[k]);
			}

			rw.calcPhenotype();
			if (rw.isViable()) {
				
				eintarray sortedindex, tmparr;
				sortedindex = sort(finalarray);		// sort returns the sorted index list
				for (k = 0; k<sortedindex.size(); ++k) {
					tmparr.add(finalarray[sortedindex[k]]);
				}
				finalarray = tmparr;

				for (k=0; k<tmparr.size(); ++k) {
					tmparr[k] -= startindex;
				}
			
				estr zeroloc = intarr2str2(tmparr);
				fout.write(zeroloc+"\n");
			}

			for (k = 0; k<finalarray.size(); ++k) {
				rw.activate(finalarray[k]);
			}
			}
		}
	f1.close();
	fout.close();
	return(0);
	}

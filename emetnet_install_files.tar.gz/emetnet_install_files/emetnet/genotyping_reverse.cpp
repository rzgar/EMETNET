#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/eheap.h>
#include <algorithm>
#include <eutils/ernd.h>

estr solver="esolver_clp";
int netsize=-1;
int strict=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
double gendist=0.0;
enet net;
erandomWalk *prw=0x00;


int emain()
{ ldieif(argvc<3,"syntax: ./genotyping_reverse <universe.net> <file.dat> <file.net>");  
  eparseArgs(argvc,argv);
  ////////////////////////////////////////// Genotyping ///////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////  
  efile f1;
  efile f2;
  f1.open(argv[1],"r");
  f2.open(argv[2],"r");
  efile fw;
  fw.open(argv[3],"a");
  eintarray gen1;
  estr sttr;
  while (f2.readln(sttr)) {
	estrarray parts;
        parts=sttr.explode(" ");
        int tmp=0;
        for (int i=0;i<6588;i++){gen1.add(tmp);}
        for (int i=0;i<6588;i++){gen1[i]=parts[i].i();}
  }
  cout<<intarr2str2(gen1)<<endl;
  int count=0;
  while (f1.readln(sttr)) {
	//estrarray parts;
        //parts=sttr.explode(" ");
        if (gen1[count]==1){fw.write(sttr+"\n");}
        count++;
  }
  f1.close();
  f2.close();
  fw.close();
  return(0);
}

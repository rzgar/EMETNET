#include "enet.h"
#include <eutils/emain.h>
#include <eutils/estrarray.h>


#define MAX(a,b) (a>b?a:b)

estrarray ignoreList("C00080,C00001");

float compareReactions(elink* ri, elink* rj)
{
  int matched,matched2;
  int ignore,ignore2;
  int k,l;

  
  ignore=0;
  ignore2=0;

  for (k=0; k<ri->src.size(); ++k){
    if ( ignoreList.find(ri->src[k].node->id.substr(0,6))!=-1)
      { ++ignore; }
  }
  for (k=0; k<ri->dst.size(); ++k){
    if (ignoreList.find(ri->dst[k].node->id.substr(0,6))!=-1)
      { ++ignore; }
  }
  for (k=0; k<rj->src.size(); ++k){
    if (ignoreList.find(rj->src[k].node->id.substr(0,6))!=-1)
      { ++ignore2; }
  }
  for (k=0; k<rj->dst.size(); ++k){
    if (ignoreList.find(rj->dst[k].node->id.substr(0,6))!=-1)
      { ++ignore2; }
  }


  matched=0;

  for (k=0; k<ri->src.size(); ++k){
    if ( ignoreList.find(ri->src[k].node->id.substr(0,6))!=-1) continue;
    for (l=0; l<rj->src.size(); ++l){
      if (ri->src[k].node->id.substr(0,6) == rj->src[l].node->id)
        { ++matched; break; }
    }
  }
  for (k=0; k<ri->dst.size(); ++k){
    if ( ignoreList.find(ri->dst[k].node->id.substr(0,6))!=-1) continue;
    for (l=0; l<rj->dst.size(); ++l){
      if (ri->dst[k].node->id.substr(0,6) == rj->dst[l].node->id)
        { ++matched; break; }
    }
  }

  matched2=0;

  if (!rj->irreversible){
  for (k=0; k<ri->src.size(); ++k){
    if ( ignoreList.find(ri->src[k].node->id.substr(0,6))!=-1) continue;
    for (l=0; l<rj->dst.size(); ++l){
      if (ri->src[k].node->id.substr(0,6) == rj->dst[l].node->id)
        { ++matched2; break; }
    }
  }
  for (k=0; k<ri->dst.size(); ++k){
    if ( ignoreList.find(ri->dst[k].node->id.substr(0,6))!=-1) continue;
    for (l=0; l<rj->src.size(); ++l){
      if (ri->dst[k].node->id.substr(0,6) == rj->src[l].node->id)
        { ++matched2; break; }
    }
  }
  }

  int rlen1,rlen2;
  rlen1 = ri->src.size()+ri->dst.size();
  rlen2 = rj->src.size()+rj->dst.size();

  matched=MAX(matched,matched2);

  if (matched < rlen2-ignore2 || matched < rlen1-ignore)
    return(0.0);

  return(1.0); 
//  return((float)MAX(matched,matched2)/(float)(ri->src.size()+ri->dst.size()));
}

int compareAllReactions(enode& node1,enode& node2)
{
  int matched;
  int ir,jr;

  matched=0;
  for (ir=0; ir<node1.links.size(); ++ir){
    if (node1.links[ir]->info.size() && node1.links[ir]->info["M"]=="1") { ++matched; } // continue; }
    for (jr=0; jr<node2.links.size(); ++jr){
      if (compareReactions(node1.links[ir],node2.links[jr])>=0.9)
        { node1.links[ir]->info["M"]="1"; node2.links[jr]->info["M"]="1"; ++matched; cerr << *node1.links[ir] << " - " << *node2.links[jr] << endl; } //break; } 
    }
  }
  return(matched); //(float)matched/(float)net1.nodes[i].links.size());
}

int main()
{
  ldieif (argvc<3,"syntax: ./emetnet <file.net> <file2.net>");  

  enet net1;
  net1.load(argv[1]); 
  cout << "finished loading file: "<<argv[1] << endl;

  enet net2;
  net2.load(argv[2]);
  cout << "finished loading file: "<<argv[2] << endl;

  int matched;
  int i,j;

  for (i=0; i<net1.nodes.size(); ++i){
    for (j=0; j<net2.nodes.size(); ++j){
      if (net1.nodes[i].id.substr(0,6) == net2.nodes[j].id){
        matched=compareAllReactions(net1.nodes[i],net2.nodes[j]);
//        if (matched!=net1.nodes[i].links.size()){
//          cout << (net1.nodes[i].links.size()-matched) << "/"<< net1.nodes[i].links.size() << " reactions for "<<net1.nodes[i].id<< " did not match!" << endl;
//        }
//        else 
//          cout << "All reactions for: "<<net1.nodes[i].id<< " matched!" << endl;
        break;
      }
    }
  } 

  cout << net1 << endl;

  for (i=0; i<net2.links.size(); ++i){
    if (net2.links[i].info.size() && net2.links[i].info["M"] == "1") continue;

    cout << estr(net2.links[i].info) << ":";

    for (j=0; j<net2.links[i].src.size()-1; ++j){
      if (net2.links[i].src[j].rate!=1.0)
        cout << "("<< net2.links[i].src[j].rate <<") ";
      cout << net2.links[i].src[j].node->id << " + ";
    }
    if (net2.links[i].src[j].rate!=1.0)
      cout << "("<< net2.links[i].src[j].rate <<") ";
    cout << net2.links[i].src[j].node->id;

    if (net2.links[i].irreversible)
      cout << " --> ";
    else
      cout << " <=> ";

    for (j=0; j<net2.links[i].dst.size()-1; ++j){
      if (net2.links[i].dst[j].rate!=1.0)
        cout << "("<< net2.links[i].dst[j].rate <<") ";
      cout << net2.links[i].dst[j].node->id << " + ";
    }
    if (net2.links[i].dst[j].rate!=1.0)
      cout << "("<< net2.links[i].dst[j].rate <<") ";
    cout << net2.links[i].dst[j].node->id;
    
    cout << endl;
  }


  int count;
  count=0;
  for (i=0; i<net1.links.size(); ++i){
    if (net1.links[i].info.size() && net1.links[i].info["M"]==1)
      ++count;
  }
  cerr<<" " << count << "/"<<net1.links.size()<<" total links matched"<<endl;

  return(0);
}

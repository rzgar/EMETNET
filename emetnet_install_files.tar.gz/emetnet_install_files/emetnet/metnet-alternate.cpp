#include "enet.h"
#include "erandomwalk.h"

#include <eutils/logger.h>
#include <eutils/emain.h>

//#include <signal.h>

estr outnet="default.mnet";
estr solver="esolver_clp";
int netsize=-1;
int strict=0;
int force_away=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
int niter=10;
enet net;
enet net2;

estr mingenotypes="mingenotypes.dat";


erandomWalk *prw=0x00;

void save_state(int)
{
  efile f1("state.dat");
  f1.open("w");

  f1.write("strictViable="+estr(strict)+"\n");
  f1.write("periphery_only="+estr(periphery_only)+"\n");
  f1.write("mutate_transport"+estr(mutate_transport)+"\n");
  f1.write("internal_secretion="+estr(internal_secretion)+"\n");
  f1.write("iterations="+estr(niter)+"\n");
  if (prw)
    f1.write("net=eintarray("+intarr2str(prw->genotype)+")\n"); 
  f1.close();

  int i;
  prw->mingenotype.save(mingenotypes);
  for (i=0; i<prw->mincount.size(); ++i)
    cout << prw->mincount[i] << " ";
  cout << endl;

  exit(0);
}


int emain()
{
  epregister(solver);
  epregister(strict);
  epregister(periphery_only);
  epregister(mutate_transport);
  epregister(internal_secretion);
  epregister(only_viable);
  epregister(outnet);
  epregister(niter);

  eparseArgs(argvc,argv);
  ldieif(argvc<5,"syntax: ./metnet-randomw <kegg.net> <genotype.net> <REACTION> <fluxbounds.flx>");

/*
  struct sigaction sa;
  sa.sa_handler=&save_state;
  sigaction(SIGINT,&sa,0x00);
*/

  cout << "# reaction: "<<argv[3] << endl;

  net.load(argv[1]); 
  cout << "# global network: "<<argv[1] << endl;
  cout << "# reactions (global): " << net.links.size() << endl;
  net.correct_malformed();
  cout << "# non-malformed reactions: " << net.links.size() << endl;

  net2.load(argv[2]);
  cout << "# initial network: "<<argv[2] << endl;
  cout << "# reactions (initial): " << net2.links.size() << endl;

  erandomWalk rw(net,solver,strict);
  prw=&rw; 

  rw.periphery_only=periphery_only;
  rw.mutate_transport=mutate_transport;
  rw.internal_secretion=internal_secretion;
  rw.only_viable=only_viable;
  rw.setRSize(netsize);

  rw.getEnv(argvc,argv);

  rw.load(net2);
  rw.calcPhenotype();

  rw.viablePhenotype=rw.phenotype;
  if (net2.info.findkey("phetarget")!=-1){
    net.info.add("phetarget",net2.info["phetarget"]);
    str2intarr(net2.info["phetarget"],rw.viablePhenotype);
    cout << "# using phetarget from initial network file!"<<endl;
  }

  cout << "# viablePhenotype: " << intarr2str(rw.viablePhenotype) << endl;

  cout << "# strictViable: "<<strict<<endl;
  cout << "# force_away: "<< force_away<<endl;
  cout << "# periphery_only: "<<rw.periphery_only<<endl;
  cout << "# mutate_transport: "<<rw.mutate_transport<<endl;
  cout << "# internal_secretion: "<<rw.internal_secretion<<endl;
  cout << "# only_viable: "<<rw.only_viable<<endl;
  cout << "# phenotype: "<< intarr2str(rw.phenotype)<<endl;

  ldieif(!net.links.exists(argv[3]),"Reaction not found");

  rw.calcSuperess();

  bool isess=rw.findminWith2(net.links[argv[3]].i);

  if (outnet.len())
    net.saveactive(outnet);


  ldieif(!isess,"Reaction is not part of any minimal network");

  eintarray mingen(rw.genotype);

  rw.load(net2);
  rw.disable(net.links[argv[3]].i);
  eintarray genwoalt(rw.genotype);
  eintarray gentmp;
 
  bool first;
  int i,j;
  for (i=0; i<niter; ++i){
    rw.findminKeep(mingen);
    gentmp=rw.genotype;
    rw.load(genwoalt);
    first=false;
    for (j=0; j<rw.genotype.size(); ++j){
      if (mingen[j]==0 && gentmp[j]==1){
        cout << net.links[j] << endl;
//        if (!first){
          rw.disable(j);
//          first=true;
//        }
      }
    }
    genwoalt=rw.genotype;
    cout << " --- " << endl;
  }

//  rw.load(net2);
//  rw.findmin();

  return(0);
}

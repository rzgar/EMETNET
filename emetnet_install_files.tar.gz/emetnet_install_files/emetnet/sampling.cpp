#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <vector>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
#include <eutils/ernd.h>
using std::vector;


// array that will store pre-computed number of "on" bits in a 16bit value
char precomp_count_16bits[0x1u<<16];
// function to compute how many "on" bits exist in a 32bit (int) value
inline char count_bits(unsigned int i)
{
  int cbits=0;
  while (i){
    cbits += i&0x1u;
    i>>=1;
  }
  return(cbits);
}

// function that needs to be called at the beginning of a program (before any other code) to initialize the array with pre-computed values (bits_in_16bits)
void init_precomp_count()
{
  unsigned int i;
// iterates through all possible 16 bit values and initializes the array to the number of "on" bits in that value
  for (i=0; i<0x1u<<16; ++i)
    precomp_count_16bits[i]=count_bits(i);
}

// function to compute how many "on" bits exist in a 64bit (long int) value using the pre-computed table. Basically this takes the first the 64 bits and splits it into 16 + 16 + 16 +16. For each of those 16 bits sums the count using the table to look them up. 
int count_bits16(unsigned long i)
{
  return( precomp_count_16bits[i & 0xfffful] + precomp_count_16bits[(i>>16) & 0xfffful] +precomp_count_16bits[(i>>32) & 0xfffful] + precomp_count_16bits[(i>>48) & 0xfffful] );
}

// This function will return the hamming distance between two networks represented by 64bit values
inline int mnets_dist(unsigned long x,unsigned long y)
{
  return(count_bits16(x^y));
}

int sample_size=0;
int carbon_source=-1;
int network_size=0;
int hamming_dist=0;

int emain()
{
ldieif(argvc<9,"syntax: ./sampling <inputfile1> <inputfile2> <outputfile> -sample_size <x>  -network_size <ns>  -hamming_dist <hd> ");

epregister(sample_size);
epregister(carbon_source);
epregister(network_size);
epregister(hamming_dist);
eparseArgs(argvc,argv);

int x=sample_size;
int ns=network_size;
int index=carbon_source;
int hd=hamming_dist;

//Initialization
estr infile1=argv[1];
estr infile2=argv[2];
estr outfile=argv[3];

efile fin1;
efile fin2;
efile fout;
estr str1;
estr str2;
estrarray parts;

init_precomp_count();  // initialize the precomp_count array
unsigned long allnetworks[x]; 
unsigned long genbits=0x00ul; // start with a 64bit value representing the network with all bits set to zero
int counter1=0;
fin1.open(infile1,"r");
while (fin1.readln(str1)) {
      parts=str1.explode(" ");
      genbits=0x00ul;
      for (int i=0; i<parts.size(); ++i){
      genbits|=(0x01ul<<(parts[i].i()-1));
      }
      allnetworks[counter1]=genbits;
      counter1++;
}
fin1.close();

eintarray chosen;
eintarray uniquation;
for (int q=0;q<x;q++){chosen.add(-1);}
for (int i=0;i<x;++i){
     fin2.open(infile2,"r");
     double counter2=0;
     int numeration=0;
     eintarray candidates;
     while (fin2.readln(str2)) {
            parts=str2.explode(" ");
            genbits=0x00ul;
            for (int kk=0; kk<parts.size(); ++kk){genbits|=(0x01ul<<(parts[kk].i()-1));}
            int distance = mnets_dist(allnetworks[i],genbits);
            //double distance2=(double) distance;
            //estr dastan=distance2;
            //cout<<dastan<<endl;
            if (distance==hd){candidates.add(counter2);numeration++;}
            counter2=counter2+1;
            estr tobeout=counter2;
            //cout<<tobeout<<endl;
     }
     fin2.close();
     if (numeration>0){
         int terminatione=0;
         while (terminatione==0){
               int r = (int)(ernd.uniform()*numeration);
               int temp=candidates[r];
               int uniquer=1;
               for (int ll=0;ll<i;ll++){if (temp==uniquation[ll]){uniquer=0;}}
               fin2.open(infile2,"r");
               int counter3=0;
               while (fin2.readln(str2)) {
                      parts=str2.explode(" ");
                      if (temp==counter3){
                          genbits=0x00ul;
                          for (int i=0; i<parts.size(); ++i){genbits|=(0x01ul<<(parts[i].i()-1));}
                          break;
                      }
                      counter3++;
               }
               fin2.close();
               for (int uu=0;uu<x;uu++){int dest=mnets_dist(allnetworks[uu],genbits);if (dest==0){uniquer=0;}}
               if (uniquer==1){
                   uniquation.add(temp);
                   chosen[i]=temp;
                   terminatione=1;
               }
         }
     }
}

fout.open(outfile,"a");
for (int i=0;i<x;++i){
     if (chosen[i]==-1){fout.write("\n");}
     else {
          fin2.open(infile2,"r");
          int counter3=0;
          int numeration=0;
          eintarray candidates;
          while (fin2.readln(str2)) {
                 parts=str2.explode(" ");
                 if (chosen[i]==counter3){fout.write(str2+"\n");break;}
                 counter3++;
          }
          fin2.close();
     }
}
return(0);
}

#ifndef __ENET__
#define __ENET__

#ifndef _WIN32
 #include "emetnet-config.h"
#else
 #ifndef WINVER                // Allow use of features specific to Windows 95 and Windows NT 4 or later.
  #define WINVER 0x0501        // Change this to the appropriate value to target Windows 98 and Windows 2000 or later.
 #endif

 #ifndef _WIN32_WINNT        // Allow use of features specific to Windows NT 4 or later.
  #define _WIN32_WINNT 0x0501        // Change this to the appropriate value to target Windows 98 and Windows 2000 or later.
 #endif                       

 #ifndef _WIN32_WINDOWS        // Allow use of features specific to Windows 98 or later.
  #define _WIN32_WINDOWS 0x0501 // Change this to the appropriate value to target Windows Me or later.
 #endif

 #include "emetnet-win32-config.h"
#endif

#include <eutils/estr.h>
#include <eutils/eintarray.h>
#include <eutils/estrhashof.h>
#include <eutils/estrarray.h>

#include <eutils/vector2.h>
#include <eutils/earrayof.h>
#include <eutils/earray.h>

#include <eutils/ematrix.h>

class elink;

class enode
{
 public:
  int i;
  estr id;
  ebasicarray<enode*> nodes;
  ebasicarray<elink*> links;

  enode();
  enode(const estr &id);

  enode &operator=(const enode &node);
  bool operator==(const enode &node) const;
};


class elinkelem
{
 public:
  elinkelem();
  elinkelem(enode *node,double rate);
  enode* node;
  double rate;
};

class elink
{
 public:
  int i;
  estr id;
  estrarray info;
  bool active;
  bool transport;

  bool irreversible;
  earray<elinkelem> src;
  earray<elinkelem> dst;

  void invert();
};


class enet
{
 public:
  estrhashof<enode> nodes;
  estrhashof<elink> links;
  int total_elements;

  estrarray info;

  int nullmatrixrows;
  double* nullmatrix;

  int transport_count;

  earrayof<evector2,estr> fluxbounds;

  enode* getnode(const estr &nodeid);
//  void   setlink(int node1,int node2);

//  void load_fluxbounds(estr filename="fluxbounds.flx");
  void load_nullmatrix(estr filename="kmat.smat");

  void remove_malformed();
  void correct_malformed();

  enet();
  ~enet();

  void addlink(estr line);
  void addlink(const elink& link);

  void getActive(eintarray& arr);
  void setActive(eintarray& arr);

  void save(estr filename);
  void saveactive(const estr& filename);
  void saveactive(eintarray& genotype,const estr& filename);
  void load(estr filename);
  void load_fast(estr &data);
  void load_robust(estr &data);

  void stoichiomatrix(ematrix& m);
};

ostream &operator<<(ostream &stream,enet &net);
ostream &operator<<(ostream &stream,elink &link);

#endif


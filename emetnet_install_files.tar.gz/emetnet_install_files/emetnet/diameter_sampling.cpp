#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/eheap.h>
#include <algorithm>
#include <eutils/ernd.h>

estr solver="esolver_clp";

int strict=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
enet net;
erandomWalk *prw=0x00;

int num=0; 

int emain()
{ ldieif(argvc<3,"syntax: ./diameter_sampling  <file.dat>  --num ");  
  epregister(num);
  eparseArgs(argvc,argv);
  estr sizstr=argv[1];
  if (num>100000){
     //////////////////////////// Donor /////////////////////////////
     cout<<"Type 1: "<<sizstr<<endl;   
     eintarray pop;
     for (int i=0; i<num; ++i) {pop.add(i);}
     int tmp1; 
     for (int i=(num-1); i>=0; --i) {
          int r = (int)(ernd.uniform()*i);
          tmp1 = pop[r];
          pop[r] = pop[i];
          pop[i]=tmp1;
     }
     eintarray pop1;
     for (int j=0;j<100000;j++){
          int x=pop[j];
          pop1.add(x);
     }
     eintarray sorted=sort(pop1);
     eintarray selected;
     for (int j=0;j<100000;j++){
          int y=sorted[j];
          selected.add(pop1[y]);
     }
     /////////////////////////////////////////////////////////////////
     estr outstr=sizstr+"_sampled";
     efile outfile;
     outfile.open(outstr,"a");
     for (int j=0;j<100000;j++){outfile.write(intarr2str2(selected[j])+"\n");}
     outfile.close();
  }
  else {cout<<"Type 2: "<<sizstr<<endl;}
}





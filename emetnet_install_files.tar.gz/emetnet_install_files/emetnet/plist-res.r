read 'plst' (0) "Info.plist";

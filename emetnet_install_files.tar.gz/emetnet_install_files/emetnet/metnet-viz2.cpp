
#include "enet.h"

#include <eutils/logger.h>
#include <eutils/vector2.h>
#include <eutils/ernd.h>

#include <edlib-2/edlib.h>


//ernd rnd;

ewinsys winsys;
ewindow win;

class edrawnode
{
 public:
  int i;
  bool painted;

  evector2 pos;
  evector2 pos2;
  evector2 acc;

  bool active;

  edrawnode();
  edrawnode(int i);
  edrawnode(int i,const evector2& pos);

  void draw(float width,float height,const estr &name);  
};

/*
class edrawlinknode
{
 public:
  
};
*/

edrawnode::edrawnode(){}
edrawnode::edrawnode(int _i): i(_i),active(false),pos(evector2(ernd.uniform(),ernd.uniform())),pos2(pos) {}
edrawnode::edrawnode(int _i,const evector2& _pos): i(_i),active(false),pos(_pos),pos2(pos) {}



#define moveTof(a,b) moveTo((int)(a),(int)(b))
#define lineTof(a,b) lineTo((int)(a),(int)(b))
#define printf(a,b,c) print((int)(a),(int)(b),c)

void edrawnode::draw(float width,float height,const estr &name)
{
  if (active) win.setColor(ecRed);
  else win.setColor(ecWhite);
  win.moveTof(pos.x*width-10,pos.y*height);
  win.lineTof(pos.x*width+10,pos.y*height);
  win.moveTof(pos.x*width,pos.y*height-10);
  win.lineTof(pos.x*width,pos.y*height+10);
  win.printf(pos.x*width+20,pos.y*height+20,name);
}

class edrawnet
{
 public:
  earray<edrawnode> nodes;
  enet *net;
  float forcefactor;

  int shells;
  int inode;

  edrawnet(enet &net);

  void shell_checkadd(int i, int s);
  void shell_remove();
  void shell_check(int i, int s);
  void shell_reset();

  int node_find(int ni);
  bool node_isconnected(int i,int j);
  elink* node_isconnected_reaction(int i,int j);
  int node_connection_type(int i,int j,elink *l);

  void node_next();
  int  hit(int x,int y);
  bool click(int x,int y);
  void move(int in,int x,int y);

  void nodes_update();
  void acc_reset();
  void acc_update();
  void pos_update();

  void update();
  void draw();
};

const int sw=1280;
const int sh=1024;

edrawnet::edrawnet(enet &_net): net(0x00)
{
  net=&_net;
  forcefactor=0.06;
  shells=2;

  int i;

  for (i=0; i<_net.nodes.size(); ++i){
    nodes.add(edrawnode(i));
  }
  nodes[0].active=true;
  inode=0;
  // after adding nodes, lets let the system run for some iterations into a more stable form
//  for (i=0; i<net->nodes.size()*100; ++i)
//    update();
}

void edrawnet::shell_reset()
{
  int i;
  for (i=0; i<nodes.size(); ++i)
    nodes[i].painted=false;
}

int edrawnet::node_find(int ni)
{
  int i;
  for (i=0; i<nodes.size(); ++i){
    if (ni==nodes[i].i) return(i);
  }
  return(-1);
}

void edrawnet::shell_check(int i, int s)
{
  int a,r;

  nodes[i].painted=true;

  if (!s) return;

  --s;
  for (a=0; a<net->nodes[i].nodes.size(); ++a){
    r=node_find(net->nodes[i].nodes[a]->i);
    if (r!=-1)
      shell_check(r,s);  
  }
}

void edrawnet::shell_remove()
{
  int i;
  for (i=0; i<nodes.size(); ++i){
    if (!nodes[i].painted){
//      if (inode > i) --inode;
      nodes.erase(i); --i;
    }
  }
}

void edrawnet::shell_checkadd(int i, int s)
{
  int a,r;

  if (nodes[i].painted) return;

  nodes[i].painted=true;

  if (!s) return;

  estrarray ignore("pyr,h2o,atp,adp,co2,o2,nad,nadh,nadp,nadph,h,nh4,ppi,C00080,C00001,C00002,C00009,C00003,C00004,C00006,C00008,C00013,C00011,C00014,C00005,C00007");

  --s;
  for (a=0; a<net->nodes[nodes[i].i].nodes.size(); ++a){
    if (node_isconnected_reaction(nodes[i].i,net->nodes[nodes[i].i].nodes[a]->i) != 0x00){
      r=node_find(net->nodes[nodes[i].i].nodes[a]->i);
      if (r!=-1)
        shell_checkadd(r,s);
      else if ( ignore.find(net->nodes[nodes[i].i].nodes[a]->id) == -1){
        nodes.add(edrawnode(net->nodes[nodes[i].i].nodes[a]->i));
        r=node_find(net->nodes[nodes[i].i].nodes[a]->i);
        nodes[r].pos = nodes[r].pos*0.1 + nodes[i].pos;
        nodes[r].painted=false;
        shell_checkadd(r,s);
      }
    }
  }
}

void edrawnet::acc_reset()
{
  int i;
  for (i=0; i<nodes.size(); ++i)
    { nodes[i].acc.x = 0.0; nodes[i].acc.y = 0.0; }
}


bool edrawnet::node_isconnected(int i,int j)
{
  if (!net->nodes[i].nodes.size()) return(false);

  if (net->nodes[ i ].nodes.find(&net->nodes[j]) != -1) return(true);

  return(false);
}

int edrawnet::node_connection_type(int i,int j,elink* l)
{
  if (!l->irreversible) return(0);
 
  int m;

  for (m=0; m<l->src.size(); ++m){
    if (l->src[m].node->i == i)
      return(1);
    if (l->src[m].node->i == j)
      return(2);
  }
  lderror("nodes were not found in source list...");
  return(0);
}

elink* edrawnet::node_isconnected_reaction(int i,int j)
{
  if (!net->nodes[i].nodes.size())
    return(0x00);

  int k,m;
  elink* l;
  bool found;

  for (k=0; k<net->nodes[ i ].links.size(); ++k){
    l = net->nodes[ i ].links[k];
    found=false;
    for (m=0; m<l->src.size(); ++m){
      if (l->src[m].node->i == i || l->src[m].node->i == j){
        if (found) break;
        found=true;
        break;
      }
    }
    if (!found) continue;

    for (m=0; m<l->dst.size(); ++m){
      if (l->dst[m].node->i == i || l->dst[m].node->i == j){
        if (found) return(l);
      }
    }
  }

  return(0x00);
}

#define MAX(a,b) (a<b)?(b):(a)
#define MIN(a,b) (a<b)?(a):(b)

void edrawnet::acc_update()
{
  int i,j;
  evector2 dir;
  float dist;
  float idist;
  float idist2;

  float deg;

  evector2 acc;

  for (i=0; i<nodes.size(); ++i){
    for (j=i+1; j<nodes.size(); ++j){
      acc.x=0.0;acc.y=0.0;
      dir = nodes[j].pos - nodes[i].pos;
      dist = sqrt(dir*dir);
      idist = 1.0/dist;
      idist2= 2.0/(dist+0.3);
      dir = dir*idist;
      
      // constant attraction force between all nodes
      acc += forcefactor*idist2*dir;
      // inverse distance repulsion force between all nodes
      acc -= 0.05*idist*dir; //0.001*idist*dir;
      // if nodes are linked, then add constant linear attraction force
//      cout << net->nodes[i].nodes.find(j) << endl;


      if( node_isconnected_reaction(nodes[i].i,nodes[j].i) != 0x00){
        deg = (float)(net->nodes[nodes[i].i].nodes.size()+net->nodes[nodes[j].i].nodes.size());
        acc += (forcefactor*(dist*2.0+1.0)*20.0)*dir;   // *100.0/(deg*deg))*dir; //forcefactor*0.5
      }

//      acc += 1.0E-2*evector2(0.5-ernd.uniform(),0.5-ernd.uniform());

      nodes[i].acc += acc;
      nodes[j].acc -= acc;
    }
  }
  for (i=0; i<nodes.size(); ++i){
    // limit maximum applied force to nodes to avoid instabilities in the dynamics
    
  }
}

void edrawnet::move(int in,int x,int y)
{
  int i;
  evector2 mouse((float)x/(float)sw,(float)y/(float)sh);

  nodes[node_find(in)].pos=mouse;
}

int edrawnet::hit(int x,int y)
{
  int i;
  evector2 mouse(x,y);
  evector2 node;

  for (i=0; i<nodes.size(); ++i){
    node=evector2(nodes[i].pos.x*(float)sw,nodes[i].pos.y*(float)sh);
    if ((node-mouse).len()<=10.0){
      return(nodes[i].i);
    }
  }
  return(-1);
}

bool edrawnet::click(int x,int y)
{
  int i;
  evector2 mouse(x,y);
  evector2 node;

  for (i=0; i<nodes.size(); ++i){
    node=evector2(nodes[i].pos.x*(float)sw,nodes[i].pos.y*(float)sh);
    if ((node-mouse).len()<=10.0){
      nodes[node_find(inode)].active=false;
      inode=nodes[i].i;
      nodes[node_find(inode)].active=true;
      return(true);
    }
  }
  return(false);
}

void edrawnet::pos_update()
{
  int i;
  float in2;
  float drag;

  in2 = 0.001; //*(1.0+1.0/nodes.size());
  drag= 0.01;
  evector2 tpos;
  for (i=0; i<nodes.size(); ++i){
    // drag factor of 0.9,  time factor of 0.1
    tpos = nodes[i].pos;
    nodes[i].pos += drag*(nodes[i].pos - nodes[i].pos2) + in2*nodes[i].acc;
    nodes[i].pos2 = tpos;
  }
}

void edrawnet::nodes_update()
{
/*
  shell_reset();

  shell_checkadd(node_find(inode),shells);

  shell_remove();
*/
}

void edrawnet::update()
{
  nodes_update();

  acc_reset();

  acc_update();
  pos_update();
}


void edrawnet::node_next()
{
  static int o=0;

  if (o < net->nodes.size()) ++o;

  nodes[node_find(inode)].active=false;
  if (node_find(o)==-1)
    nodes.add(edrawnode(o));
  inode=o;
  nodes[node_find(inode)].active=true;
}


void drawArrow(float x1,float y1,float x2,float y2,int type)
{
  evector2 p1(x1,y1);
  evector2 p2(x2,y2);
  evector2 d,d1,d2;
  d=(p2-p1).unit();
  d1=d.rot(M_PI/16.0)*12.0;
  d2=d.rot(-M_PI/16.0)*12.0;

  switch(type){
    case 0:
      win.setColor(0x99FF99);
      win.moveTof(x1+d1.x,y1+d1.y);
      win.lineTof(x1,y1);
      win.lineTof(x1+d2.x,y1+d2.y);
      win.moveTof(x2-d1.x,y2-d1.y);
      win.lineTof(x2,y2);
      win.lineTof(x2-d2.x,y2-d2.y);
     break;
    case 1:
      win.setColor(0x9999FF);
      win.moveTof(x2-d1.x,y2-d1.y);
      win.lineTof(x2,y2);
      win.lineTof(x2-d2.x,y2-d2.y);
     break;
    case 2:
      win.setColor(0x9999FF);
      win.moveTof(x1+d1.x,y1+d1.y);
      win.lineTof(x1,y1);
      win.lineTof(x1+d2.x,y1+d2.y);
     break;
    default:
     ldwarn("this shouldnt happen");
  }
  win.moveTof(x1,y1);
  win.lineTof(x2,y2);
}

void edrawnet::draw()
{
  int i,j;
//  for (i=0 ; i< 10; ++i)
  update();

  float width,height;
  
  width=sw; height=sh;


  elink* l;

  win.setColor(ecGray);

//  cout << nodes.size() << " --- " << net->nodes.size() << endl;
  for (i=0; i<nodes.size(); ++i){
    for (j=i+1; j<nodes.size(); ++j){
//      cout << i << " " << j << endl;
      l=node_isconnected_reaction(nodes[i].i,nodes[j].i);
      if (l!=0x00)
        drawArrow( width*nodes[i].pos.x , height*nodes[i].pos.y, width*nodes[j].pos.x, height*nodes[j].pos.y, node_connection_type(nodes[i].i,nodes[j].i,l));
    }
  }

//  win.setColor(ecWhite);
  for (i=0; i<nodes.size(); ++i)
    nodes[i].draw(sw,sh,net->nodes[ nodes[i].i ].id);
}
 



int main(int argvc,char *argv[])
{
  ldieif(argvc<2,"syntax: metnet-viz <file.net>");

  win.create(sw,sh);

  enet net;

  net.load(argv[1]);

  edrawnet drawnet(net);


/*
  int i;
  for (i=0; i<drawnet.nodes.size(); ++i){
    cout << drawnet.nodes[i].pos << endl;
  }
*/
  evector2 drag;
  int begindrag;

  begindrag = -1;
  
  while(winsys.processMessages()){
    win.clear(ecBlack);

    drawnet.draw();
    
    win.flip();


    if (win.isPressed('1'))
      drawnet.shells=1;
    if (win.isPressed('2'))
      drawnet.shells=2;
    if (win.isPressed('3'))
      drawnet.shells=3;
    if (win.wasPressed(VK_RIGHT))
      drawnet.node_next();
    if (win.isPressed(VK_DOWN))
      drawnet.forcefactor = drawnet.forcefactor*0.999;
    if (win.isPressed(VK_UP))
      drawnet.forcefactor = drawnet.forcefactor/0.999;
    if (win.isLeftButtonPressed() && begindrag!=-2){
      if (drag==evector2(0.0,0.0)){
        drag=evector2(win.mousePos.x,win.mousePos.y);
      } else if (begindrag!=-1){
        drawnet.move(begindrag,(int)win.mousePos.x,(int)win.mousePos.y);
      } else if (drag != win.mousePos){
        begindrag=drawnet.hit((int)drag.x,(int)drag.y);
        if (begindrag!=-1)
          drawnet.move(begindrag,(int)win.mousePos.x,(int)win.mousePos.y);
        else
          begindrag=-2;
      }
      win.setColor(ecWhite);
      win.print(20,20,"click! ("+estr(win.mousePos.x)+","+estr(win.mousePos.y)+")");
    }else if (drag!=evector2(0.0,0.0)){
      if (begindrag==-1)
        drawnet.click((int)win.mousePos.x,(int)win.mousePos.y);
      drag=evector2(0.0,0.0);
      begindrag=-1;
    }
  }

  return(0);
}

#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
#include <vector>
using std::vector;

// Clust function definition //
void clust(int &count, vector<int> &vec, const int mat2[][45], const int j1)
{
int ind=0;
int init=0;
for (int i=0; i<j1;++i){
    if (vec[i]==0){
        vec[i]=count;
        ind=1;
        init=i;
        break;
    }
}
if (ind==1){
   for (int q=0;q<2;++q){
      for (int k=init;k<j1;++k){
        if (vec[k]==count){
            for (int l=init;l<j1;++l){
                if (vec[l]==0){
                    int sum=0;
                    for (int j=0;j<45;++j){
                        if (mat2[k][j]!=mat2[l][j])
                            {sum=sum+1;}
                         }
                    if (sum==2)
                        vec[l]=count;
              }
            }
           }
        else if (vec[k]==0){
            for (int l=init; l<j1; ++l){
                if (vec[l]==count){
                    int sum=0;
                    for (int j=0;j<45;++j){
                        if (mat2[k][j]!=mat2[l][j])
                            {sum=sum+1;}
                         }
                    if (sum==2)
                        vec[k]=count;
                   }
                }
            }
        else;
        }

    }

count++;
clust(count,vec,mat2,j1);
}
}

int emain() {
ldieif(argvc<4,"syntax: ./connected_comp.cpp <inputfilename.dat> <number of lines> <length of lines>");
// Arguments
estr sizestr=argv[1];
estr numb1=argv[2];
estr numb2=argv[3];
int j1,j2;
estrarray parts1;
estrarray parts2;
parts1=numb1.explode(" ");
parts2=numb2.explode(" ");
j1=parts1[0].i();
j2=parts2[0].i();
epregister(sizestr);
// Reading the files and filling the arrays
estr str;
estrarray parts;
efile f;
int j,tmp;
int intcount;
int mat2[j1][45];
intcount=0;
f.open(argv[1],"r");
while (f.readln(str)) {
      parts=str.explode(" ");	
      for (int l=0; l<45; ++l) {
      mat2[intcount][l]=1;
      }
      for (j=0; j<parts.size(); ++j) {	
			    tmp = parts[j].i();						 					
          mat2[intcount][tmp-1]=0;	
      } 
      intcount++; 
}
f.close();
// Clustering
int count=1;
vector<int> vec(j1);
clust(count,vec,mat2,j1);
// Writing the result
efile files;
estr test;
estr intstr;
estr intstr2;
test=sizestr+"_Connected.dat";
eintarray tmparr;
eintarray tmparr2;
int tempint2;
int tempint;

files.open(test,"a");
for (int n=0;n<j1;++n){
    tempint=vec[n];
    tmparr.add(tempint);
}
for (int m=0;m<45;++m){
    tempint2=mat2[1][m];
    tmparr2.add(tempint2);} 
intstr = intarr2str2(tmparr);
intstr2 = intarr2str2(tmparr2);
files.write(intstr2+"\n");
files.write(intstr+"\n");
files.close();
}

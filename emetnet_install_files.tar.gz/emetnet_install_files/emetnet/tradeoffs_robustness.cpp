#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <vector>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
using std::vector;
//Initialization stuff
estr solver="esolver_clp";
int netsize=-1;
int strict=0;
int force_away=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
enet net;
erandomWalk *prw=0x00;
int sample_size=0;
int genotype_size=0;
int carbon_source=-1;

int emain()
{
ldieif(argvc<4,"syntax: ./tradeoffs_robustness  <universe.net>  <inputfile> -genotype_size <y> <fluxbounds.flx>");
epregister(solver);
epregister(sample_size);
epregister(genotype_size);
epregister(carbon_source);
eparseArgs(argvc,argv);
//Must be done rw stuff
net.load(argv[1]); 
net.correct_malformed();
erandomWalk rw(net,solver,strict);
prw=&rw; 
rw.periphery_only=periphery_only;
rw.mutate_transport=mutate_transport;
rw.internal_secretion=internal_secretion;
rw.only_viable=only_viable;
rw.setRSize(netsize);
rw.getEnv(argvc,argv);
rw.load(net);
rw.calcPhenotype();
rw.viablePhenotype=rw.phenotype;
//Initialization
estr infile=argv[2];
estr outfile=infile+"_trd_rb";
int x=1000;
int y=genotype_size;
int z=45-y;

efile fin;
efile fout;
estr str;
estrarray parts;
int i;
int j;
int tmp;
int absent[x][z];
for (i=0; i<x; ++i){
    for (j=0; j<z; ++j){
        absent[i][j]=0;
    }
}

int present[x][y];
for (i=0; i<x; ++i){
    for (j=0; j<y; ++j){
        present[i][j]=0;
    }
}

//Reading input files and saving in the corresponding arrays
int counter=0;
fin.open(argv[2],"r");
while (fin.readln(str)) {
      parts=str.explode(" ");
      for (i=0; i<parts.size(); ++i) {
			    tmp =parts[i].i();
          absent[counter][i]=tmp;
      }
      counter=counter++;
}
fin.close();

int temp_vec[x][45];
for (i=0;i<x;++i){
    for (j=0; j<45; ++j){
        temp_vec[i][j]=1;
    }
}
for (i=0; i<x; ++i){
    for (j=0;j<z;++j){
        temp_vec[i][(absent[i][j])]=0;
    }
}
for (i=0; i<x; ++i){
    int counted=0;
    for (j=0;j<45;++j){
        if (temp_vec[i][j]==1){
           present[i][counted]=j;
           counted=counted++;
        }
    }
}        
/////////////////////////////////////////////////////// Neighborhood analysis ///////////////////////////////////////////////////////////////////////////
int k;
int l;
int m;

fout.open(outfile,"a");

for (i=0;i<x;++i){
        //Initialization
        int semi_final[z];for (m=0;m<z;++m){semi_final[m]=0;}
        for (m=0;m<z;++m){semi_final[m]=absent[i][m];}
        //processing the neighborhood of the first genotype
        for (l=0;l<y;++l) {
        for (m=0;m<z;++m){int tmp=semi_final[m]+26;rw.disable(tmp);}
        int tomp=present[i][l]+26; rw.disable(tomp);
        rw.calcPhenotype();
        eintarray changed=rw.phenotype;
        for (m=0;m<z;++m){int tmp=semi_final[m]+26;rw.activate(tmp);}
        rw.activate(tomp);
        estr intstr = intarr2str2(changed);
			  fout.write(intstr+"\n"); 
        }
                         
}

fout.close();
return(0);
}

#include "enet.h"
#include "erandomwalk.h"

#include <eutils/emain.h>
#include <eutils/ernd.h>
#include <eutils/eregexp.h>

/*
void random_phenotype(eintarray& arr,int num)
{
  lddieif(num<0 || num>solvers.size(),"random_phenotype(): num is out of bounds");

  while (arr.size() < solvers.size())
    arr.add(0);

  int i;
  while (num){
    i=(int)(ernd.uniform()*solvers.size());
    if (arr[i]==0){
      --num;
      arr[i]=1;
    }
  }
}
*/


void random_phenotype(eintarray& phe_target,eintarray& phe,int phecount_target){
  while (phe_target.size()<phe.size()) phe_target.add(0);
  int i;
  for (i=0; i<phe_target.size(); ++i)
    phe_target[i]=0;

  int phecount=countPhenotype(phe);

  int j;
  int tmp;
  for (i=0; i<phecount_target; ++i){
    tmp=ernd.uniform()*phecount;
    for (j=0; j<phe.size(); ++j){
      if (phe[j]==1 && phe_target[j]==0){
        if (tmp==0) {
          phe_target[j]=1;
          --phecount;
          break;
        }
        --tmp;
      }
    }
  }
}

int emain()
{
  ldieif (argvc<4,"syntax: ./metnet-findphe [-phe count] [-outnet file.net] [-solver clp|cplex] <file.net> <starter.net> <env.flx env2.flx ...>"); 

  int rcount=0;
  int phe=0;

  estr outnet="default.net";
  estr solver="cplex";
  estr phetarget;

  epregister(rcount);
  epregister(phe);
  epregister(phetarget);

  epregister(outnet);
  epregister(solver);
  

  enet net;
  net.load(argv[1]); 
  net.correct_malformed();

  enet net2;
  net2.load(argv[2]);

  epregisterClassProperty(erandomWalk,solvername);

  erandomWalk rw(net,solver,0);
  epregister(rw);

  cout << "# solver: "<<rw.solvername << endl;
  cout << "# global network: "<<argv[1] << endl;
  cout << "# total reactions (global): " << net.links.size() << endl;

  rw.getEnv(argvc,argv);

  ldieif(phe>rw.solvers.size(),"selected phenotype ("+estr(phe)+") count is higher than total environments given ("+estr(rw.solvers.size())+")");
  
  

  cout << "# initial network: " << argv[2] << endl;
  cout << "# total reactions (initial): " << net2.links.size() << endl;

  rw.load(net2);
  rw.calcPhenotype();

  if (rcount>0)
    rw.setRSize(rcount);
  else
    rcount=rw.count;

  cout << "# rcount: "<< rcount << endl;
  cout << "# phe: "<< phe << endl;
  cout << "# target network size: " << rcount << endl;

  int m,tmpmin;
  eintarray phe_s;
  eintarray phe_target;
  eintarray oldphe;
  phe_s=rw.phenotype;
  oldphe=rw.phenotype;

  m=countPhenotype(phe_s);
  cout << "# phenotype (initial): " << intarr2str(phe_s) <<endl;

  if (phetarget.len())
    str2intarr(phetarget,phe_target);
  else{
    ldieif(phe==0,"random phenotype size not specified (use -phe parameter)");
    ldieif(phe>m,"expected network that grows on more than target number of environments");
    random_phenotype(phe_target,rw.phenotype,phe);
  }

  cout << "# target phenotype: " << intarr2str(phe_target) << endl;
  rw.viablePhenotype=phe_target;

  ldieif(!rw.isViable(),"initial network not viable on target phenotype");

  int i; 
  i=0;
  while (1){
    rw.mutate();
    rw.updatePhenotype();

    tmpmin = countPhenotype(rw.phenotype);
    if (tmpmin > m || tmpmin==0 || tmpmin < phe || !rw.isViable()){
      cout << "# " << rw.acount << " " << rw.printPhenotype() << endl;
      rw.revert();
      rw.phenotype=oldphe;
      continue;
    }
    cout << rw.acount << " " << rw.printPhenotype() << endl;

    m=tmpmin;
    if (m==phe)
      break;
    oldphe=rw.phenotype;
    ++i;
    if (i==20000){
      cout << "# warning: genotype for this phenotype was not found in 10'000 iterations, stopping simulation"<<endl;
      exit(1);
    }
  }

  cout << "# found genotype with target phenotype: "<< rw.printPhenotype() << endl;
  cout << "# target phenotype: "<<intarr2str(phe_target)<<endl;

  cout << "# looking for network with target size" << endl;
  // we found the phenotype, now lets make sure we have the right network size
  rw.strictViable=1;
  rw.viablePhenotype=rw.phenotype;
  for (i=0; i<10000 && rw.acount!=rw.count; ++i){
    rw.mutate();
    rw.updatePhenotype();
    if (!rw.isViable()){
      rw.phenotype=rw.viablePhenotype;
      rw.revert();
      cout << "# "<< i << " " << rw.count << " " << rw.acount << endl;
    }
    cout << i << " " << rw.count << " " << rw.acount << endl;
  }

  ldieif(rw.acount!=rw.count,"did not reach target network size");


/*
  eintarray phe_f,gen_f;

  gen_f = rw.genotype;
  phe_f = rw.phenotype;

  cout << "# Starting "<<netcount<<" semi steepest descents (1'000 iterations each) away from found network:" << endl;

  for(i=0; i<1000; ++i){
    rw.mutate_away(gen_f);
    rw.updatePhenotype();
    if (rw.phenotype != phe_f){ rw.revert(); rw.phenotype=phe_f; continue; }
  }
*/

  net.saveactive(outnet);

  return(0);
}

#include "edrawnet.h"

#include <eutils/ernd.h>

edrawnet::edrawnet(enet& _net): net(&_net),rootnode(0x00),infonode(0x00),dragnode(0x00),infolink(0x00),vpoint(evector2(0,0)),startVPoint(evector2(0,0)),mouseDrag(false)
{
  iw = 1.0/1024.0; ih = 1.0/786.0;

  forcefactor=0.050;
  ffactorMLink=1.0;
  ffactorTLink=1.0;
  ffactorSDRepulsion=1.0;

  frangeRepulsion=0.15;
  ffactorRepulsion=1.0;

  frangeAttraction=0.20;
  ffactorAttraction=0.0;

}

bool edrawnet::areLinked(edrawnode* node1,edrawnode* node2)
{
  if (node1->node->nodes.find(node2->node)!=-1){
    int i;
    for (i=0; i<links.size(); ++i){
      if (links[i].inLink(node1) && links[i].inLink(node2))
        return(true);
    }
  }
  return(false);
}

void edrawnet::doCreate()
{
//  infopopup.create(*this,left,top,200,300);
//  infopopuparr.create(infopopup,1,1,infopopup.width-2,infopopup.height-2);
//  infopopup.hide();
//  popupWindow=0x00;


//  check();

  int i;
  for (i=0; i<nodes.size(); ++i){
    cout << i <<": " << nodes[i].pos << endl;
  }
}

void edrawnet::reset()
{
  nodes.clear(); links.clear();
}

void edrawnet::addAll(const eintarray& genotype)
{
/*
  int i,r;
  for (i=0; i<reactioninfo.size(); ++i){
    rinfo = reactioninfo["id"][i].get<estr>();
    if (net->links.exists(rinfo) && rinfo != "EC001" && !links.exists(rinfo))
      links.addref(rinfo,new edrawlink(this,net->links[rinfo],reactioninfo["rpairs"][i].get<estr>(),evector2(0.5,0.5)));
  }
*/
  int i;
  estr rinfo;
  for (i=1; i<genotype.size(); ++i){
    if (genotype[i]==1 && !links.exists(net->links[i].info[0])){
      rinfo = net->links[i].info[0];
      links.addref(rinfo,new edrawlink(this,net->links[rinfo],net->links[rinfo].info["rpairs"],evector2(0.5,0.5)));
    }
  }
}
void edrawnet::showOnly(const eintarray& genotype)
{
  int i;

  estr rinfo;
  for (i=1; i<genotype.size(); ++i){
    if (genotype[i]==0 && links.exists(net->links[i].info[0]))
      { delete &links.values(net->links[i].info[0]); links.erase(net->links[i].info[0]); }
  }

  for (i=0; i<nodes.size(); ++i){
    if (nodes[i].node!=0x00)
      cout << nodes[i].node->id << " " << nodes[i].linkcount << endl;
    if (nodes[i].linkcount==0) { nodes.erase(i); --i; }
  }
  
  
}
void edrawnet::highlite(const eintarray& genotype)
{
  int i;
  for (i=0; i<links.size(); ++i)
    links[i].highlite=false;

  estr rinfo;
  for (i=1; i<genotype.size(); ++i){
    if (genotype[i]==1 && links.exists(net->links[i].info[0])){
      links.values(net->links[i].info[0]).highlite=true;
    }
  }
}
void edrawnet::addPathway(const estr& pathway)
{
  int i,r;
  for (i=0; i<reactioninfo.size(); ++i){
    r=reactioninfo["pathways"][i].get<estr>().find(pathway);
    if (r!=-1){
      if (net->links.exists(reactioninfo["id"][i].get<estr>()))
        links.addref(reactioninfo["id"][i].get<estr>(),new edrawlink(this,net->links[reactioninfo["id"][i].get<estr>()],reactioninfo["rpairs"][i].get<estr>(),evector2(0.5,0.5)));
    }
  }
}

void edrawnet::check(edrawnode* drawnode,int n)
{
  int i,r;
  for (i=0; i<reactioninfo.size(); ++i){
    r=reactioninfo["pathways"][i].get<estr>().find("rn00020");
    if (r!=-1){
      if (net->links.exists(reactioninfo["id"][i].get<estr>()))
        links.addref(reactioninfo["id"][i].get<estr>(),new edrawlink(this,net->links[reactioninfo["id"][i].get<estr>()],reactioninfo["rpairs"][i].get<estr>(),evector2(0.5,0.5)));
    }
  }
/*
  if (rootnode==0x00){
    links.addref(new edrawlink(this,net->links[0],0x00,evector2(0.5,0.5)));
    if (links[0].srcnodes.size()){
      rootnode = links[0].srcnodes[0];
      rootnode->active=true;
    }else{
      rootnode = links[0].src;
      rootnode->active=true;
    }
  }

  if (!drawnode) drawnode=rootnode;
  if (!drawnode) return;
  if (!drawnode->node) return;

  int i;
  for(i=0; i<drawnode->node->links.size(); ++i){
    if (!linkExists(*drawnode->node->links[i]) && (drawnode->node->links[i]->info.findkey("FLUX")==-1 || fabs(drawnode->node->links[i]->info["FLUX"].f()) > 1.0e-3))
      links.addref(new edrawlink(this,*drawnode->node->links[i],rootnode->node,drawnode->pos));
  }
*/
}

bool edrawnet::linkExists(elink& link)
{
  int i;
  for (i=0; i<links.size(); ++i){
    if (links[i].link == &link) return(true);
  }
  return(false);
}

edrawnode* edrawnet::getnode(enode* node,const evector2& pos)
{
  int i;
  if (nodes.exists(node->id)) return(&nodes.values(node->id));

/*
  for (i=0; i<nodes.size(); ++i){
    if (node == nodes[i].node)
      return(&nodes[i]);
  }
*/

  edrawnode* drawnode;
  drawnode = new edrawnode(this,node);
  drawnode->pos = pos + evector2(ernd.uniform()-0.5,ernd.uniform()-0.5)*0.02;
  drawnode->pos2=drawnode->pos;

  for (i=0; i<net->links[0].src.size(); ++i){
    if (net->links[0].src[i].node==node)
      { drawnode->objective=true; break; }
  }

  if (node->id.len() > 3 && node->id.substr(-3) == "[e]")
    drawnode->source=true;

  nodes.addref(node->id,drawnode);
  return(&nodes.values(node->id));
}

bool isHit(const evector2& p1, const evector2& p2,float dist)
{
  if (fabs(p1.x-p2.x) < dist && fabs(p1.y-p2.y) < dist) return(true);

  return(false);
}

bool isLineHit(const evector2& p1,const evector2& p2,const evector2& p3,float dist)
{
  evector2 dir;
  evector2 perp;

  float len;

  dir = p3-p2;
  len = dir.len();
  dir = dir/len;
  perp = dir.perp();

  evector2 vec;
  vec = p1-p2;
  float xlen,ylen;
  xlen = vec*dir;
  ylen = vec*perp;

  if ( xlen>=0.0 && xlen<=len && fabs(ylen) < dist) return(true);
  
  return(false);

}

bool isLinkHit(const evector2& p1,edrawlink& drawlink,float dist)
{
  if (isLineHit(p1,drawlink.src->pos,drawlink.dst->pos,dist)) return(true);

  int i;
  for (i=0; i<drawlink.srcnodes.size(); ++i)
    if (isLineHit(p1,drawlink.src->pos,drawlink.srcnodes[i]->pos,dist))
      return(true);
  for (i=0; i<drawlink.dstnodes.size(); ++i)
    if (isLineHit(p1,drawlink.dst->pos,drawlink.dstnodes[i]->pos,dist))
      return(true);
 
  return(false);
}

int table_find(etable& table,const estr& field,const estr& needle)
{
  int i;
  if (table.cols.findkey(field)==-1) return(-1);
  for (i=0; i<table[field].size(); ++i)
    if (table[field][i].get<estr>()==needle) return(i);
  return(-1);
}

void edrawnet::getname(const estr& name,estr &res)
{
  int i;
  i=table_find(nodeinfo,"entry",name);
  if (i!=-1){
    res = nodeinfo["name"][i].get<estr>().explode(";")[0];
    return;
  }
  res = name;
}



void edrawnet::updateinfo(const evector2& mousePos)
{
  int i,j;
  i=table_find(nodeinfo,"entry",infonode->node->id);
  if (i!=-1){
    infoarr.clear();
    for (j=0; j<nodeinfo.cols.size(); ++j)
      infoarr.add(nodeinfo.cols.keys(j),nodeinfo.cols.at(j).at(i).get<estr>());
    if (infolink){
      infolink->selected=false;
      infolink=0x00;
    }

/*
    infopopuparr.array=nodeinfo[i];
    infopopuparr.doDraw();
    infopopup.show();
    infopopup.move(left+(int)mousePos.x+30,top+(int)mousePos.y+30);
    infopopupnode=true;
    if (infolink){
      infolink->selected=false;
      infolink=0x00;
    }
*/
    return;
  }

}

void edrawnet::updatelinkinfo(const evector2& mousePos)
{
  infoarr = infolink->link->info;

/*
  int i,j;
  i=reactioninfo["id"].find(evar(infolink->link->info[0]));

  if (i!=-1){
    for (j=0; j<reactioninfo.cols.size(); ++j)
      infoarr.add(reactioninfo.cols.keys(j),reactioninfo.cols.at(j).at(i).get<estr>());
  }
*/
  if (infonode){
    infonode->selected=false;
    infonode=0x00;
  }

/*
  infopopuparr.array = infolink->link->info;
  int i;
  i=reactioninfo.cols("id").find(infolink->link->info[0]);
  if (i!=-1)
    infopopuparr.array += reactioninfo[i];
  infopopuparr.flip();
  infopopup.show();
  infopopup.move(left+(int)mousePos.x+30,top+(int)mousePos.y+30);
  infopopupnode=false;
  if (infonode){
    infonode->selected=false;
    infonode=0x00;
  }
*/
}


void edrawnet::doMouseMove(const evector2& mousePos,int mouseButton)
{
  ewindow::doMouseMove(mousePos,mouseButton);

  if (mouseDrag) return;

  int i;
  evector2 pos;

  pos.x=mousePos.x*iw;
  pos.y=mousePos.y*ih; 
  pos += vpoint;

  bool found;
  found=false;
  for (i=0; i<nodes.size(); ++i){
    if (::isHit(pos,nodes[i].pos,0.01) && nodes[i].node){
      if (infonode != &nodes[i]){
        if (infonode)
          infonode->selected=false;
        infonode=&nodes[i];
        infonode->selected=true;
        updateinfo(mousePos);
      }
      found=true;
      break;
    }
  }
  if (!found && infonode){
    infonode->selected=false;
    infonode=0x00;
//    if (infopopupnode)
//      infopopup.hide();
  }


  if (found) return;

  found=false;
  for (i=0; i<links.size(); ++i){
    if (isLinkHit(pos,links[i],0.01)){
      if (infolink != &links[i]){
        if (infolink)
          infolink->selected=false;
        infolink=&links[i];
        infolink->selected=true;
        updatelinkinfo(mousePos);
      }
      found=true;
      break;
    }
  }
  if (!found && infolink){
    infolink->selected=false;
    infolink=0x00;
//    if (!infopopupnode)
//      infopopup.hide();
  }
}

void edrawnet::doMouseScroll(int vdelta,int hdelta)
{
  float tmpiw,tmpih;
/*
  if (vdelta<0){
    scale.x = scale.x*0.90;
    scale.y = scale.y*0.90;
  }else{
    scale.x = scale.x/0.90;
    scale.y = scale.y/0.90;
  }

  tmpiw = 1.0/scale.x;
  tmpih = 1.0/scale.y;

  vpoint.x += (mousePos.x*iw - mousePos.x*tmpiw);
  vpoint.y += (mousePos.y*ih - mousePos.y*tmpih);

  iw = tmpiw;
  ih = tmpih;
*/
}

void edrawnet::doMouseScrollUp()
{
  float tmpiw,tmpih;
/*
  scale.x = scale.x*0.90;
  scale.y = scale.y*0.90;

  tmpiw = 1.0/scale.x;
  tmpih = 1.0/scale.y;

  vpoint.x += (mousePos.x*iw - mousePos.x*tmpiw);
  vpoint.y += (mousePos.y*ih - mousePos.y*tmpih);

  iw = tmpiw;
  ih = tmpih;
*/
}

void edrawnet::doMouseScrollDown()
{
  float tmpiw,tmpih;
/*
  scale.x = scale.x/0.90;
  scale.y = scale.y/0.90;

  tmpiw = 1.0/scale.x;
  tmpih = 1.0/scale.y;

  vpoint.x += (mousePos.x*iw - mousePos.x*tmpiw);
  vpoint.y += (mousePos.y*ih - mousePos.y*tmpih);

  iw = tmpiw;
  ih = tmpih;
*/
}

void edrawnet::doMouseBeginDrag(const evector2& mousePos,int mouseButton)
{
  mouseDrag=true;
  if (infonode!=0x00){
    startVPoint = infonode->pos;
//    infonode->fixed=true;
  }else
    startVPoint = vpoint;
}

void edrawnet::doMouseDrag(const evector2& mouseStart,const evector2& mousePos,int mouseButton)
{
  if (infonode!=0x00)
    infonode->pos = evector2((mousePos.x-mouseStart.x)*iw,(mousePos.y-mouseStart.y)*ih)+startVPoint;
  else
    vpoint = evector2((mouseStart.x-mousePos.x)*iw,(mouseStart.y-mousePos.y)*ih)+startVPoint;
}

void edrawnet::doMouseEndDrag(const evector2& mouseStart,const evector2& mousePos,int mouseButton)
{
  mouseDrag=false;
  if (infonode!=0x00)
    infonode->pos = evector2((mousePos.x-mouseStart.x)*iw,(mousePos.y-mouseStart.y)*ih)+startVPoint;
  else
    vpoint = evector2((mouseStart.x-mousePos.x)*iw,(mouseStart.y-mousePos.y)*ih)+startVPoint;
}

void edrawnet::doMouseClick(const evector2& mousePos, int mouseButton)
{
  if (mouseButton == Button1)
    click(mousePos);
  else if (mouseButton == Button2)
    clickdel(mousePos);
}

void edrawnet::delnode(int i)
{
  int j,k;

  if (infonode==&nodes[i]) infonode=0x00;

  for (j=0; j<links.size(); ++j){
    k=links[j].srcnodes.find(&nodes[i]);
    if (k!=-1) { links[j].srcnodes.erase(k); continue; }
    k=links[j].dstnodes.find(&nodes[i]);
    if (k!=-1) { links[j].dstnodes.erase(k); continue; }
    if (links[j].src == &nodes[i] || links[j].dst == &nodes[i])
      links.erase(j);
  }
  nodes.erase(i);
//  check();
}

void edrawnet::clickdel(evector2 pos)
{
  int i;
  pos.x=pos.x*iw;
  pos.y=pos.y*ih; 
  pos += vpoint;

  for (i=0; i<nodes.size(); ++i){
    if (::isHit(pos,nodes[i].pos,0.01) && nodes[i].node){
      if (rootnode==&nodes[i]) return;
      delnode(i);
      return;
    }
  }
}

void edrawnet::click(evector2 pos)
{
  int i;
  pos.x=pos.x*iw;
  pos.y=pos.y*ih; 

  pos += vpoint;

  for (i=0; i<nodes.size(); ++i){
    if (::isHit(pos,nodes[i].pos,0.01) && nodes[i].node){ 
      if (rootnode) rootnode->active=false;
      rootnode=&nodes[i];
//      check();
      rootnode->active=true;
//        cout << rootnode->node->id << endl;
      return;
    }
  }
}


void edrawnet::draw()
{
  int i;

  for (i=0; i<links.size(); ++i)
    links[i].draw();
  for (i=0; i<nodes.size(); ++i){
    if (!nodes[i].linkcount)
      { nodes.erase(i); --i; continue; }
    nodes[i].draw();
  }

  int j;
  int vspace=-14;
  int yadj=14*infoarr.size();

  for (j=0; j<(int)infoarr.size()-1; ++j){
    setColor(0xFFFFFF);
    print(5, 5+yadj+j*vspace,infoarr.keys(j).substr(0,10));
    print(85,5+yadj+j*vspace,infoarr.values(j));

    setColor(0x202020);
    moveTo(1,2+vspace+yadj+j*vspace);
    lineTo(width-12,2+vspace+yadj+j*vspace);
  }
  if (j<infoarr.size()){
    setColor(0xFFFFFF);
    print(5, 5+yadj+j*vspace,infoarr.keys(j).substr(0,10));
    print(85,5+yadj+j*vspace,infoarr.values(j));
  }
}

void edrawnet::update()
{
  int i;
  for (i=0; i<nodes.size(); ++i)
    nodes[i].acc=evector2(0,0);

  for (i=0; i<links.size(); ++i)
    links[i].update();

  int j;
  evector2 dir;
  float dist;
  float idist;
  float idist2;

  float deg;
  evector2 acc;


  for (i=0; i<nodes.size(); ++i){
    if (!nodes[i].node) continue;
    for (j=i+1; j<nodes.size(); ++j){
      if (!nodes[j].node) continue;
      acc.x=0.0;acc.y=0.0;
      dir = nodes[j].pos - nodes[i].pos;
      dist = sqrt(dir*dir);
      idist = 1.0/(dist+0.01);
      idist2= 2.0/(dist+0.3);
      dir = dir*idist;

      if (dist < frangeAttraction)      
        acc += ffactorAttraction*forcefactor*idist2*dir;
      if (dist < frangeRepulsion)
        acc -= 0.05*((frangeRepulsion-dist)/frangeRepulsion)*ffactorRepulsion*idist*dir;
      

      nodes[i].acc += acc;
      nodes[j].acc -= acc;
    }
  }

  float in2;
  float drag;

  in2 = 0.001;
  drag= 0.01;
  evector2 tpos;
  for (i=0; i<nodes.size(); ++i){
    if (&nodes[i]==infonode && mouseDrag) continue;
    if (nodes[i].acc.len() > 1.0) nodes[i].acc = nodes[i].acc.unit()*1.0;
    tpos = nodes[i].pos;
    nodes[i].pos += drag*(nodes[i].pos - nodes[i].pos2) + in2*nodes[i].acc;
    nodes[i].pos2 = tpos;
  }
}




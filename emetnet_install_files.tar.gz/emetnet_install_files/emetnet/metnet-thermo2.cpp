#include <eutils/emain.h>
#include <eutils/eparser.h>
#include <eutils/logger.h>

#include "enet.h"
#include <math.h>


epregisterClass(enet);

epregisterClassStart(enet){
  epregisterClassMethod(enet,load);
  epregisterClassMethod(enet,stoichiomatrix);
}
epregisterClassEnd(enet);


estrarray highenergy;



void zerotol(ematrix& m,double tol)
{
  int i,j;
  for (i=0; i<m.h; ++i){
    for (j=0; j<m.w; ++j){
      if (fabs(m(i,j))<tol){ m(i,j)=0.0; }
    }
  }
}

void print_nonzero(enet& net,const ematrix& m,int i)
{
  int j,count;
  count=0;
  for (j=0; j<m.w; ++j){
    if (fabs(m(i,j))>1.0e-10){ cout << m(i,j) << " : " <<net.links[j+1]<<endl; }
  }
}

void correct_cycle(enet& net,const ematrix& m,int i)
{
  int j,k,t,tmpi,ilink,energy;
  int link1,link2;
  bool src;
  bool tmpco2,co2;

  ilink=-1;
  src=false;
  co2=false;
  energy=-1;

  estrarray tmparr;

  for (j=0; j<m.w; ++j){
    if (fabs(m(i,j))>1.0e-10){ 
      link1=link2;
      link2=j+1;
      tmpco2=false;
      for (k=0; k<net.links[j+1].src.size(); ++k){
        if (net.links[j+1].src[k].node->id=="C00011") tmpco2=true;
        tmpi = highenergy.findkey(net.links[j+1].src[k].node->id);
        if ( tmpi != -1 && energy < tmpi){
          tmparr = highenergy[tmpi].explode(",");
          for (t=0; t<net.links[j+1].dst.size(); ++t){
            if (tmparr.find(net.links[j+1].dst[t].node->id)!=-1){
              ilink=j+1; src=true; energy=tmpi; break;
            }
          }
        }
      }
      for (k=0; k<net.links[j+1].dst.size(); ++k){
        if (net.links[j+1].dst[k].node->id=="C00011") tmpco2=true;
        tmpi = highenergy.findkey(net.links[j+1].dst[k].node->id);
        if ( tmpi != -1 && energy < tmpi ){
          tmparr = highenergy[tmpi].explode(",");
          for (t=0; t<net.links[j+1].src.size(); ++t){
            if (tmparr.find(net.links[j+1].src[t].node->id)!=-1){
              ilink=j+1; src=false; energy=tmpi; break;
            }
          }
        }
      }
      if (ilink==j+1){ if (tmpco2) co2=true; else co2=false; }
    }
  }

  if (ilink!=-1){
    if (co2) cout << "* ";
    if (src)
      cout << "proposed: --> " << net.links[ilink] << endl;
    else {
      cout << "proposed: <-- " << net.links[ilink] << endl;
      if (ilink==link1)
        cout << net.links[link2] << endl;
      else
        cout << net.links[link1] << endl;
    }
  }
}

void correct_cycle(enet& net,const ematrix& n,int i,const evector& v)
{
  int j,k,t,tmpi,energy;
  int node1,node2;

  energy=-1;

  estrarray tmparr;

  for (j=0; j<v.w; ++j){
    if (fabs(v(j))>1.0e-10){ 
      node1=node2;
      node2=j;

      tmpi = highenergy.findkey(net.nodes.keys(j));
      if ( energy < tmpi){
        tmparr = highenergy[tmpi].explode(",");
        for (t=0; t<v.w; ++t){
          if (t!=j && fabs(v(t))>1.0e-10){
            if ( v(t)*v(j)<0.0 && tmparr.find(net.nodes.keys(t))!=-1){
              energy=tmpi; break;
            }
          }
        }
      }
    }
  }

  if (energy!=-1)
    cout << "cycle converting: "<<highenergy.keys(energy) << "  to: "<<highenergy.values(energy)<<endl;
}

void print_nonzero_vec(enet& net,const ematrix& m,int i,const evector& v)
{
  int j,count;
  count=0;
  for (j=0; j<m.w; ++j){
    if (fabs(m(i,j))>1.0e-10){ ++count; }
  }
  cout << "found: "<<count << ":"<<endl;
  if (count==2)
    correct_cycle(net,m,i,v);
  for (j=0; j<v.w; ++j){
    if (v(j)>1.0e-10){ cout << net.nodes[j].id<<": "<<v(j)<<"  "; }
  }
  cout << "--> ";
  for (j=0; j<v.w; ++j){
    if (v(j)<-1.0e-10){ cout << net.nodes[j].id<<": "<<v(j)<<"  "; }
  }
  cout << endl;
}

int count_nonzero(const ematrix& m,int i,int& r1,int& r2)
{
  int j,count;
  count=0;
  for (j=0; j<m.w; ++j){
    if (fabs(m(i,j))>1.0e-10){ r1=r2; r2=j; ++count; }
  }
  return(count);
}

void zeroreactions(enet& net,ematrix& m,const estrarray& arr)
{
  int i,j,i2;
  for (i=0; i<arr.size(); ++i){
    if (net.nodes.exists(arr.values(i)) ){// || net.nodes.exists(arr.values(i)+"[e]")){
      i2=net.nodes.findkey(arr.values(i));
//      if (i2==-1)i2=net.nodes.findkey(arr.values(i)+"[e]");

      for (j=0; j<m.w; ++j)
        m(i2,j)=0.0;
    }
  }
}

int main()
{
  ldieif(argvc<3,"syntax: "+estr(argv[0])+" <net> <reactions>");
  enet net;

  net.load(argv[1]);

//  cout << arr << endl;

  
  ematrix m;

  net.stoichiomatrix(m);

  estrarray arr;
  arr.load(argv[2]);

  highenergy.load("reactions3.txt");

  zeroreactions(net,m,arr);

  m.save(efile("teste.smat"));

  ematrix n;

  cout << "stoichiomatrix: "<<m.h<<"x"<<m.w<<endl;

  nullspacer(m,n);
  zerotol(n,1.0e-6);
  
  cout << "null rank: "<<n.h<<endl;

//  rref(n);
//  zerotol(n,1.0e-6);

  int balanced;
  evector v;

  net.stoichiomatrix(m);
  int i;
  int r1,r2,t;
  balanced=0;
  for (i=0; i<n.h; ++i){
    v=m*n.row(i);
    if (v.length()>1.0e-10){
      print_nonzero_vec(net,n,i,v);
//      correct_cycle(net,n,i);
/*
      t=count_nonzero(n,i,r1,r2);
      cout << "row("<<i<<") nonzero elements: "<<t<<endl;
      if (t>=2 && t<=4){
        print_nonzero(net,n,i);
      }
*/
    }else{
      ++balanced;
    }
  }
  cout << "balanced cycles: " << balanced << endl;
  cout << "unbalanced cycles: "<<n.h-balanced<<endl;

  epregister(net);
  epregister(m);
  epregister(n);

  epregisterFunc(zeroreactions);

  epruninterpret();
  
  return(0);
}

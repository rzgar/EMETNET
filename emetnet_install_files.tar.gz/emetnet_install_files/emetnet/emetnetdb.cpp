#include "emetnetdb.h"

ereactionelem::ereactionelem(int _mid,float _coefficient,const estr& _compartment): mid(_mid), coefficient(_coefficient), compartment(_compartment) {}

ostream& operator<<(ostream& stream,const ereactionelem& relem)
{
  stream << "("<<relem.coefficient<<") " <<relem.mid<<"["<<relem.compartment.substr(0,1)<<"]";
  return(stream);
}



ostream& operator<<(ostream& stream,const ereaction& reaction)
{
  stream << "id: "<< reaction.id << " name: " << reaction.name << " reversible: " << reaction.reversible << " :: ";
  int i;
  for (i=0; i<reaction.substs.size()-1; ++i)
    stream << reaction.substs[i] <<" + ";
  if (i<reaction.substs.size())
    stream << reaction.substs[i];
  if (reaction.reversible)
    stream << " <=> ";
  else
    stream << " --> ";
  for (i=0; i<reaction.prods.size()-1; ++i)
    stream << reaction.prods[i]<<" + ";
  if (i<reaction.prods.size())
    stream << reaction.prods[i];
  return(stream);
}



ostream& operator<<(ostream& stream,const emetabolite& metabolite)
{
  stream << "id: "<< metabolite.id << " name: " << metabolite.name << " formula: " << metabolite.formula << " compartment: " << metabolite.compartment << " charge: " << metabolite.charge;
  return(stream);
}



int emetnetdb::getMetabolite(emetabolite& metabolite)
{
  int i;
  for (i=0; i<metabolites.size(); ++i){
    if (metabolite.name==metabolites[i].name)
      return(i);
  }
  metabolites.add(metabolite);
  return(metabolites.size()-1);
}

int emetnetdb::getReaction(ereaction& reaction)
{
  int i;
  for (i=0; i<reactions.size(); ++i){
    if (reaction.id==reactions[i].id)
      return(i);
  }
  reactions.add(reaction);
  return(reactions.size()-1);
}

estr emetnetdb::sqlReactions(emysql& mysql)
{
  int i;
  estr sqlstr;
  for (i=0; i<reactions.size(); ++i)
    sqlstr+="("+estr(i)+",'"+mysql.escape_string(reactions[i].id)+"','"+mysql.escape_string(reactions[i].name)+"','"+mysql.escape_string(reactions[i].ecnumber)+"'),";
  sqlstr.del(-1);
  return(sqlstr);
}

estr emetnetdb::sqlReactData(emysql& mysql,int refid)
{
  int i;
  estr sqlstr;
  for (i=0; i<reactions.size(); ++i)
    sqlstr+="("+estr(i)+","+refid+",'"+mysql.escape_string(reactions[i].id)+"','"+mysql.escape_string(reactions[i].name)+"',"+(reactions[i].reversible?"1":"0")+",'"+reactions[i].equation+"'),";
  sqlstr.del(-1);
  return(sqlstr);
}

estr emetnetdb::sqlReactMet(emysql& mysql,int refid)
{
  int i,j;
  estr sqlstr;
  for (i=0; i<reactions.size(); ++i){
    for (j=0; j<reactions[i].substs.size(); ++j)
      sqlstr+="("+estr(i)+","+refid+","+reactions[i].substs[j].mid+",0,"+reactions[i].substs[j].coefficient+",'"+mysql.escape_string(reactions[i].substs[j].compartment)+"'),";
    for (j=0; j<reactions[i].prods.size(); ++j)
      sqlstr+="("+estr(i)+","+refid+","+reactions[i].prods[j].mid+",1,"+reactions[i].prods[j].coefficient+",'"+mysql.escape_string(reactions[i].prods[j].compartment)+"'),";
  }
  sqlstr.del(-1);
  return(sqlstr);
}

estr emetnetdb::sqlMetabolites(emysql& mysql)
{
  int i;
  estr sqlstr;
  for (i=0; i<metabolites.size(); ++i)
    sqlstr+="("+estr(i)+",'"+mysql.escape_string(metabolites[i].id)+"','"+mysql.escape_string(metabolites[i].name)+"'),";
  sqlstr.del(-1);
  return(sqlstr);
}

estr emetnetdb::sqlMetData(emysql& mysql,int refid)
{
  int i;
  estr sqlstr;
  for (i=0; i<metabolites.size(); ++i)
    sqlstr+="("+estr(i)+","+refid+",'"+mysql.escape_string(metabolites[i].id)+"','"+mysql.escape_string(metabolites[i].name)+"','"+mysql.escape_string(metabolites[i].formula)+"'),";
  sqlstr.del(-1);
  return(sqlstr);
}



int esbmlmodel::getMetabolite(const estr& metid)
{
  int i;
  i=metabolites.findkey(metid);
  ldieif(i==-1,"metabolite: "+metid+" not found");
  return(i);
}





#include "enet.h"

#include <eutils/emain.h>

int main()
{
  ldieif (argvc<2,"syntax: ./emetnet <file.net>");  

  enet net;

  net.load(argv[1]); 

  int i;
  for (i=0; i<net.nodes.size(); ++i)
    cout << net.nodes[i].id << " " << net.nodes[i].links.size() << endl;

  return(0);
}

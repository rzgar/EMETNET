#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/eheap.h>
#include <algorithm>
#include <eutils/ernd.h>




int emain()
{ ldieif(argvc<3,"syntax: ./sccm_counter  <filein.dat> <fileout.dat> ");  
  eparseArgs(argvc,argv);
////////////////////////////////////////////////////////////// Genotyping /////////////////////////////////////////////////////////////////

  efile fin;
  efile fout;
  fin.open(argv[1],"r");
  fout.open(argv[2],"w");
  estr str;
  estrarray parts;
  while (fin.readln(str)) {	
  	 parts=str.explode(" ");
         int dels[46];
         for (int k=0;k<46;k++){dels[k]=0;}
	 for (int j=0; j<parts.size(); ++j) {int temp=parts[j].i(); dels[temp]=1;} 
         int sums=dels[1]+dels[4]+dels[34]+dels[35]+dels[36]+dels[37]+dels[38]+dels[39]+dels[40];
         if (sums==0){fout.write(str+"\n");}     
  }
  fout.close();
  return(0);
}

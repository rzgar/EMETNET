#include "enet.h"
#include "esolver_clp.h"

#include <eutils/emain.h>


enet net;
esolver_clp solver;


int emain()
{
  eparseArgs(argvc,argv);
  ldieif (argvc<2,"syntax: "+efile(argv[0]).basename()+" <file.net>");  

  net.load(argv[1]);

  

  int reactions;
  reactions=net.links.size();

  int nodes;
  nodes=net.nodes.size();

  solver.internal_secretion=1;
  solver.parse(net);


  estrhash cofactors;

  float res;
  int i,j,k;
  for (i=0; i<net.links.size(); ++i){
    if (net.links[i].src.size()==1) { cout << "# reaction with single source metabolite, skipping: " << net.links[i].info[0] << endl; continue; }

    solver.setobjective(i);
//    for (j=0; j<net.links[i].dst.size(); ++j)
//      solver.setNodeBounds(net.links[i].dst[j].node->id,0.0,100.0*net.links[i].dst[j].rate);
    for (j=0; j<net.links[i].src.size(); ++j){
      solver.setNodeBounds(net.links[i].src[j].node->id,-100.0*net.links[i].src[j].rate,0.0);
      res=solver.solve(); 
      if (res>=1.0e-5){
        estr srcstr,prodstr;
        for (k=0; k<net.links[i].src.size(); ++k){
          if (k==j) continue;
          srcstr+=" "+net.links[i].src[k].node->id;
        }
        for (k=0; k<net.links[i].dst.size(); ++k){
          if (k==j) continue;
          prodstr+=" "+net.links[i].dst[k].node->id;
        }
        cofactors[srcstr.substr(1)]+=" "+net.links[i].info[0]+"("+net.links[i].src[j].node->id+"->"+prodstr+")["+res+"]";
        cout << net.links[i].info[0] << " " << net.links[i].src[j].node->id << " " << srcstr.substr(1) << " " << net.links[i].src.size() << " "<< res << endl;
      }
      solver.setNodeBounds(net.links[i].src[j].node->id,0.0,1000.0);
    }
//    for (j=0; j<net.links[i].dst.size(); ++j)
//      solver.setNodeBounds(net.links[i].dst[j].node->id,0.0,0.0);
  }
  cout << cofactors << endl;

  return(0);
}

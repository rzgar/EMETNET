#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/eheap.h>
#include <algorithm>
#include <eutils/ernd.h>

estr solver="esolver_clp";

int strict=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
enet net;
erandomWalk *prw=0x00;

int num1=0; //number of reactions in the parental networks
double num2=0.0; //genotypic distance between parental genotypes
int num3=0; //number of exchanged reactions
estr outnet="out.net";
int iter=0;

int emain()
{ ldieif(argvc<4,"syntax: ./recombination_essentiality <universe.net> <file.dat> --outnet  --num1 --num2 --num3  --iter <fluxbounds.flx>");  
  epregister(num1);
  epregister(num2);
  epregister(num3);
  epregister(iter);
  epregister(outnet);
  eparseArgs(argvc,argv);
  epregister(solver);
  epregister(strict);
  epregister(periphery_only);
  epregister(mutate_transport);
  epregister(internal_secretion);
  epregister(only_viable);
  int netsize=num1-1;  

  ////////////////////////////////////////////////////////////Genotyping////////////////////////////////////////////////////
  enet net;
  net.load(argv[1]);
  net.correct_malformed();
  erandomWalk rw(net,solver,strict);
  prw=&rw; 
  rw.periphery_only=periphery_only;
  rw.mutate_transport=mutate_transport;
  rw.internal_secretion=internal_secretion;
  rw.only_viable=only_viable;
  rw.getEnv(argvc,argv);
  rw.load(net);  
  net.correct_malformed();
  rw.calcPhenotype();
  estr sttr;

  efile fu;
  fu.open(argv[2],"r");

  //////////////////////
  estr outnet1=outnet+"_rxn_gained";
  efile fw1;
  fw1.open(outnet1,"a");

  estr outnet2=outnet+"_rxn_lost";
  efile fw2;
  fw2.open(outnet2,"a");
  
  estr outnet3=outnet+"_pheno";
  efile fw3;
  fw3.open(outnet3,"a");

  //////////////////////

  int id=1;
  eintarray gen1;
  eintarray gen2;
  eintarray GEN1;
  eintarray GEN2;
  eintarray phen1;
  eintarray phen2;
  int tmp=0;
  while (fu.readln(sttr)) {
	estrarray parts;
        parts=sttr.explode(" ");
        if (id==1){
            for (int i=0;i<6588;i++){gen1.add(tmp);}
            for (int i=0;i<6588;i++){gen1[i]=parts[i].i();}
            for (int i=0;i<6588;i++){if (gen1[i]==0){rw.disable(i);}}
            rw.periphery_only=periphery_only;
            rw.mutate_transport=mutate_transport;
            rw.internal_secretion=internal_secretion;
            rw.only_viable=only_viable;
            rw.setRSize(netsize);
            rw.calcPhenotype(); 
            phen1=rw.phenotype;
            fw3.write(intarr2str2(phen1)+"\n");
            GEN1=gen1;
            for (int i=0;i<6588;i++){rw.activate(i);}
        }
        else if (id==2){
                 for (int i=0;i<6588;i++){gen2.add(tmp);}
                 for (int i=0;i<6588;i++){gen2[i]=parts[i].i();}
                 for (int i=0;i<6588;i++){if (gen2[i]==0){rw.disable(i);}}
                 cout<<"alaki6"<<endl;
                 rw.periphery_only=periphery_only;
                 rw.mutate_transport=mutate_transport;
                 rw.internal_secretion=internal_secretion;
                 rw.only_viable=only_viable;
                 rw.setRSize(netsize);
                 rw.calcPhenotype(); 
                 phen2=rw.phenotype;
                 fw3.write(intarr2str2(phen2)+"\n");
                 GEN2=gen2;
                 for (int i=0;i<6588;i++){rw.activate(i);}
        }
        else {}
        id++;
  }
  for (int countering=0;countering<iter;countering++){
       //////////////////////////Recombination///////////////////////
       eintarray gen2=GEN2;
       eintarray gen1=GEN1;
       ////////////////////////////Donor/////////////////////////////
       cout<<"#############################################"<<endl;   
       eintarray pop;
       for (int i=0; i<num2; ++i) {pop.add(i);}
       int tmp1; 
       for (int i=(num2-1); i>=0; --i) {
            int r = (int)(ernd.uniform()*i);
            tmp1 = pop[r];
            pop[r] = pop[i];
            pop[i]=tmp1;
       }
       eintarray pop1;
       for (int j=0;j<num3;j++){
            int x=pop[j];
            pop1.add(x);
       }
       eintarray sorted1=sort(pop1);
       eintarray selected1;
       for (int j=0;j<num3;j++){
            int y=sorted1[j];
            selected1.add(pop1[y]);
       }
       ////////////////////////////Recipient/////////////////////////
       eintarray popp;
       for (int i=682; i<6588; ++i) {
            if (gen2[i]==1){popp.add(i);}
       }
       for (int i=(num1-682); i>=0; --i) {
            int r = (int)(ernd.uniform()*i);
            tmp1 = popp[r];
            popp[r] = popp[i];
            popp[i]=tmp1;
       }
       eintarray pop2;
       for (int j=0;j<num3;j++){
           int x=popp[j];
           pop2.add(x);
       }
       eintarray sorted2=sort(pop2);
       eintarray selected2;
       for (int j=0;j<num3;j++){
           int y=sorted2[j];
           selected2.add(pop2[y]);
       }
       selected1.add(0);
       selected2.add(0);    
       ////////////////////////////final indexing//////////////////////////
       eintarray final1;
       for (int i=0;i<6588;i++){
           if (gen1[i]==1){
               if (gen2[i]==0){
                  final1.add(i);
               }
           }
       }
      /////////////////Recombinants and outputing////////////////////////
      int count1=0;
      int count2=0;
      eintarray gained;
      eintarray lost;
      for (int i=0;i<6588;i++){
        if (gen2[i]==1){  
           if (selected2[count2]==i){gen2[i]=0;count2++;lost.add(i);}
           else {}
        }

        else if (gen2[i]==0) {
             if (final1[selected1[count1]]==i){
                 gen2[i]=1;
                 count1++;
                 gained.add(i);
             }
        }
        else {}
      }	
      fw1.write(intarr2str2(gained)+"\n"); 
      fw2.write(intarr2str2(lost)+"\n");       
      ///////////////////////////////Phenotyping////////////////////////
      for (int i=0;i<6588;i++){if (gen2[i]==0){rw.disable(i);}}
      rw.calcPhenotype();
      eintarray phen3 = rw.phenotype;
      fw3.write(intarr2str2(phen3)+"\n");     
      for (int i=0;i<6588;i++){if (gen2[i]==0){rw.activate(i);}}
      cout<<"++++++++++++++++++++++++++++++++++++++"<<endl;

  }
  fw1.close();
  fw2.close();
  fw3.close();
  return(0);
}



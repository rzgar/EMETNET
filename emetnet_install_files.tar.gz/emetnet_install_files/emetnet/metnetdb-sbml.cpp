#include <eutils/emain.h>
#include <eutils/efile.h>
#include <eutils/ehtml.h>
#include <eutils/emysql.h>

#include "emetnetdb.h"


void parseReactionNotes(ehtmltag& tag,ereaction& reaction)
{
  int i,j;
  estr info;

  for (i=0; i<tag.parts.size(); ++i){
    if (tag.parts[i].type.len()==0) continue;
    info=tag.parts[i].parts[0].text;
/*
    j=info.find(":");
    if (j!=-1)
      arr.add("note:"+info.substr(0,j),html_entities_decode(info.substr(j+1)));
    else
      arr.add("note:"+info,"");
*/
  }
}

void parseReactionReactants(ehtmltag& tag,esbmlmodel& model,ereaction& reaction)
{
  int i,j;
  estr info;
  for (i=0; i<tag.parts.size(); ++i){
    if (tag.parts[i].type.len()==0) continue;
    j=model.getMetabolite(html_entities_decode(tag.parts[i].args["species"]));
    reaction.substs.add(ereactionelem(j,tag.parts[i].args["stoichiometry"].f(),model.metabolites[j].compartment));
  }
}

void parseReactionProducts(ehtmltag& tag,esbmlmodel& model,ereaction& reaction)
{
  int i,j;
  estr info;
  for (i=0; i<tag.parts.size(); ++i){
    if (tag.parts[i].type.len()==0) continue;
    j=model.getMetabolite(html_entities_decode(tag.parts[i].args["species"]));
    reaction.prods.add(ereactionelem(j,tag.parts[i].args["stoichiometry"].f(),model.metabolites[j].compartment));
  }
}

void parseReaction(ehtmltag& tag,esbmlmodel& model)
{
  ereaction reaction;
//  estrarray arr;
  reaction.id=html_entities_decode(tag.args["id"]);
  reaction.name=html_entities_decode(tag.args["name"]);
  if (tag.args["reversible"]=="false")
    reaction.reversible=false;
  else if (tag.args["reversible"]=="true")
    reaction.reversible=true;
  else
    lwarn("unknown reversible value for reaction: "+tag.args["reversible"]);

  int i;
  for (i=0; i<tag.parts.size(); ++i){
    if (tag.parts[i].type.len()==0) continue;
    if (tag.parts[i].type=="notes")
      parseReactionNotes(tag.parts[i],reaction);
    if (tag.parts[i].type=="listofreactants")
      parseReactionReactants(tag.parts[i],model,reaction);
    if (tag.parts[i].type=="listofproducts")
      parseReactionProducts(tag.parts[i],model,reaction);
//    if (tag.parts[i].type=="kinecticlaw")
//      parseReactioKinectic(tag.parts[i],arr);
  }

  model.reactions.add(reaction);
}

void parseListOfReactions(ehtmltag& tag,esbmlmodel& model)
{
  int i;
//  estrarray rinfo;
  for (i=0; i<tag.parts.size(); ++i){
    if (tag.parts[i].type.len()==0) continue;
    parseReaction(tag.parts[i],model);
//    cout << rinfo << endl;
  }
}

void parseSpecie(ehtmltag& tag,esbmlmodel& model)
{
  emetabolite metabolite;
//  estrarray arr;
  metabolite.id=html_entities_decode(tag.args["id"]);
  metabolite.name=html_entities_decode(tag.args["name"]);
  metabolite.compartment=html_entities_decode(tag.args["compartment"]);
  metabolite.charge=html_entities_decode(tag.args["charge"]).i();
  model.metabolites.add(metabolite.id,metabolite);
}

void parseListOfSpecies(ehtmltag& tag,esbmlmodel& model)
{
  int i;
//  estrarray rinfo;
  for (i=0; i<tag.parts.size(); ++i){
    if (tag.parts[i].type.len()==0) continue;
    parseSpecie(tag.parts[i],model);
//    cout << rinfo << endl;
  }
}

void parseModel(ehtmltag& tag,esbmlmodel& model)
{
  int i;
  for (i=0; i<tag.parts.size(); ++i){
    if (tag.parts[i].type.len()==0) continue;
    if (tag.parts[i].type=="listofspecies")
      parseListOfSpecies(tag.parts[i],model);
    if (tag.parts[i].type=="listofreactions")
      parseListOfReactions(tag.parts[i],model);
  }
}

void parseSBML(ehtmltag& tag,esbmlmodel& model)
{
  int i;
  for (i=0; i<tag.parts.size(); ++i){
    if (tag.parts[i].type.len()==0) continue;
    if (tag.parts[i].type=="model")
      parseModel(tag.parts[i],model);
  }
}

int emain()
{
  eparseArgs(argvc,argv);
  ldieif(argvc<1,"syntax: "+efile(argv[0]).basename()+" <sbml.file>");


//  efile f(argv[1]);
//  estr str;
//  f.read(str);

  emetnetdb mndb;
  esbmlmodel model;

  ehtml html;
  html.load(argv[1]);

  int i;
  for (i=0; i<html.parts.size(); ++i){
    if (html.parts[i].type.len()==0) continue;
    if (html.parts[i].type=="sbml")
      parseSBML(html.parts[i],model);
  }

  int j,k;
  for (i=0; i<model.metabolites.size(); ++i)
    model.metabolites[i].mid=mndb.getMetabolite(model.metabolites[i]);
  for (i=0; i<model.reactions.size(); ++i){
    for (j=0; j<model.reactions[i].substs.size(); ++j){
      k=model.reactions[i].substs[j].mid;
      model.reactions[i].substs[j].mid=model.metabolites[k].mid;
    }
    for (j=0; j<model.reactions[i].prods.size(); ++j){
      k=model.reactions[i].prods[j].mid;
      model.reactions[i].prods[j].mid=model.metabolites[k].mid;
    }
    model.reactions[i].rid=mndb.getReaction(model.reactions[i]);
  }
  cout << "# model.metabolites: " << model.metabolites.size() << endl;
  cout << "# model.reactions: " << model.reactions.size() << endl;
  cout << "# mndb.metabolites: " << mndb.metabolites.size() << endl;
  cout << "# mndb.reactions: " << mndb.reactions.size() << endl;

  emysql mysql;

  mysql.connect("localhost","fluxconcept","fseq2sh&B","fluxconcept");

  mysql.query("insert refs (refid,title) values (0,'"+mysql.escape_string(efile(argv[1]).basename())+"');");
  mysql.query("insert metabolites (mid,id,name) values "+mndb.sqlMetabolites(mysql)+";"); 
  mysql.query("insert met_ref_data (_mid,_refid,id,name,formula) values "+mndb.sqlMetData(mysql,0)+";"); 

  mysql.query("insert reactions (rid,id,name,ecnumber) values "+mndb.sqlReactions(mysql));
  mysql.query("insert react_ref_data (_rid,_refid,id,name,reversible,equation) values "+mndb.sqlReactData(mysql,0));

  mysql.query("insert react_ref_met (_rid,_refid,_mid,type,coefficient,compartment) values "+mndb.sqlReactMet(mysql,0));
//  cout << "insert react_ref_met (_rid,_refid,_mid,type,coefficient,compartment) values "+mndb.sqlReactMet(mysql,0) << endl;

//  cout << mysql.tables() << endl;
//  cout << mysql.query("show tables") << endl;
  
  

//  cout << str.len() << endl;

  return(0);
}


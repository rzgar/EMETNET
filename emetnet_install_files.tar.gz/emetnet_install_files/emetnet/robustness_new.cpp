//This script calculates robustness of the networks

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "enet.h"
#include "esolver.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <eutils/eregexp.h>

#include <fstream>
#include <iomanip>
#include "erandomwalk.h"

enet net;


estr getFilename(const estr& str)
{
  estr tmpstr;
  eregexp re("[^/.]+\\.[^.]+$");
  tmpstr=re_match(str,re);
  eregexp re2("^[^/.]+");
  tmpstr=re_match(tmpstr,re2);
  return(tmpstr);
}

int emain()
{
  ldieif (argvc<4,"syntax: ./robustness <universe.net> <size.dat> <environment.flx> ");  
  
  estr solver="esolver_clp";
  estr strsize=argv[2];
  int internal_secretion=0;

  epregister(solver);
  epregister(internal_secretion);
  eparseArgs(argvc,argv);

  net.load(argv[1]);
  net.correct_malformed();

//  cout << "# solver: "<<solver<<endl;
//  cout << "# internal_secretion: "<<internal_secretion<<endl;
  erandomWalk rw(net,solver,0);

  rw.internal_secretion=internal_secretion;

  int i;
  rw.getEnv(argvc,argv);
	rw.load(net);
  rw.calcPhenotype();

	estr str;
  estr test=strsize+"-rr";
	estrarray parts;
	efile f;
  efile files;
	f.open(argv[2],"r");

	while (f.readln(str)) {			// While the file isn't finished, read line by line
       parts=str.explode(" ");		// cut the string based on delimiter, here a space, and assign the resulting fields into an array called "parts"
       int startindex=26;
	     eintarray numarray, writearr;
	     int tmp = 0;
		   int totalsize = 51;
		   for (int i=0; i<parts.size(); ++i){      	
			     tmp = parts[i].i()+startindex;
			     rw.disable(tmp);
			     numarray.add(tmp);
			     --totalsize;
		      }
		   rw.calcPhenotype();
		   rw.viablePhenotype = rw.phenotype;

       int tmp3;
       int count=0;
       for (int i=1; i<46; ++i) {
           tmp3=(i+startindex);
           if (rw.genotype[tmp3]==1){	
        	     rw.disable(tmp3);
					     rw.calcPhenotype();
               if (rw.isViable()){
           	      count++;
               }
             rw.activate(tmp3);
           }
        } 
       eintarray tmparr;
       tmparr.add(count);
       estr intstr=intarr2str2(tmparr);
       files.open(test,"a");
	     files.write(intstr+"\n");
	     files.close();

		   for (int i=0; i<numarray.size(); ++i){
			     rw.activate(numarray[i]);
    		} 
  }
	f.close();
	return(0);
}


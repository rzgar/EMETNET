#include "enet.h"
#include "erandomwalk.h"

#include <eutils/logger.h>
#include <eutils/emain.h>

int niter=30000;
enet net;
enet net2;
enet net3;
estr outnet="randomw-default";
estr solver="esolver_clp";
int strict=0;
int netsize=-1;
int periphery_only=0;
int internal_secretion=0;
int mutate_transport=0;


int emain()
{
  ldieif(argvc<4,"syntax: ./metnet-randomw [--outnet output] [--niter iterations] <kegg.net> <genotype.net> <fluxbounds.flx>");

  epregister(outnet);
  epregister(solver);
  epregister(netsize);
  epregister(strict);
  epregister(periphery_only);
  epregister(internal_secretion);
  epregister(mutate_transport);
  epregister(niter);
  eparseArgs(argvc,argv);


  cout << "# environment: "<<argv[4] << endl;

  enet net;
  net.load(argv[1]); 
  cout << "# global network: "<<argv[1] << endl;
  cout << "# reactions (global): " << net.links.size() << endl;
  net.correct_malformed();
  cout << "# non-malformed reactions: " << net.links.size() << endl;

  enet net2;
  net2.load(argv[2]);
  cout << "# initial network: "<<argv[2] << endl;
  cout << "# reactions (initial): " << net2.links.size() << endl;

  erandomWalk rw(net,solver,strict);
 
  rw.periphery_only=periphery_only;
  rw.mutate_transport=mutate_transport;
  rw.internal_secretion=internal_secretion;
  rw.setRSize(netsize);
  rw.getEnv(argvc,argv);


 	enet net3;
  net3.load(argv[3]);
  cout << "# network to mutate to: "<<argv[3] << endl;
  cout << "# reactions ( mutate to): " << net3.links.size() << endl;

//
//  cout << "# Optimize performance: " << opt_performance <<endl;
//  cout << "# viablePhenotype: " << intarr2str(rw.viablePhenotype) << endl;
//  cout << "# strictViable: "<<strict<<endl;
//  cout << "# Forced Random Walk: " << rw_away << endl;
//  cout << "# periphery_only: "<<rw.periphery_only<<endl;
//  cout << "# mutate_transport: "<<rw.mutate_transport<<endl;
//  cout << "# internal_secretion: "<<rw.internal_secretion<<endl;
//  cout << "# phenotype: " << intarr2str(rw.phenotype) << endl;
//  cout << "# Minimum growth sf: "<< min_gR_sf << endl;
//  cout << "# Maximum growth sf: "<< max_gR_sf << endl;
//  cout << "# Samples per iterations: " << niter<< endl;
//  cout << "# Number of samples: " << nsample << endl;
//  cout << "# Growth with start network: "<<rw.printGrowthRate() << endl;
//  cout << "# Maximum growth rates for the starting network: "<< rw.printGrMax() << endl;
//  cout << "# Minimum growth rates for the starting network: "<< rw.printGrMin() << endl;



//  if (rw_away){
//    cout << "# simulation type: forced random walk away from initial network"<<endl;
//    rw.run_away(net2,niter);
//    net.info.add("finalgr",doublearr2str(rw.growthRate));
//    net.saveactive(outnet+".net");
//  }else{
//  int n;
//  for (n=1; n<=nsample; ++n){
//    cout << "# simulation type: random walk"<<endl;
//    rw.run(niter);
//    net.info.add("finalgr",doublearr2str(rw.growthRate));
//    net.saveactive(outnet+"-"+n+".net");
//  }
//}


  rw.run_toward(net2,net3,niter);

  return(0);
}

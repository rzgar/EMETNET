#include "enet.h"
#include "erandomwalk.h"

#include <eutils/logger.h>
#include <eutils/emain.h>

#include <signal.h>

//estr outfile="default-file";
estr solver="esolver_clp";
int netsize=-1;
int strict=0;
int force_away=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
enet net;


erandomWalk *prw=0x00;

int emain()
{

  ldieif(argvc<5,"syntax: ./metnet-exgen [--outnet outputfile] <universe.net> <size.dat> <fluxbounds.flx>");

// arg N is for total number of combinations and E is for number of zero entries

  //epregister(outfile);
  epregister(solver);
  eparseArgs(argvc,argv);
  estr outfile=argv[4];

  cout << "# environment: "<<argv[3] << endl;
	cout << "# input file: "<<argv[2] << endl;

  net.load(argv[1]); 
  cout << "# global network: "<<argv[1] << endl;
  cout << "# reactions (global): " << net.links.size() << endl;
  net.correct_malformed();
  cout << "# non-malformed reactions: " << net.links.size() << endl;

  erandomWalk rw(net,solver,strict);
  prw=&rw; 

//  estrarray rfrq;
//  rfrq.load(argv[2]);
//	for (i=0; i<rfrq.size(); ++i){
//		cout << rfrq.(i) <<endl;
//	}

  rw.periphery_only=periphery_only;
  rw.mutate_transport=mutate_transport;
  rw.internal_secretion=internal_secretion;
  rw.only_viable=only_viable;
  rw.setRSize(netsize);
  rw.getEnv(argvc,argv);

  rw.load(net);
  rw.calcPhenotype();
  rw.viablePhenotype=rw.phenotype;

  int transport_count,superess_count,i,j;
  transport_count=0;

  for (i=0; i<net.links.size(); ++i){
    if (net.links[i].transport)
      ++transport_count;
  }
  cout << "# phenotype: "<< intarr2str(rw.phenotype)<<endl;
  cout << "# transport reactions: "<<transport_count<<endl;
	cout << "# Number of nontransport reactions: " << net.links.size()-transport_count-1 << endl;


	estr str;
	estrarray parts;
	efile f;
	f.open(argv[2],"r");
	
	efile fout;
 	


	while (f.readln(str)) {			// While the file isn't finished, read line by line
  	parts=str.explode(" ");		// cut the string based on delimiter, here a space, and assign the resulting fields into an array called "parts"
    int startindex=26;
	  eintarray numarray, writearr;
	  int tmp = 0;
    int tmpo= 0;
		for (i=0; i<parts.size(); ++i){
      	
			tmp = parts[i].i()+startindex;
      tmpo= parts[i].i();
      writearr.add(tmpo);						// convert index i in parts to integer and assign to integer called tmp 
			rw.disable(tmp);
			numarray.add(tmp);
		}

		rw.calcPhenotype();
    fout.open(outfile,"a");
		if (rw.isViable()) {
			estr zeroloc = intarr2str2(writearr);
			fout.write(zeroloc+"\n");
		}
    fout.close();
		for (i=0; i<numarray.size(); ++i){
			rw.activate(numarray[i]);
		}
	}
	f.close();
	return(0);
}


#include "enet.h"
#include <eutils/eparser.h>

void register_enet()
{
  epregisterClassMethod(enet,load);
  epregisterClassMethod(enet,stoichiomatrix);
}

int main(int argvc,char* argv[])
{
  register_enet();
  eparseArgs(argvc,argv);

  ldieif(argvc<2,"syntax: metnet-interp <file.net>");

  enet net;
  net.load(argv[1]);
  net.correct_malformed();

  epregister(net);

  return(0);
}

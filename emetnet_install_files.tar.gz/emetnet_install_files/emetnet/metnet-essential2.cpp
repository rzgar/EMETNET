#include "enet.h"

#include "esolver_clp.h"
//#include "esolver_cplex.h"

#include <eutils/emain.h>
#include <eutils/ernd.h>

esolver_clp solver1;
esolver_clp solver2;
esolver_clp solver_ijr;
//esolver_clp solver;


bool isTransport(elink& link)
{
  int i;
  for (i=0; i<link.src.size(); ++i)
    if (link.src[i].node->id.find("[e]")!=-1) return(true);
  for (i=0; i<link.dst.size(); ++i)
    if (link.dst[i].node->id.find("[e]")!=-1) return(true);
  return(false);
}

int emain()
{
  ldieif (argvc<4,"syntax: ./emetnet-ess2 <file.net> <env.flx> <env2.flx>");  

  enet net;
  net.load(argv[1]); 

  cout << "# number of total reactions: " << net.links.size() << endl;
  net.correct_malformed();
  cout << "# finished loading file: "<<argv[1] << endl;
  solver1.parse(net);
  solver2.parse(net);
  solver_ijr.parse(net);
  cout << "# Number of total reactions in model: "<<net.links.size()<<endl;

  double v,env1,env2,envijr;

 
  solver1.load_fluxbounds(argv[2]);
  env1=solver1.solve();
  ldieif(v==-1.0,"unbounded or infeasible problem");
  cout << "# growth on env1: "<< env1 << endl;
  

  solver2.load_fluxbounds(argv[3]);
  env2=solver2.solve();
  ldieif(v==-1.0,"unbounded or infeasible problem");
  cout << "# growth on env2: "<< env2 << endl;

  solver_ijr.load_fluxbounds(argv[2]);
  int i,j,k;
  for (i=0; i<net.links.size(); ++i){
    if (net.links[i].info["DB"]!="IJR904")
      break;
  }
  int ijr=i;
  for (; i<net.links.size(); ++i)
    solver_ijr.disable(i);
  envijr=solver_ijr.solve();
  cout << "# ecoli growth on env1: "<<envijr<<endl;

  int rdir[net.links.size()];
  bool transport[net.links.size()];
  int count;

  for (i=0; i<net.links.size(); ++i)
    rdir[i]=0;

  for (i=0; i<net.links.size(); ++i)
    transport[i]=isTransport(net.links[i]);
  
  for (i=0; 1; ++i){
    count=0;
    for (j=ijr; j<net.links.size(); ++j){
//      if (rdir[j]!=3 && fabs(solver2.x[j])>1.0e-4 && !net.links[j].irreversible && !transport[j]) ++count;
      if (rdir[j]!=3 && fabs(solver2.x[j])>1.0e-4 && !transport[j]) ++count;
    }

    cout << count;

    if (count && ernd.uniform() < 0.7*(double)count/10.0+0.3){
      k=(int)(ernd.uniform()*count)+1;
      for (j=ijr; j<net.links.size() && k; ++j){
//        if (rdir[j]!=3 && fabs(solver2.x[j])>1.0e-4 && !net.links[j].irreversible && !transport[j]) --k;
        if (rdir[j]!=3 && fabs(solver2.x[j])>1.0e-4 && !transport[j]) --k;
      }
      --j;
    }else{
      count=0;
      for (j=ijr; j<net.links.size(); ++j){
        if (rdir[j]!=0 && !transport[j]) ++count;
//        if (rdir[j]!=0 && !net.links[j].irreversible && !transport[j]) ++count;
      }
      ldieif(count==0,"error, count=0");
      k=(int)(ernd.uniform()*count)+1;
      for (j=ijr; j<net.links.size() && k; ++j){
        if (rdir[j]!=0 && !transport[j]) --k;
//        if (rdir[j]!=0 && !net.links[j].irreversible && !transport[j]) --k;
      }
      --j;

      cout << "reset: " << net.links[j].info[0]<<": "<<j<<endl;
      rdir[j]=0;
      solver2.activate(j);
      solver1.activate(j);
      if (j<ijr)
        solver_ijr.activate(j);
      v=solver2.solve();
      continue;
    }
    
    cout << " >> "<<net.links[j].info[0]<<": "<<j<<" "<<rdir[j]<<" "<<solver2.x[j]<<" -- "; 
    if (solver2.x[j]>0.0)
      { solver2.setxbounds(j,-1.0e10,0.0); solver1.setxbounds(j,-1.0e10,0.0); if (j<ijr) solver_ijr.setxbounds(j,-1.0e10,0.0); rdir[j]=1; }
    else
      { solver2.setxbounds(j,0.0,1.0e10); solver1.setxbounds(j,0.0,1.0e10); if (j<ijr) solver_ijr.setxbounds(j,0.0,1.0e10); rdir[j]=2; }
    
    v=solver1.solve();
    cout << v <<" - ";
    if (v<0.1*env1){
      solver1.activate(j);
      solver2.activate(j);
      if (j<ijr)
        solver_ijr.activate(j);
      rdir[j]=3;
      cout << " reversed: "<<v<<endl;
      continue;
    }

    if (j<ijr){
      v=solver_ijr.solve();
      if (v<0.1*envijr){
        solver1.activate(j);
        solver2.activate(j);
        if (j<ijr)
          solver_ijr.activate(j);
        rdir[j]=3;
        cout << " reversed: "<<v<<endl;
        continue;
      }
    }

    v=solver2.solve();
    if (v==-1){
      solver1.activate(j);
      solver2.activate(j);
      if (j<ijr)
        solver_ijr.activate(j);
      rdir[j]=3;
      v=solver2.solve();
      cout << " reversed2: "<<v<<endl;
      continue;
    }

    if (v<1.0E-3){
      cout << "found!: "<<v<<endl;
      break;
//      cout << net.links[j].info[0] << endl;
    }
    cout << " accepted: "<<v<<endl;
  }

  count=0;
  for (i=0; i<net.links.size(); ++i){
    if (rdir[i]==1 || rdir[i]==2){
      solver2.activate(i);
      v=solver2.solve();
      if (v==-1 || v>1.0E-3){
        if (rdir[i]==1)
          solver2.setxbounds(i,-solver2.MMAXFLUX,0.0);
        else
          solver2.setxbounds(i,0.0,solver2.MMAXFLUX);
      }else{
        solver1.activate(i);
        if (i<ijr)
          solver_ijr.activate(i);
        rdir[i]=3;
        ++count;
      }
    }
  }

  int reverted;
  reverted=count;

  count=0;
  for (i=1; i<net.links.size(); ++i){
    if (rdir[i]==1 || rdir[i]==2){
      if (rdir[i]==1)
        net.links[i].invert();
      net.links[i].irreversible=true;
      cout << net.links[i].info[0]<< " : " << rdir[i] << endl;
      ++count;
    }
  }

  cout << endl << "reverted: "<<reverted<<endl<<"total changes: "<<count<<endl;

  v=solver2.solve();
  cout << "final result for env2: "<<v<<endl;
  v=solver1.solve();
  cout << "final result for env1: "<<v<<endl;
  v=solver_ijr.solve();
  cout << "final result for ijr904 on env1: "<<v<<endl;

  cout << "saving network to file: output.net"<<endl;
  net.save("output.net");
  return(0);
}

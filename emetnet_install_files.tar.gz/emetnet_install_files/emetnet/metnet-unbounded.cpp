#include "enet.h"
#include "esolver_clp.h"

#include <eutils/emain.h>


enet net;
esolver_clp solver;


int main()
{
  ldieif (argvc<2,"syntax: ./metnet-clp <file.net>");  

  net.load(argv[1]);
  net.correct_malformed();

  solver.parse(net);

  int i;
  if (argvc>2){
    for (i=0; i<net.links.size(); ++i){
      if (net.links[i].info[0] == argv[2]) break;
    }

    ldieif(i>=net.links.size()," reaction: \""+estr(argv[2])+"\" was not found!");

    solver.setobjective(i);
    solver.setxbounds(i,0.0,1000.0);
    ldieif(solver.solve() != 1000.0," reaction: \""+estr(argv[2])+"\" is not unbounded!");
    
    for (i=0;i<net.links.size(); ++i){
      if (solver.x[i] != 0.0)
        cout << net.links[i].info[0] << " " << solver.x[i]<<endl;
    }
  }else{
    int type;
    int j;
    estr reactions1,reactions2;

    for (i=0; i<net.links.size(); ++i){
      reactions1.clear();
      reactions2.clear();
      type=0;
      solver.setobjective(i);
      solver.setxbounds(i,0.0,1000.0);
      if (solver.solve() == 1000.0){
        type=1;
        for (j=0;j<net.links.size(); ++j){
          if (solver.x[j] != 0.0){
            reactions1 += net.links[j].info[0];
            reactions1 += " ";
          }
        }
      }
      if (!net.links[i].irreversible){
        solver.setobjective(i,-1.0);
        solver.setxbounds(i,-1000.0,0.0);
        if (solver.solve() == 1000.0)
          type+=2;
        for (j=0;j<net.links.size(); ++j){
          if (solver.x[j] != 0.0){
            reactions2 += net.links[j].info[0];
            reactions2 += " ";
          }
        }
      }
      switch(type){
        case 1:
          cout << " " << net.links[i].info[0] << " --> " <<reactions1<<endl; break;
        case 2:
          cout << " " << net.links[i].info[0] << " <-- " <<reactions2<<endl; break;
        case 3:
          if (reactions1 == reactions2)
            cout << " " << net.links[i].info[0] << " <=> " <<reactions1 << "="<<endl;
          else
            cout << " " << net.links[i].info[0] << " <=> " <<reactions1<< "- "<<reactions2<<endl;
      }
      solver.activate(i);
    }
  }

  return(0);
}

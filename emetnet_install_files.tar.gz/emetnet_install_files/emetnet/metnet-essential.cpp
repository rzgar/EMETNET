#include "enet.h"

#include "esolver_clp.h"
//#include "esolver_cplex.h"

#include <eutils/emain.h>

esolver_clp solver;
//esolver_cplex solver;

#include <fstream>
#include <iomanip>


//#define MAXFLUX 1.0e20

void print_flux_header(fstream& f,enet& net)
{
  f << "AddedR ";

  int i;
  for (i=0; i<net.links.size()-1; ++i)
    f << net.links[i].info[0] << " ";
  
  if (i<net.links.size())
    f << net.links[i].info[0] << endl;
}

int emain()
{
  eparseArgs(argvc,argv);
  ldieif (argvc<2,"syntax: ./emetnet-essential <file.net> [fluxbounds.flx]");  

  enet net;
  net.load(argv[1]); 

  cout << "# number of total reactions: " << net.links.size() << endl;
  net.correct_malformed();

  cout << "# finished loading file: "<<argv[1] << endl;

  solver.parse(net);
  if (argvc==3)
    solver.load_fluxbounds(argv[2]);
  else
    solver.load_fluxbounds();


  cout << "# Number of total reactions in model: "<<net.links.size()<<endl;

  double v;

  v=solver.solve();

  cout << "# growth: "<< v << endl;



  bool ess[net.links.size()];
  

  int count;
  count=0;

  int i;

  for (i=0; i<net.links.size(); ++i)
    ess[i]=false;

  for (i=1; i<net.links.size(); ++i){
    if (net.links[i].transport) continue;
    solver.disable(i);
    v=solver.solve();
    solver.activate(i);
    if (v==-1 || v<1.0E-3){
//      cout << net.links[i].info[0];
      cout << net.links[i];
      cout << endl;
      ++count;
      ess[i]=true;
    }
  }
  return(0);

  // more complex essential checks

  for (i=1; i<net.links.size(); ++i){
    if (net.links[i].irreversible) continue;

    solver.setxbounds(i,0.0,MAXFLUX);
    v=solver.solve();
    if (v==-1 || v<1.0E-3){
      cout << ">"<<net.links[i].info[0] << endl;
    }
    solver.setxbounds(i,-MAXFLUX,0.0);
    v=solver.solve();
    if (v==-1 || v<1.0E-3){
      cout << "<"<<net.links[i].info[0] << endl;
    }
    solver.activate(i);
  }

  int j;
  int count2;
  count2=0;
  for (i=1; i<net.links.size(); ++i){
    if (ess[i]) continue;
    solver.disable(i);
    for (j=i+1; j<net.links.size(); ++j){
      if (ess[j]) continue;
      solver.disable(j);
      v=solver.solve();
      solver.activate(j);
      if (v==-1 || v<1.0E-3){
        cout << net.links[i].info[0] << " <---> "<<net.links[j].info[0];
        cout << endl;
//        net.links[i].info["ESSENTIAL2"]+=net.links[j].info[0]+";";
//        net.links[j].info["ESSENTIAL2"]+=net.links[i].info[0]+";";
        ++count2;
      }
    }
    solver.activate(i);
  }
  
  for (i=1; i<net.links.size(); ++i){
    if (ess[i]) continue;
    solver.disable(i);

    for (j=i+1; j<net.links.size(); ++j){
      if (ess[j]) continue;
      solver.setxbounds(i,0.0,MAXFLUX);
      v=solver.solve();
      if (v==-1 || v<1.0E-3){
        cout << net.links[i].info[0] << " <---> "<<net.links[j].info[0];
        cout << endl;
//        net.links[i].info["ESSENTIAL2"]+=net.links[j].info[0]+";";
//        net.links[j].info["ESSENTIAL2"]+=net.links[i].info[0]+";";
        ++count2;
      }
      solver.activate(j);
    }
    solver.activate(i);
  }
  
  return(0);
}

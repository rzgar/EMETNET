#include "enet.h"
#include "esolver_clp.h"

#include <eutils/emain.h>
#include <eutils/ematrix.h>

#include <eutils/eintarray.h>


enet net;
esolver_clp solver;


inline void store(double *x, double *x2,int i)
{
  for (; i>0; --i,++x,++x2)
    *x=*x2;
}

void printvec(enet& net,const evector& v)
{
  int j;
  double maxf;

  maxf=fabs(v(0));
  for (j=1; j<v.w; ++j)
    if (maxf < fabs(v(j))) maxf=fabs(v(j));
  maxf=1.0/maxf;

  cout << "converting: ";
  for (j=0; j<v.w; ++j){
    if (v(j)*maxf<-1.0e-2){ cout << net.nodes[j].id<<": "<<v(j)*maxf<<"  "; }
  }
  cout << "--> ";
  for (j=0; j<v.w; ++j){
    if (v(j)*maxf>1.0e-2){ cout << net.nodes[j].id<<": "<<v(j)*maxf<<"  "; }
  }
  cout << endl;
}

int main()
{
  ldieif (argvc<2,"syntax: ./metnet-clp <file.net>");  

  net.load(argv[1]);
  net.correct_malformed();
  solver.parse(net);
  if (argvc==3)
    solver.load_fluxbounds(argv[2]);
  else
    solver.load_fluxbounds();

  ldieif(solver.solve()==-1.0,"unable to solve problem");

  double x[net.links.size()];

  store(x,solver.x,net.links.size());

  // fix the objective value (maximum growth)
  solver.setxbounds(0,x[0]*0.9999999999,x[0]);

  cout << "growth objective: "<<solver.solve()<<endl;

  int fixed,fixednonzero,nonzero;

  fixed=0;
  fixednonzero=0;
  nonzero=0;
 
  double tmpf,maxf,minf;

  ematrix m;
  evector v;
  
  eintarray propose;

  net.stoichiomatrix(m);

  int i,j;
  for (i=1; i<net.links.size(); ++i){
    solver.setxbounds(i,-10000.0,10000.0);
    solver.setobjective(i,1.0);
    solver.solve();

    maxf = solver.x[i];
    solver.setobjective(i,-1.0);
    solver.solve();
    minf = solver.x[i];

    if (fabs(maxf-minf)<1.0e-6){
      cout << net.links[i].info[0] << " fixed "<<minf<<" "<<maxf<<endl;
      solver.activate(i);
      continue;
    }

    // Lets check if we can disable this reaction and check for correlations

    if (minf*maxf>0.0){
      cout << net.links[i].info[0] << " nonzero "<<minf<<" "<<maxf<<endl;
      solver.activate(i);
      continue;
    }

    // Make the flux the maximum absolute value
    if (fabs(maxf)>fabs(minf)){
      solver.setobjective(i,1.0);
      solver.solve();
    }
    store(x,solver.x,net.links.size());

    // Fix the flux at zero
    solver.setxbounds(i,0.0,0.0);

    solver.solve();
    if (fabs(solver.x[i])>=1.0e-6) lerror("unable to zero reaction flux?");

    cout << net.links[i].info[0] <<" zeroable "<<minf<<" "<<maxf<<endl;

    tmpf=1.0/fabs(x[i]);
    v=m.col(i-1);
    propose.clear();
    cout << "correlations: ";
    for (j=1; j<net.links.size(); ++j){
      if (j!=i && fabs(x[j])>1000.0 && fabs(solver.x[j])<1000.0){
        cout << net.links[j].info[0]<<" ("<<x[j]<<", "<<solver.x[j]<<") ";
        v+=m.col(j-1)*(x[j]*tmpf);
        if (x[j]*m(net.nodes["C00002"].i,j-1)>0.0)
          propose += j;
      }
    }
    cout << endl;
    printvec(net,v);
    cout << "propose: ";
    for (j=0; j<propose.size(); ++j){
      cout << net.links[propose[j]].info[0] <<" ";
    }
    cout << endl;
    solver.activate(i);
  }
  return(0);
}

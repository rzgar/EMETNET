#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
#include <vector>
using std::vector;

int siz=0;
int diam=0;

// array that will store pre-computed number of "on" bits in a 16bit value
char precomp_count_16bits[0x1u<<16];
// function to compute how many "on" bits exist in a 32bit (int) value
inline char count_bits(unsigned int i)
{
  int cbits=0;
  while (i){
    cbits += i&0x1u;
    i>>=1;
  }
  return(cbits);
}

// function that needs to be called at the beginning of a program (before any other code) to initialize the array with pre-computed values (bits_in_16bits)
void init_precomp_count()
{
  unsigned int i;
// iterates through all possible 16 bit values and initializes the array to the number of "on" bits in that value
  for (i=0; i<0x1u<<16; ++i)
    precomp_count_16bits[i]=count_bits(i);
}

// function to compute how many "on" bits exist in a 64bit (long int) value using the pre-computed table. Basically this takes the first the 64 bits and splits it into 16 + 16 + 16 +16. For each of those 16 bits sums the count using the table to look them up. 
int count_bits16(unsigned long i)
{
  return( precomp_count_16bits[i & 0xfffful] + precomp_count_16bits[(i>>16) & 0xfffful] +precomp_count_16bits[(i>>32) & 0xfffful] + precomp_count_16bits[(i>>48) & 0xfffful] );
}

// This function will return the hamming distance between two networks represented by 64bit values
inline int mnets_dist(unsigned long x,unsigned long y)
{
  return(count_bits16(x^y));
}


int emain() {
ldieif(argvc<3,"syntax: ./diameter2.cpp <inputfilename.dat> --siz --diam");
// Arguments

epregister(siz);
epregister(diam);
eparseArgs(argvc,argv);

estr sizestr=argv[1];

init_precomp_count();  // initialize the precomp_count array

unsigned long allnetworks[siz];  // this is the array which will contain all networks (array of 64bit values). Make sure to set "netcount" to the proper number of networks you will be reading

// Reading the files and filling the arrays
estr str;
estrarray parts;
efile f1;

int j,k,m,n;

unsigned long genbits=0x00ul; // start with a 64bit value representing the network with all bits set to zero

int intcount=0;
f1.open(argv[1],"r");
while (f1.readln(str)) {
      parts=str.explode(" ");
      genbits=0x00ul; 
      for (int m=0; m<parts.size(); ++m){
      genbits|=(0x01ul<<(parts[m].i()-1));}
      allnetworks[intcount]=genbits;
      intcount++;
}
f1.close();
///////////////////////////////////////
estr test=sizestr+"_diameter2";
efile files;

double s=0;
int distance=0;
double x1=0;
double x2=0;
files.open(test,"a");
estr str_siz=double (siz);
// degree definition //
for (int k=0; k<siz; ++k){
     for (int l=(k+1); l<siz; ++l){
          distance = mnets_dist(allnetworks[k],allnetworks[l]); //distance is defined
          estr kapa=double (distance);
          if (distance==diam){
              x1=double (k+1);
              x2=double (l+1);
              estr intstr1=x1;
              estr intstr2=x2;
              files.write(intstr1+" "+intstr2+"\n");
          }
     }
}
files.close();
}


#ifndef __ESOLVER_CPLEX__
#define __ESOLVER_CPLEX__

#include "esolver.h"
#include <eutils/ematrix.h>

#include <ilcplex/cplex.h>

class esolver_cplex : public esolver
{
 public:
  double   *pi;
  double   *dj;

  int iobjective;

  static CPXENVptr     env;
  CPXLPptr      lp;

  esolver_cplex();
  ~esolver_cplex();

  bool openEnv();
  bool isAvailable();

  void parse(enet& net);
  void parse(ematrix& m,evector& lower,evector& upper,evector& xlower,evector& xupper,evector& objective);
  double solve();

  void setobjective(int i,double value=1.0);
  void setobjective(evector& obj);
  void setxbounds(int i,double min,double max);
  void setybounds(int i,double min,double max);

  void write(const estr& filename);

  void setActive(const eintarray& arr);
  void activate(int i);
  void disable(int i);
};

#endif


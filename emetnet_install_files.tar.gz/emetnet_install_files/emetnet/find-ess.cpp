#include "enet.h"
#include "esolver.h"

#include <eutils/emain.h>
#include <eutils/eregexp.h>
#include <fstream>
#include <iomanip>

#include "erandomwalk.h"

estr intarr2str(const eintarray& arr);


int emain() {
	ldieif(argvc<2,"syntax: ./find-ess [--solver <clp|cplex>] <metabolic.net> <env.flx> [env2.flx env3.flx ...]");

	int essonly = 0;
	int internal_secretion = 0;
	int mutate_transport = 0;
	int phetarget_opt = 0;

	epregister(essonly);
	epregister(internal_secretion);
	epregister(mutate_transport);
	epregister(phetarget_opt);
  eparseArgs(argvc,argv);

	enet net;
	net.load(argv[1]);
	net.correct_malformed();

	estr solver = "esolver_clp";
	epregister(solver);

	cout << "# loaded starting metnet: " << argv[1] << endl;

	erandomWalk rw(net, solver, 0);
	rw.internal_secretion = internal_secretion;
	rw.mutate_transport = mutate_transport;
	rw.getEnv(argvc, argv);
	rw.calcPhenotype();


////////////////////////////////////////

	eintarray pheref;
	pheref = rw.phenotype;
	rw.viablePhenotype = pheref;


	ldieif(!rw.isViable(),"given network is not viable on target phenotype");

	int i;
	int transport = 0;

	for (i = 1; i < rw.genotype.size(); ++i) {
		if (rw.net->links[i].transport && !rw.mutate_transport
				&& rw.genotype[i] == 1)
			++transport;
	}

	earrayof<int, eintarray> phenotypes;
	earrayof<eintarray, estr> rreactions;
	estrarray dreactions;
  estr robstr;

  pheessential2(rw,phenotypes,rreactions,dreactions);
	   //  cout << "# reduced phenotypes" << endl;
	for (i=0; i<rreactions.size(); ++i){
     if (!rw.isViable(rreactions.values(i))){
	     cout << rreactions.keys(i) << ": " << intarr2str(rreactions.values(i)) << endl;
      }
   }
	  
  cout << "# Shared essential reactions between all environments" << endl;
  for (i=0; i<dreactions.size(); ++i) {
    cout << dreactions[i] << endl;
 	}
	return (0);

}

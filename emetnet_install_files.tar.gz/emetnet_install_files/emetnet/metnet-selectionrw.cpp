#include "enet.h"
#include "erandomwalk.h"
#include "esolver.h"

#include <eutils/logger.h>
#include <eutils/emain.h>

int emain()
{
  ldieif(argvc<4,"syntax: ./metnet-selectionrw [--outnet output.net] [--startnet <1|0>] [--niter iterations] <kegg.net> <genotype.net> <fluxbounds.flx>");

  int startnet=0;
  epregister(startnet);

  estr outnet;
  outnet="selectionrw-default.net";
  epregister(outnet);

  int niter;
  niter=10000;
  epregister(niter);

  cout << "# global metnet: "<<argv[1] << endl;
  cout << "# initial metnet: "<<argv[2] << endl;
  cout << "# environment: "<<argv[3] << endl;

  enet net;
  net.load(argv[1]); 
  cout << "# total reactions (global): " << net.links.size() << endl;
  net.correct_malformed();
  cout << "# total non-malformed reactions: " << net.links.size() << endl;

  enet net2;
  net2.load(argv[2]);
  cout << "# total reactions (starter): " << net2.links.size() << endl;

  erandomWalk rw(net,1);

  rw.addEnv(argv[3]);
  rw.viablePhenotype[0]=1;
  cout << "# iterations: " << niter<<endl;
  cout << "# simulation type: selection random walk"<<endl;

  double igrowth,growth,tgrowth;

  rw.load(net2);

  igrowth = rw.solvers.at(0).solve();
  cout << "# growth rate of starting metnet: " <<igrowth<<endl;
  ldieif (igrowth*0.333 < 1.0e-3," initial growth to small < 1.0e-3");

  growth=igrowth;
  cout << "# looking for small growth network" << endl;
  while(!startnet){ 
    rw.mutate();
    growth=rw.solvers.at(0).solve();
    if (growth<1.0e-3) { rw.revert(); cout << "# "<<growth<<endl; continue; }
    cout << growth<<endl;
    if (growth<0.333*igrowth){
      net.saveactive(outnet);
      break;
    }
  }

  cout << "# found small growth network with growth rate: "<<growth<<endl;
  cout << "# starting optimization: " << endl;
  tgrowth = growth;
  int i;
  for (i=0; i<niter; ++i){
    rw.mutate();
    growth=rw.solvers.at(0).solve();
    if (growth<=1.0e-3) { cout << "#! "<< i << " " << tgrowth << " " <<growth<< endl; rw.revert(); continue; }
    if (growth<=tgrowth) { cout << "# "<< i << " " << tgrowth << " " << growth<< endl; continue; }
  
    tgrowth=growth;
    cout << i << " " << growth << endl;
  }

  return(0);
}

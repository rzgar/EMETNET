#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <vector>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
#include <eutils/ernd.h>
using std::vector;

int emain()
{
ldieif(argvc<4,"syntax: ./outputing <inputfile1> <inputfile2> <inputfile3> ");
estr inputfile1=argv[1];
estr inputfile2=argv[2];
estr inputfile3=argv[3];
estr outputfile1=inputfile2+"_file1";
estr outputfile2=inputfile2+"_file2";
efile infile1;
efile infile2;
efile infile3;
efile outfile1;
efile outfile2;
estr str1;
estr str2;
estr str3;
estrarray parts;
eintarray deleted;
infile3.open(inputfile3,"r");
int marker=0;
while (infile3.readln(str3)) {
      parts=str3.explode(" ");
      if (parts.size()>0){deleted.add(parts[0].i());marker++;};
}
cout<<intarr2str2(deleted[0])<<endl;
if (marker==0){
    ////First file//////
    infile1.open(inputfile1,"r");
    outfile1.open(outputfile1,"w");
    cout<<outputfile1<<endl;
    while (infile1.readln(str1)) {
           outfile1.write(str1+"\n");
    }
    infile1.close();
    outfile1.close();
    ////Second file//////
    infile2.open(inputfile2,"r");
    outfile2.open(outputfile2,"w");
    while (infile2.readln(str2)) {
           outfile2.write(str2+"\n");
    }
    infile2.close();
    outfile2.close();
}
else {
    ////First file//////
    int counter1=1;
    int count1=0;
    infile1.open(inputfile1,"r");
    outfile1.open(outputfile1,"w");
    cout<<outputfile1<<endl;
    while (infile1.readln(str1)) {
           if (counter1==deleted[count1]){count1++;}
           else {outfile1.write(str1+"\n");cout<<"count1: "<<(double) count1<<endl;cout<<"counter1: "<<(double) counter1<<endl;}
           counter1++;
    }
    infile1.close();
    outfile1.close();
    ////Second file//////
    int counter2=1;
    int count2=0;
    infile2.open(inputfile2,"r");
    outfile2.open(outputfile2,"w");
    while (infile2.readln(str2)) {
           if (counter2==deleted[count2]){count2++;}
           else {outfile2.write(str2+"\n");cout<<"count2: "<<(double) count2<<endl;cout<<"counter2: "<<(double) counter2<<endl;}
           counter2++;
    }
    infile2.close();
    outfile2.close();
}
return(0);
}

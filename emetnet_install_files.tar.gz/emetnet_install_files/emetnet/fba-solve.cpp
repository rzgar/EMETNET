
#include "enet.h"
#include "esolver.h"

#include <eutils/emain.h>
#include <eutils/eregexp.h>

#include <fstream>
#include <iomanip>

#include "erandomwalk.h"

enet net;


estr getFilename(const estr& str)
{
  estr tmpstr;
  eregexp re("[^/.]+\\.[^.]+$");
  tmpstr=re_match(str,re);
  eregexp re2("^[^/.]+");
  tmpstr=re_match(tmpstr,re2);
  return(tmpstr);
}



int emain()
{
	getLogger()->level=6;
  ldieif (argvc<3,"syntax: ./fba_solve [--print_active 1|0] [--fluxnet <filename.net>] [--phenotype 1|0] <metabolic.net> <environment.flx>");  
  
  estr fluxnet;
	estr outnet;
	int print_active=0;
  estr obj="Biomass";
  estr solver="esolver_clp";
  int internal_secretion=0;
	int phenotype=0;
	estr KO;
	epregister(KO);
	epregister(obj);
  epregister(solver);
  epregister(fluxnet);
  epregister(outnet);
  epregister(internal_secretion);
	epregister(print_active);
	epregister(phenotype);
  eparseArgs(argvc,argv);

  net.load(argv[1]);
  net.correct_malformed();

//  cout << "# solver: "<<solver<<endl;
//  cout << "# internal_secretion: "<<internal_secretion<<endl;
  erandomWalk rw(net,solver,0);
  rw.internal_secretion=internal_secretion;
  rw.getEnv(argvc,argv);

  int i;

  if (obj.len()){
    i=net.links.findkey(obj);
    ldieif(i==-1,"objective reaction: "+obj+" not found");
    rw.setobjective(i);
    cout << "# objective: " << net.links[i].info[0] << endl;
  }else{
    cout << "# objective: " << net.links[0].info[0] << endl;
  }

  int transport_count;
  transport_count=0;
  for (i=0; i<net.links.size(); ++i){
    if (net.links[i].transport)
      ++transport_count;
  }

  rw.calcPhenotype();

  cout << "# Network: "<<argv[1]<<endl;
  cout << "# Environment: "<<argv[2]<<endl;
//  cout << "# Transport reactions: "<<transport_count<<endl;

  for (i=0; i<rw.phenotype.size(); ++i){
    cout << "# Growth Rate" << ": " << efile(rw.solvers.keys(i)).basename() <<": "<< rw.growthRate[i] << endl;
  }
//  net.saveactive(outnet);
	
  int j;
  for (i=0; i<rw.solvers.size(); ++i){
    if (fabs(rw.growthRate[i])<=1.0e-3) continue;
    for (j=0; j<net.links.size(); ++j){
      if (fabs(rw.solvers.at(i).x[j])>1.0e-5){
        net.links[j].info.add(getFilename(rw.solvers.keys(i)),rw.solvers.at(i).x[j]);
      }
    }
  }

	int active=0;
	if (print_active==1){
		for (i=0; i<rw.solvers.size(); ++i){
    	if (fabs(rw.growthRate[i])<=1.0e-3) continue;
    	for (j=0; j<net.links.size(); ++j){
				cout << net.links[j].info[0] << " : " << rw.solvers.at(i).x[j] << endl;
      	if (fabs(rw.solvers.at(i).x[j])>1.0e-5){
//					cout << net.links[j].info[0] << " : " << rw.solvers.at(i).x[j] << endl;
					++active;
//        	net.links[j].info.add(getFilename(rw.solvers.keys(i)),rw.solvers.at(i).x[j]);
      	}
    	}
  	}
		cout << "# Number of active reactions: " << active << endl;
	}

	if (phenotype==1) {  cout << "Phenotype of " << argv[1] << ":" << intarr2str(rw.phenotype) << endl;}
  if (fluxnet.len())
    net.saveactive(fluxnet);


  return(0);
}

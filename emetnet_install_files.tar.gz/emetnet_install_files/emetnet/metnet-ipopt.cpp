
#include "enet.h"
#include "eqnlsolver_ipopt.h"

#include <eutils/emain.h>

#include <fstream>
#include <iomanip>

enet net;
eqnlsolver_ipopt nlsolver;

/*
void print_flux(ofstream& f,enet& net)
{
  int i;
  double *primalColumns;
  
  primalColumns = solver.model->primalColumnSolution();
//  f << setprecision(4) << setw(6);
  for (i=0; i<net.links.size(); ++i){
    if (net.links[i].active && primalColumns[i]!=0.0){
      f << net.links[i].info[0] << "("<<i<<") ";
      f << setw(6) << primalColumns[i] << endl;
    }
  }
}
*/

int main()
{
  dieif (argvc<2,"syntax: ./metnet-clp <file.net>");  

  net.load(argv[1]);
  net.correct_malformed();

  nlsolver.parse(net);
  if (argvc>2)
    nlsolver.load_fluxbounds(argv[2]);
  else
    nlsolver.load_fluxbounds();
 

  cout << "objective function result: "<< nlsolver.solve() << endl;
  int i;
  for (i=1; i<net.links.size(); ++i){
    nlsolver.activateQ(i);
    cout << "objective function result: "<< nlsolver.solve() << endl;
  }

/*
  ofstream f;

  f.open("flux_vector.dat");
  print_flux(f,net);
*/

  

//  cout << net << endl;


  return(0);
}

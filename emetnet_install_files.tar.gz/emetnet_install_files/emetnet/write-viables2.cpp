#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
int emain() {
//  ldieif(argvc<2,"syntax: ./write-viables <inputfilename.dat>");
	estr sizestr=argv[1];
	epregister(sizestr);
	estrarray parts;
	estr str, intstr;
  eparseArgs(argvc,argv);
	efile f;
	efile sizefile;
	efile files;
	f.open(argv[1],"r");
	int length;
	int j;
	int intcounter;
	while (f.readln(str)) {			// While the file isn't finished, read line by line
		intcounter=0;
  	parts=str.explode(" ");		// cut the string based on delimiter, here a space, and assign the resulting fields into an array called "parts"
		length = 45 - (parts.size());
    estr test = sizestr+"-"+length+".dat";
		files.open(test,"a");
		files.write(parts+"\n");
		files.close();}
}

#include "erandomwalk.h"

#include "esolver_clp.h"
#ifdef HAVE_CPLEX
#include "esolver_cplex.h"
#endif
#include <stdio.h>  
#include <stdlib.h>  
#include <eutils/estrarrayof.h>
#include <eutils/ernd.h>
#include <eutils/eregexp.h>

estrarray ignore("C00080,C00001,C00002,C00009,C00003,C00004,C00006,C00008,C00013,C00011,C00014,C00005,C00007");

void str2intarr(estr str,eintarray &arr)
{
  int i;
  i=str.find(")");
  if (i>=0)
    str.del(0,i+1);

  eregexp re("^[0-9]+");
  arr.clear();

  estr num;
  for (i=0; i<str.len(); ){
    while(i<str.len() && str[i]==' ') ++i;

    num=re_match(str,re,i);
    if (num.len()==0) break;
    
    arr.add(num.i());
    i+=num.len();
  }
}

estr intarr2str(const eintarray& arr)
{
  int i;
  estr tmp;

  int count=0;

  for (i=0; i<arr.size(); ++i)
    { if (arr[i]>0) ++count; tmp+=arr[i]; tmp+=" "; }
  tmp.del(-1);
  return("("+estr(count)+") "+tmp);
}

estr intarr2str2(const eintarray& arr)
{
  int i;
  estr tmp;

  int count=0;

  for (i=0; i<arr.size(); ++i)
    { if (arr[i]>0) ++count; tmp+=arr[i]; tmp+=" "; }
  tmp.del(-1);
  return(tmp);
}

void sumintarr(eintarray &arr)
{
  int i,sum;
	sum=0;
	for (i=0; i<arr.size(); ++i) {
    sum=sum+arr[i];
	}
}


void phemerge(earrayof<int,eintarray>& phelist1,earrayof<int,eintarray>& phelist2)
{
  int i,j;

  int ccount,tcount;
  ccount=0;
  tcount=0;

  for (j=0; j<phelist2.size(); ++j){
    
    i=phelist1.findkey(phelist2.keys(j));
    if (i==-1)
      phelist1.add(phelist2.keys(j),phelist2.values(j));
    else
      phelist1.values(i)+=phelist2.values(j);
  }
}




int countPhenotype(eintarray& arr)
{
  int i;
  int c;
  c=0;
  for (i=0; i<arr.size(); ++i)
    if (arr[i]==1) ++c;
  return(c);
}

bool is_connected(elink &link)
{
  int j,k;

  for (j=0; j<link.src.size(); ++j){
    if (ignore.find(link.src[j].node->id)!=-1) continue;

    for (k=0; k<link.src[j].node->links.size(); ++k){
      if (link.src[j].node->links[k]->active)
        return(true);
    }
  }

  for (j=0; j<link.dst.size(); ++j){
    if (ignore.find(link.dst[j].node->id)!=-1) continue;

    for (k=0; k<link.dst[j].node->links.size(); ++k){
      if (link.dst[j].node->links[k]->active)
        return(true);
    }
  }
  return(false);
}

erandomWalk& erandomWalk::operator=(const erandomWalk& rw)
{
  net=rw.net;
  solvername=rw.solvername;
  return(*this);
}

erandomWalk::erandomWalk(const erandomWalk& rw): net(rw.net),icount(-1.0),acount(0),count(0),solvername("esolver_clp"),strictViable(rw.strictViable),periphery_only(0),mutate_transport(0),internal_secretion(0),only_viable(0),print_rejected(0),secount(0),internal_viability(0)
{
}

erandomWalk::erandomWalk(enet& _net,const estr& _solvername,int _strictViable): net(&_net),icount(-1.0),count(0),acount(0),solvername(_solvername),strictViable(_strictViable),periphery_only(0),mutate_transport(0),internal_secretion(0),only_viable(0),print_rejected(0),secount(0),internal_viability(0)
{
/*
  ldieif(solverClasses.classes.size()==0,"no installed solvers");
  int k=solverClasses.classes.findkey(solvername);
  if(k==-1){
    k=0;
    lwarn("solver: "+solvername+" not found! Using: "+solverClasses.classes.keys(0));
  }
  func_newSolver=solverClasses.classes.values(k);
*/
  init();
}

erandomWalk::erandomWalk(enet& _net, int _strictViable): net(&_net),count(0),icount(-1.0),acount(0),solvername("esolver_clp"),strictViable(_strictViable),periphery_only(0),mutate_transport(0),internal_secretion(0),only_viable(0),print_rejected(0),secount(0),internal_viability(0) { init(); }

/*
erandomWalk::erandomWalk(enet& _net,int _strictViable): net(&_net),count(0),icount(-1.0),acount(0),func_newSolver(0x00),strictViable(_strictViable),periphery_only(0),mutate_transport(0),internal_secretion(0),only_viable(0),print_rejected(0),secount(0)
{

//  ldieif(solverClasses.classes.size()==0,"no registered solvers!");
//  linfo("no solver specified, using first one: "+solverClasses.classes.keys(0));
//  func_newSolver=solverClasses.classes.values(0);

  init();
}
*/

erandomWalk::~erandomWalk(){}

void erandomWalk::init()
{
  int i;
  superess.add(0);
  genotype.add(1); // objective function is always on
  mincount.add(0);
  for (i=1; i<net->links.size(); ++i){
    if (net->links[i].active){
      genotype.add(1);
      ++acount;
    }else
      genotype.add(0);
    superess.add(0);
    mincount.add(0);
  }
}

void erandomWalk::addEnv(const estr& name)
{
  esolver *solver=getSolver(solvername); //func_newSolver();
  if (!solver->isAvailable()){
    cout << "#solver \"" << name << "\" is not available, using clp solver!";
    delete solver;
    solvername="esolver_clp";
    solver=getSolver(solvername);
    ldieif(solver==0x00,"solver: clp not found!");
  }
  solver->internal_secretion=internal_secretion;
  solver->parse(*net);
  solver->load_fluxbounds(name);
  solvers.addref(name,solver);

  phenotype.add(0);
  viablePhenotype.add(0);
  growthRate.add(0.0);
}

void erandomWalk::checkEssential(eintarray& esslist)
{
  calcPhenotype();

  eintarray ogen(genotype);
  eintarray ophe(phenotype);;

  // for each of the reactions in each of the environments register the active reactions
  // the inactive reactions are more likely to be non-essential, and do not need to be 
  // tried one by one
  eintarray agen;
  int i;
  for (i=0; i<net->links.size(); ++i)
    agen.add(0);

  int j;
  for (j=0; j<solvers.size(); ++j){
    if (phenotype[j]==1){
      for (i=1; i<net->links.size(); ++i){
        if (ogen[i]==1 && fabs(solvers.at(j).x[i]) >= 1.0e-8)
          agen[i]=1;
      }
    }
  }

  for (i=1; i<net->links.size(); ++i){
    if (ogen[i]==1 && agen[i]==0)
      disable(i);
  }
  updatePhenotypeRemoval();

  ldieif(ophe != phenotype,"some inactive reactions appear to be essential for phenotype!: "+estr(countPhenotype(ophe))+" "+estr(countPhenotype(phenotype)));
//   cout << "Everything is fine!!!" << endl;
  for (i=1; i<net->links.size(); ++i){
    if (ogen[i]==1 && agen[i]==0){
      activate(i);
      if (esslist[i]==1)
        esslist[i]=0;
    }
  }

  if (ophe!=phenotype){
    // test all reactions
    ldie("some inactive reactions appear to be essential for phenotype!");
    for (i=1; i<net->links.size(); ++i){
      if (ogen[i]==1)
        agen[i]=1;
    }
  }

  for (i=1; i<genotype.size(); ++i){
    if (net->links[i].transport && !mutate_transport || genotype[i]==0 || agen[i]==0 || esslist[i]==0)
      continue;
    disable(i);
    updatePhenotypeRemoval();

    if (!isViable()){
      esslist[i]=1;
      phenotype = ophe;
    }else
      esslist[i]=0;
    activate(i);
  }
  load(ogen);
}

void erandomWalk::calcEssential(eintarray& esslist)
{
  calcPhenotype();

  eintarray ogen(genotype);
  eintarray ophe(phenotype);;

  // for each of the reactions in each of the environments register the active reactions
  // the inactive reactions are more likely to be non-essential, and do not need to be 
  // tried one by one
  eintarray agen;
  int i;
  for (i=0; i<net->links.size(); ++i)
    agen.add(0);

  int j;
  for (j=0; j<solvers.size(); ++j){
    if (phenotype[j]==1){
      for (i=1; i<net->links.size(); ++i){
        if (ogen[i]==1 && fabs(solvers.at(j).x[i]) >= 1.0e-8)
          agen[i]=1;
      }
    }
  }

  for (i=1; i<net->links.size(); ++i){
    if (ogen[i]==1 && agen[i]==0)
      disable(i);
  }
  updatePhenotypeRemoval();

  ldieif(ophe != phenotype,"some inactive reactions appear to be essential for phenotype!: "+estr(countPhenotype(ophe))+" "+estr(countPhenotype(phenotype)));
//   cout << "Everything is fine!!!" << endl;
  for (i=1; i<net->links.size(); ++i){
    if (ogen[i]==1 && agen[i]==0){
      activate(i);
      esslist[i]=0;
    }
  }

  if (ophe!=phenotype){
    ldie("some inactive reactions appear to be essential for phenotype!");
    // test all reactions
    for (i=1; i<net->links.size(); ++i){
      if (ogen[i]==1)
        agen[i]=1;
    }
  }

  for (i=1; i<genotype.size(); ++i){
    if (net->links[i].transport && !mutate_transport || genotype[i]==0 || agen[i]==0)
      continue;
    disable(i);
    updatePhenotypeRemoval();

    if (!isViable()){
      esslist[i]=1;
      phenotype = ophe;
    }else
      esslist[i]=0;
    activate(i);
  }
  load(ogen);
}

void erandomWalk::calcSuperess()
{
  eintarray ogen(genotype);
  int i;
  for (i=1; i<net->links.size(); ++i){
    if (genotype[i]==0) activate(i);
    superess[i]=0;
  }

  eintarray oarr;
  int phecount;
  int transport;

  calcPhenotype();
  oarr=phenotype;

  phecount = countPhenotype(phenotype);
  eintarray reactions;
  eintarray ireactions;

  // for each of the reactions in each of the environments register the active reactions
  // the inactive reactions are more likely to be non-essential, and do not need to be 
  // tried one by one
  eintarray agen;
  for (i=0; i<net->links.size(); ++i)
    agen.add(0);

  int j;
  for (j=0; j<solvers.size(); ++j){
    if (phenotype[j]==1){
      for (i=1; i<net->links.size(); ++i){
        if (genotype[i]==1 && fabs(solvers.at(j).x[i]) >= 1.0e-8)
          agen[i]=1;
      }
//      break;
    }
  }

  int c,t;
  c=0;t=0;
  for (i=0; i<net->links.size(); ++i){
    if (genotype[i]==1){
      ++t;
      if (agen[i]==1) ++c;
    }
  }

//  cout << "Total reactions: "<<t<<" | Inactive: "<<t-c<<endl;
  for (i=1; i<net->links.size(); ++i){
    if (genotype[i]==1 && agen[i]==0)
      disable(i);
  }
  updatePhenotypeRemoval();

  lerrorif(oarr != phenotype,"some inactive reactions appear to be essential for phenotype!: "+estr(countPhenotype(oarr))+" "+estr(countPhenotype(phenotype)));
//   cout << "Everything is fine!!!" << endl;
  for (i=1; i<net->links.size(); ++i){
    if (agen[i]==0)
      activate(i);
  }

  if (oarr!=phenotype){
    // test all reactions
    for (i=1; i<net->links.size(); ++i){
      if (genotype[i]==1)
        agen[i]=1;
    }
  }

  int inviable=0;
  int viable=0;
  transport=0;

  for (i=1; i<genotype.size(); ++i){
    if (net->links[i].transport && !mutate_transport)
      ++transport;
  }

  cout << "# transport: " << transport << " transport_count: " << net->transport_count << endl;

  secount=0;
  for (i=1; i<genotype.size(); ++i){
    if (net->links[i].transport && !mutate_transport || genotype[i]==0 || agen[i]==0)
      continue;
    disable(i);
    updatePhenotypeRemoval();

//    if (oarr != phenotype){
    if (!isViable()){
      superess[i]=1;
      ++secount;
      phenotype = oarr;
    }
    activate(i);
  }
  load(ogen);
  cout << "# super essential reactions: " << secount << endl;
}


void erandomWalk::getEnv(int argvc,char **argv)
{
  int i=1;
  for (i=1; i<argvc; ++i){
    if (estr(argv[i]).substr(-4) == ".flx"){
      addEnv(argv[i]);
    }
  }
}

void erandomWalk::setobjective(int r)
{
  if (genotype[r]==0)
    activate(r);

  int i;
  for (i=0; i<solvers.size(); ++i)
    solvers.values(i).setobjective(r);
}


void erandomWalk::activate(int r)
{
  if (genotype[r]==1) return;

  int i;
  for (i=0; i<solvers.size(); ++i)
    solvers.at(i).activate(r);
  ++acount;
  genotype[r]=1;
}

void erandomWalk::disable(int r)
{
  if (genotype[r]==0) return;

  int i;
  for (i=0; i<solvers.size(); ++i)
    solvers.at(i).disable(r);
  --acount;
  genotype[r]=0;
}



bool erandomWalk::is_connected(elink &link)
{

// The new is_connected function. Tests if all substrates and all products in the selected reaction are involved in at least one of the reactions in the currrent genotype
  int j,k;
	int numsubstrates=0;
	int numproducts=0;

  for (j=0; j<link.src.size(); ++j){ // for the metabolites in the substrate list of that  reaction

    for (k=0; k<link.src[j].node->links.size(); ++k){ // for all the reactions that contain this metabolite sub or prod
      if (genotype[link.src[j].node->links[k]->i]==1) {
				++numsubstrates;
				break;
			}
    }
  }
  
	for (j=0; j<link.dst.size(); ++j){ // for the metabolites in the product list of that  reaction

		for (k=0; k<link.dst[j].node->links.size(); ++k){ // for all the reactions that contain this metabolite sub or prod
		  if (genotype[link.dst[j].node->links[k]->i]==1) {
  			++numproducts;
				break;
			}
	  }
  } 
  
	if (numproducts==link.dst.size()){
	//if (numsubstrates==link.src.size() && numproducts==link.dst.size()) {
		return(true);
	}
	else {return(false);}
}



void erandomWalk::calcPhenotype()
{
  int i;
  for (i=0; i<phenotype.size(); ++i){
    if (only_viable && viablePhenotype[i]==0) { phenotype[i]=-1; continue; }
    growthRate[i]=solvers.at(i).solve();
    growthRate[i] < 1.0e-3 ? phenotype[i]=0 : phenotype[i]=1;
    if (phenotype[i]==1 && internal_viability && !checkIntViability(i)) phenotype[i]=0;
  }
}

void erandomWalk::updatePhenotypeAddition(const eintarray& phenotype_mask)
{
//  ldieif(lastMutation==-1,"application did not respond to lack of possible mutations");
  int i;
  for (i=0; i<phenotype.size(); ++i){
    if (phenotype[i]==0 && phenotype_mask[i]==1){
      growthRate[i]=solvers.at(i).solve();
      if (growthRate[i] >= 1.0e-3)
        phenotype[i]=1;
    }
  }
}

void erandomWalk::updatePhenotypeAddition()
{
//  ldieif(lastMutation==-1,"application did not respond to lack of possible mutations");
  int i;
  for (i=0; i<phenotype.size(); ++i){
    if (phenotype[i]==0){
      growthRate[i]=solvers.at(i).solve();
      if (growthRate[i] >= 1.0e-3)
        phenotype[i]=1;
    }
  }
}


void erandomWalk::updatePhenotypeRemoval()
{
//  ldieif(lastMutation==-1,"application did not respond to lack of possible mutations");
  int i;
  for (i=0; i<phenotype.size(); ++i){
    if (viablePhenotype[i]==1 || !only_viable && phenotype[i]==1){
      growthRate[i]=solvers.at(i).solve();
      if (growthRate[i] < 1.0e-3)
        phenotype[i]=0;
      if (phenotype[i]==1 && internal_viability && !checkIntViability(i))
        phenotype[i]=0;
    }
  }
}

void erandomWalk::updatePhenotype_univ()
{
  if (lastMutationType && !only_viable && lastAddMutation!=-1)
    updatePhenotypeAddition();
  else if (!lastMutationType && lastRemoveMutation!=-1)
    updatePhenotypeRemoval();
}


void erandomWalk::updatePhenotype()
{
  ldieif(lastMutationType && only_viable && lastAddMutation==-1 || !lastMutationType && lastRemoveMutation==-1,"no mutation done yet");

  if (lastMutationType && !only_viable)
    updatePhenotypeAddition();
  else if (!lastMutationType)
    updatePhenotypeRemoval();
}

void erandomWalk::load(const enet& net2)
{
  int i;
  for (i=1; i<net->links.size(); ++i){
    net2.links.exists(net->links[i].info[0]) ? activate(i) : disable(i);
  }
  if (icount<0.0) setRSize(acount);
}

void erandomWalk::load(const eintarray& newgenotype)
{
  lerrorif(newgenotype.size() != genotype.size(),"genotype mismatch");

  int i,t;
  for (i=1; i<genotype.size(); ++i){
    t=genotype[i]-newgenotype[i];
    if (t!=0) (t==-1 ? activate(i) : disable(i));
  }
  if (icount<0.0) setRSize(acount);
}

bool erandomWalk::checkMetaboliteProd(int ienv,int i)
{
  if (solvers.at(ienv).fluxbounds.findkey(net->nodes[i].id)!=-1 && solvers.at(ienv).fluxbounds[net->nodes[i].id].x<0.0) return(true); // return true if the metabolite is provided in the environment
  solvers.at(ienv).setobjective(net->links.size()+i);
  solvers.at(ienv).setNodeBounds(net->nodes[i].id,0.0,1000.0);
  double res=solvers.at(ienv).solve();
//  cout << "# checking metabolite: " << net->nodes[i].id << " production: "<< res << endl;
  solvers.at(ienv).setobjective(0);
  solvers.at(ienv).resetNodeBounds(net->nodes[i].id);
  if (res==-1.0 || fabs(solvers.at(ienv).x[net->links.size()+i])<=1.0e-8) return(false);
  return(true);
}

void erandomWalk::disableMetaboliteReactions(int i)
{
  int j;
  for (j=0; j<net->nodes.at(i).links.size(); ++j){
    if (net->nodes.at(i).links[j]->i==0) continue;
    disable(net->nodes.at(i).links[j]->i);
  }
}


void erandomWalk::enableMetaboliteReactions(int i,const eintarray& ogen)
{
  int j;
  for (j=0; j<net->nodes.at(i).links.size(); ++j){
    if (net->nodes.at(i).links[j]->i==0) continue;
    if (ogen[net->nodes.at(i).links[j]->i]==1)
      activate(net->nodes.at(i).links[j]->i);
  }
}


bool erandomWalk::checkIntViability(int ienv)
{
//  ldieif(solvers.size()>1,"this method only works with 1 environment");

  estrarray carrierMetabolites;
  bool internalViable=true;

  eintarray ogen(genotype);

  float tmpres;
  tmpres=solvers.at(ienv).solve();
  ldieif(tmpres<=0.0,"metabolite network is not viable in this environment or lp problem is too constrained. Solver returned: "+estr(tmpres));

  solvers.at(ienv).setxbounds(0,solvers.at(ienv).x[0]*0.001,solvers.at(ienv).x[0]);
  tmpres=solvers.at(ienv).solve();

  int i;
  eintarray mets;
  for (i=0; i<net->nodes.size(); ++i)
    mets.add(0);

  bool disabledReactions;
  int j;
  do {
    for (i=1; i<net->links.size(); ++i){
      if (fabs(solvers.at(ienv).x[i])>=1.0e-8){
        if (solvers.at(ienv).x[i]<0.0){
          for (j=0; j<net->links[i].src.size(); ++j){
            if (mets[net->links[i].src[j].node->i]==0)
              mets[net->links[i].src[j].node->i]=1;
          }
        }else{
          for (j=0; j<net->links[i].dst.size(); ++j)
            if (mets[net->links[i].dst[j].node->i]==0)
              mets[net->links[i].dst[j].node->i]=1;
        }
      }
    }

/*
    disabledReactions=false;
    for (i=0; i<mets.size(); ++i){
      if (mets[i]==1 && !checkMetaboliteProd(i))
        { carrierMetabolites.add(net->nodes[i].id,""); disableMetaboliteReactions(i); disabledReactions=true; cout << "# disabled reactions for metabolite: " << net->nodes[i].id << endl; mets[i]=-1; break; }
    }
    tmpres=solvers.at(0).solve();
    if(tmpres<=0.0) { internalViable=false; enableMetaboliteReactions(i,ogen); carrierMetabolites[net->nodes[i].id]="*"; }
*/
    disabledReactions=false;
    for (i=0; i<mets.size(); ++i){
      if (mets[i]==1 && !checkMetaboliteProd(ienv,i)) {
        carrierMetabolites.add(net->nodes[i].id,"");
        disableMetaboliteReactions(i);
//        disabledReactions=true;
//        cout << "# disabled reactions for metabolite: " << net->nodes[i].id << endl;
        mets[i]=-1;
        tmpres=solvers.at(ienv).solve();
        if(tmpres<=0.0) {
          internalViable=false;
          carrierMetabolites[net->nodes[i].id]="*";
        }
        enableMetaboliteReactions(i,ogen);
      }
    }
  } while(disabledReactions);

  solvers.at(ienv).setxbounds(0,0.0,1000.0);
  cout << carrierMetabolites << endl;
  if (internalViable) cout << "internal viable: yes" << endl; else cout << "internal viable: no" << endl;
  load(ogen);
  return(internalViable);
}

int erandomWalk::mutate_add_genpool_univ(eintarray& genpool,int genpoolcount,float exthgt,int univ)
{
  int i;
  int dice;
  int r;

  if (ernd.uniform()<exthgt){
    r=(int)(ernd.uniform()*(univ-1))+1;

    if (r>=genotype.size()){
      lastAddMutation=-1;
      lastMutationType=true;
      return(-1);
    }
  }else{
    dice=(int)(ernd.uniform()*(genpoolcount+(univ-genotype.size())));

    for (i=1; i<genpool.size(); ++i){
      dice-=genpool[i];
      if (dice<0) break;
    }
    r=i;
    if (dice>0) {
      lastAddMutation=-1; lastMutationType=true; return(-1);
    }
  }

  if (genotype[r]==0)
    activate(r);
  lastAddMutation=r;
  lastMutationType=true;

  return(r);
}

int erandomWalk::mutate_add_genpool(eintarray& genpool,int genpoolcount,float exthgt)
{
  int i;
  int dice;
  int r;

  if (ernd.uniform()<exthgt){
    r=(int)(ernd.uniform()*(genotype.size()-1))+1;
  }else{
    dice=(int)(ernd.uniform()*genpoolcount);

    for (i=1; i<genpool.size(); ++i){
      dice-=genpool[i];
      if (dice<0) break;
    }
    r=i;
    ldieif(dice>0 && i==genpool.size(),"problem in mutate_add_genpool");
  }

  if (genotype[r]==0)
    activate(r);
  lastAddMutation=r;
  lastMutationType=true;

  return(r);
}

int erandomWalk::mutate_add_univ(int univ)
{
  int r;
  int c=0;
  while(c<20){
    ++c;
    r=(int)(ernd.uniform() * (univ-1))+1;
    if (r>=genotype.size()){
      lastAddMutation=-1; lastMutationType=true; return(-1);
    }
    if (genotype[r]==1 || periphery_only && !is_connected(net->links[r])) continue;
    activate(r);
    lastAddMutation=r;
    lastMutationType=true;
    return(r);
  }

  int tmpcount=0;
  int i;
  for (i=1; i<net->links.size(); ++i){
    if (genotype[i]==0 && (!periphery_only || is_connected(net->links[i]))) ++tmpcount;
  }
  lwarn("exceeded add tries, searching for addable reactions");
  if(tmpcount==0){ ldie("no available reactions for adding"); lastAddMutation=-1; return(-1); };
  r=(int)(ernd.uniform()*tmpcount);
  for (i=1; i<net->links.size(); ++i){
    if (genotype[i]==0 && (!periphery_only||is_connected(net->links[i]))){
      if (r==0){
        activate(i);
        lastAddMutation=i;
        lastMutationType=true;
        return(i);
      }
      --r;
    }
  }

  return(-1);
}

int erandomWalk::mutate_add()
{
  int r;
  int c=0;
  while(c<20){
    ++c;
    r=(int)(ernd.uniform() * net->links.size()-1)+1;
    if (genotype[r]==1 || periphery_only && !is_connected(net->links[r])) continue;
    activate(r);
    lastAddMutation=r;
    lastMutationType=true;
    return(r);
  }

  int tmpcount=0;
  int i;
  for (i=1; i<net->links.size(); ++i){
    if (genotype[i]==0 && (!periphery_only || is_connected(net->links[i]))) ++tmpcount;
  }
  lwarn("exceeded add tries, searching for addable reactions");
  if(tmpcount==0){ ldie("no available reactions for adding"); lastAddMutation=-1; return(-1); };
  r=(int)(ernd.uniform()*tmpcount);
  for (i=1; i<net->links.size(); ++i){
    if (genotype[i]==0 && (!periphery_only||is_connected(net->links[i]))){
      if (r==0){
        activate(i);
        lastAddMutation=i;
        lastMutationType=true;
        return(i);
      }
      --r;
    }
  }

  return(-1);
}

int erandomWalk::mutate_remove_ess_mincount_similar(int esscount,eintarray& ess)
{
  int i,r;
  int maxcount;
  int tmpcount=acount-esscount-secount;
  if (mutate_transport==0) tmpcount-=net->transport_count;

  if(tmpcount<0){ lwarn("something wrong"); return(-1); };
  if (tmpcount==0){return(-1);}

  r=-1;
  maxcount=mingenotype.size()+1;
  for (i=1; i<genotype.size(); ++i)
    if (genotype[i]==1 && superess[i]!=1 && ess[i]!=1 && (net->links[i].transport==false || mutate_transport==1)  && maxcount > mincount[i]) { maxcount=mincount[i]; r=i; }

  if(maxcount==mingenotype.size()+1){ return(-1); };

  disable(r);
  return(r);
}

int erandomWalk::mutate_remove_ess_mincount(int esscount,eintarray& ess)
{
  int i,r;
  int maxcount;
  int tmpcount=acount-esscount-secount;
  if (mutate_transport==0) tmpcount-=net->transport_count;

  if(tmpcount<0){ lwarn("something wrong"); return(-1); };
  if (tmpcount==0){return(-1);}

  maxcount=-1;
  tmpcount=0;
  r=-1;
  for (i=1; i<genotype.size(); ++i){
    if (genotype[i]==1 && superess[i]!=1 && ess[i]!=1 && (net->links[i].transport==false || mutate_transport==1)){
      if (maxcount < mincount[i]) { maxcount=mincount[i]; r=i; tmpcount=1; } else if (maxcount==mincount[i]) ++tmpcount;
    }
  }
  if(maxcount<0){ return(-1); };

  tmpcount=(int)(ernd.uniform()*tmpcount);
  for (i=1; i<genotype.size(); ++i){
    if (genotype[i]==1 && superess[i]!=1 && ess[i]!=1 && (net->links[i].transport==false || mutate_transport==1)){
      if (tmpcount==0) { r=i; break; }
      --tmpcount;
    }
  }

  disable(r);
  return(r);
}

int erandomWalk::mutate_remove_ess(int esscount,eintarray& ess)
{
  int r;

  int tmpcount=acount-esscount-secount;
  int i;
  if (mutate_transport==0) tmpcount-=net->transport_count;

  if (tmpcount<0){ lwarn("something wrong: "+estr(tmpcount)); return(-1); };
  if (tmpcount==0){return(-1);}

  r=(int)(ernd.uniform()*tmpcount);
  for (i=1; i<net->links.size(); ++i){
    if (genotype[i]==1 && superess[i]!=1 && (!net->links[i].transport || mutate_transport==1) && ess[i]!=1){
      if (r==0){
        disable(i);
        return(i);
      }
      --r;
    }
  }
  return(-1);
}

int erandomWalk::mutate_remove_univ(int univ)
{
  int r;

  int tmpcount=count;
  int tmpcount2=acount;
  int i;

  if (!mutate_transport){ tmpcount-=net->transport_count; tmpcount2-=net->transport_count; }

  if(tmpcount==0){ lwarn("no available reactions for removal"); lastRemoveMutation=-1; return(-1); };

  r=(int)(ernd.uniform()*tmpcount);
  if (r>=tmpcount2) { lastRemoveMutation=-1; lastMutationType=false; return(-1); }

  for (i=1; i<net->links.size(); ++i){
    if (genotype[i]==1 && (mutate_transport || net->links[i].transport==false)){
      if (r==0){
        disable(i);
        lastRemoveMutation=i;
        lastMutationType=false;
        return(i);
      }
      --r;
    }
  }
  return(-1);
}

int erandomWalk::mutate_remove()
{
  int r;

  int tmpcount=acount;
  int i;

  if (!mutate_transport) tmpcount-=net->transport_count;

  if(tmpcount==0){ lwarn("no available reactions for removal"); lastRemoveMutation=-1; return(-1); };

  r=(int)(ernd.uniform()*tmpcount);
  for (i=1; i<net->links.size(); ++i){
    if (genotype[i]==1 && (mutate_transport || net->links[i].transport==false)){
      if (r==0){
        disable(i);
        lastRemoveMutation=i;
        lastMutationType=false;
        return(i);
      }
      --r;
    }
  }
  return(-1);
}

void erandomWalk::revert_univ()
{
  if (lastMutationType && lastAddMutation==-1 || !lastMutationType && lastRemoveMutation==-1) return;
  lastMutationType ? disable(lastAddMutation) : activate(lastRemoveMutation);
  lastAddMutation=-1; lastRemoveMutation=-1;
}

void erandomWalk::revert()
{
  ldieif(lastMutationType && lastAddMutation==-1 || !lastMutationType && lastRemoveMutation==-1,"reverted the mutation twice! or no mutation done yet");

  lastMutationType ? disable(lastAddMutation) : activate(lastRemoveMutation);
  lastAddMutation=-1; lastRemoveMutation=-1;
}

void erandomWalk::revert_toward()
{
  ldieif(lastMutationType && lastAddMutation==-1 || !lastMutationType && lastRemoveMutation==-1,"reverted the mutation twice! or no mutation done yet");
  lastMutationType ? disable(lastAddMutation) : activate(lastRemoveMutation);
  lastAddMutation=-1; lastRemoveMutation=-1;
}

void erandomWalk::setRSize(int _count)
{
  ldieif(_count==0,"trying to set RSize to 0!");
  icount=1.0/(double)_count;
  count=_count;
//  lwarn("Setting count to: "+estr(count)+" icount: "+icount);
}

void erandomWalk::mutate_genpool_univ(eintarray& genpool,int genpoolcount,float exthgt,int univ)
{
  if (lastMutationType){
    mutate_remove_univ(univ);
  }else{
    mutate_add_genpool_univ(genpool,genpoolcount,exthgt,univ);
  }
}

void erandomWalk::mutate_genpool(eintarray& genpool,int genpoolcount,float exthgt)
{
  // In order to keep the network size constant we always make a deletion and a addition
  int resd,resa;

//  lwarnif(acount!=count && acount!=count-1,"number of reactions is incorrect: "+estr(acount)+" "+count)
  
  if (acount > count){
    resd=mutate_remove();
    ldieif(resd==-1,"unable to delete a reaction");
  }else{
    resa=mutate_add_genpool(genpool,genpoolcount,exthgt);
    ldieif(resa==-1,"unable to add a reaction");
  }
}

void erandomWalk::mutate_univ(int univ)
{
  if (lastMutationType){
    mutate_remove_univ(univ);
  }else{
    mutate_add_univ(univ);
  }
}

void erandomWalk::mutate()
{
  // In order to keep the network size constant we always make a deletion and a addition
  int resd,resa;

//  lwarnif(acount!=count && acount!=count-1,"number of reactions is incorrect: "+estr(acount)+" "+count)
  
  if (acount > count){
    resd=mutate_remove();
    ldieif(resd==-1,"unable to delete a reaction");
  }else{
    resa=mutate_add();
    ldieif(resa==-1,"unable to add a reaction");
  }
}

int erandomWalk::mutate_away2(eintarray& genotype, double T)
{
  int resd,resa;

  if (acount > count){
    resd=mutate_remove();
    ldieif(resd==-1,"unable to delete a reaction");
    return(resd);
  }

  if (ernd.uniform() < 1.0-T)
    resa=mutate_add();
  else
    resa=mutate_add_away(genotype);

  lwarnif(resa==-1,"unable to add a reaction");
  return(resa);
}

int erandomWalk::mutate_away(eintarray& genotype)
{
  int resd,resa;

  if (acount > count){
    resd=mutate_remove();
    ldieif(resd==-1,"unable to delete a reaction");
    return(resd);
  }

  resa=mutate_add_away(genotype);
  lwarnif(resa==-1,"unable to add a reaction");
  return(resa);
}

int erandomWalk::mutate_toward(eintarray& genotype)
{
  double p;
  int res;
  ldie("this code has not been updated. it still uses the old random mutation probability");

  icount=1.0/931.0;

  p =(double)acount*icount-0.5;
//  p=0.5;
  res=-1;
  if (ernd.uniform() < p){
    res=mutate_remove_toward(genotype);
    if (res==-1){ // if we did not remove anything, try adding
      lwarn("unable to remove, trying adding in this step instead");
      res=mutate_add_toward(genotype);
    }
  }else{
    if (acount == net->links.size()-1){ // if all reactions in the 'universe' are on, try removing
    }else{
      res=mutate_add_toward(genotype);
      if (res==-1) {// if we did not add anything, try removing
        lwarn("unable to add, trying remove in this step instead");
        res=mutate_remove_toward(genotype);
      }
    }
  }
  return(res);
}


int erandomWalk::mutate_add_away(eintarray& gref)
{
  int r;
  int c=0;
  while(c<20){
    ++c;
    r=(int)(ernd.uniform() * net->links.size()-1)+1;
    if (r < gref.size() && gref[r]==1 || genotype[r]==1 || !is_connected(net->links[r]) && periphery_only) continue;
//    if (r < gref.size() && gref[r]==1 || genotype[r]==1) continue;
    activate(r);
    lastAddMutation=r;
    lastMutationType=true;
    return(r);
  }

  int tmpcount=0;
  int i;
  for (i=1; i<net->links.size(); ++i){
    if (gref[i]==0 && genotype[i]==0 && (is_connected(net->links[i]) || !periphery_only)) ++tmpcount;
//    if (gref[i]==0 && genotype[i]==0) ++count;
  }
  lwarn("exceeded mutate_away add tries, searching for addable reactions");
  if(tmpcount==0){ lwarn("no available reactions for adding"); lastAddMutation=-1; return(-1); };
  r=(int)(ernd.uniform()*tmpcount);
  for (i=1; i<net->links.size(); ++i){
    if (gref[i]==0 && genotype[i]==0 && (is_connected(net->links[i]) || !periphery_only)){
//    if (gref[i]==0 && genotype[i]==0){
      if (r==0){
        activate(i);
        lastAddMutation=i;
        lastMutationType=true;
        return(i);
      }
      --r;
    }
  }

  return(-1);
}

int erandomWalk::mutate_add_toward(eintarray& gref)
{
  int r;
  int c=0;
  while(c<20){
    ++c;
    r=(int)(ernd.uniform() * net->links.size()-1)+1;
    if (gref.size() && gref[r]==0 || genotype[r] == 1 || periphery_only && !is_connected(net->links[r])) continue;
//    if (gref.size() && gref[r]==0 || genotype[r] == 1) continue;
    activate(r);
    lastAddMutation=r;
    lastMutationType=true;
    return(r);
  }

  int tmpcount=0;
  int i;
  for (i=1; i<net->links.size(); ++i){
    if (gref[i]==1 && genotype[i]==0 && (!periphery_only || is_connected(net->links[i]))) ++tmpcount;
//    if (gref[i]==1 && genotype[i]==0) ++count;
  }
  lwarn("exceeded mutate_toward add tries, searching for addable reactions");
  if(tmpcount==0){ lwarn("no available reactions for adding"); lastAddMutation=-1; return(-1); };
  r=(int)(ernd.uniform()*tmpcount);
  for (i=1; i<net->links.size(); ++i){
    if (gref[i]==1 && genotype[i]==0 && (!periphery_only || is_connected(net->links[i]))){
//    if (gref[i]==1 && genotype[i]==0){
      if (r==0){
        activate(i);
        lastAddMutation=i;
        lastMutationType=true;
        return(i);
      }
      --r;
    }
  }

  return(-1);
}

int erandomWalk::mutate_remove_toward(eintarray& gref)
{
  int r;
  int c=0;
  while(c<20){
    ++c;
    r=(int)(ernd.uniform()*(net->links.size()-1))+1;
    
    if (r < gref.size() && gref[r]==1 || genotype[r] == 0 || net->links[r].transport && !mutate_transport) continue;
    disable(r);
    lastRemoveMutation=r;
    lastMutationType=false;
    return(r);
  }

  int tmpcount=0;
  int i;
  for (i=1; i<net->links.size(); ++i){
    if (gref[i]==0 && genotype[i]==1 && (net->links[i].transport==false || mutate_transport)) ++tmpcount;
  }
  lwarn("exceeded remove tries, searching for removable reactions");
  if(tmpcount==0){ lwarn("no available reactions for removal"); lastRemoveMutation=-1; return(-1); };
  r=(int)(ernd.uniform()*tmpcount);
  for (i=1; i<net->links.size(); ++i){
    if (gref[i]==0 && genotype[i]==1 && (net->links[i].transport==false || mutate_transport)){
      if (r==0){
        disable(i);
        lastRemoveMutation=i;
        lastMutationType=false;
        return(i);
      }
      --r;
    }
  }

  return(-1);
}


double gendistance(eintarray& arr,eintarray& arr2,erandomWalk *rw)
{
  int tcount,acount1,acount2;
  int i;
  tcount=0;
  acount1=0; acount2=0;
  for (i=1; i<arr.size(); ++i){  // i starts in 1 (instead of 0) because we dont count the objective function as a reaction
    if (rw && !rw->mutate_transport && rw->net->links[i].transport) continue; // if we are not mutating transport reactions we dont count them for the gendistance
    if (arr[i]-arr2[i]!=0) ++tcount;
    if (arr[i]==1) ++acount1;
    if (arr2[i]==1) ++acount2;
  }
  return((double)tcount/(double)(acount1+acount2));
}


double gendistance2(eintarray& arr,eintarray& arr2,erandomWalk *rw)
{
  int tcount,acount1,acount2;
  int i;
  tcount=0;
  acount1=0; acount2=0;
  for (i=1; i<arr.size(); ++i){  // i starts in 1 (instead of 0) because we dont count the objective function as a reaction
    if (rw && !rw->mutate_transport && rw->net->links[i].transport) continue; // if we are not mutating transport reactions we dont count them for the gendistance
    if (arr[i]-arr2[i]!=0) ++tcount;
    if (arr[i]==1) ++acount1;
    if (arr2[i]==1) ++acount2;
  }
  return(double)tcount;
}

double gendistance3(eintarray& arr,eintarray& arr2)
{
  int tcount;
  int i;
  tcount=0;

  for (i=0; i<arr.size(); ++i){  // i starts in 1 (instead of 0) because we dont count the objective function as a reaction
    if (arr[i]-arr2[i]!=0) ++tcount;
  }
  return(double)tcount;
}



bool erandomWalk::isViable3(int num, int cs){
  int i;
  int count=0;
  if (phenotype[cs]==0) {return(false);}
  for (i=0; i<viablePhenotype.size(); ++i){if (phenotype[i]==1){count++;}}
  if (count<num) {return(false);}
  return(true);
}


bool erandomWalk::isViable2(){
  int i;
  int count=0;
  for (i=0; i<viablePhenotype.size(); ++i){
    if (phenotype[i]==1){count++;}
  }
  if (count==0) {return(false);}
  return(true);
}

bool erandomWalk::isViable()
{
  int i;

  if (strictViable){
    for (i=0; i<viablePhenotype.size(); ++i){
         if (viablePhenotype[i]==1 && phenotype[i]==0 || viablePhenotype[i]==0 && phenotype[i]==1)
             return(false);
    }
    return(true);
  }
  for (i=0; i<viablePhenotype.size(); ++i){
    if (viablePhenotype[i]==1 && phenotype[i]==0)
      return(false);
  }
  return(true);
}
/////////////////////////////////////////////// New viability func for strict phes. 
bool erandomWalk::isViable_strict()
{
  int i;
 
    for (i=0; i<viablePhenotype.size(); ++i){
		cout << "Entering FOR in Viable_STRICT" << endl;
      if (viablePhenotype[i]==1 && phenotype[i]==0 || viablePhenotype[i]==0 && phenotype[i]==1)
//		if (viablePhenotype[i]==1 && phe[i]==0) {
	    return(false);
    }
    return(true);
}
/////////////////////////////////////////////////

bool erandomWalk::isViable(const eintarray& phe)
{

  int i;
  if (strictViable){
    for (i=0; i<viablePhenotype.size(); ++i){
      if (viablePhenotype[i]==1 && phe[i]==0 || viablePhenotype[i]==0 && phe[i]==1)
        return(false);
    }
   return(true);
  }
  for (i=0; i<viablePhenotype.size(); ++i){
    if (viablePhenotype[i]==1 && phe[i]==0)
      return(false);
  }
  return(true); 
}

estr erandomWalk::printPhenotype()
{
  int i;
  estr res;

  res+=intarr2str(phenotype);
/*
  for (i=0; i<phenotype.size()-1; ++i)
    {res+=phenotype[i]; res +=", ";}
  if (phenotype.size())
    res+=phenotype[i];
*/
  return(res);
}

estr erandomWalk::printGrowthRate()
{
  int i;
  estr res;

  for (i=0; i<phenotype.size()-1; ++i)
    {res+=growthRate[i]; res +=", ";}
  if (phenotype.size())
    res+=growthRate[i];
  return(res);
}

void erandomWalk::findmin_noflux()
{
  eintarray ogen(genotype);

  eintarray agen;
  int i;
  for (i=0; i<net->links.size(); ++i)
    agen.add(0);

  int j;
  for (j=0; j<solvers.size(); ++j){
    if (phenotype[j]==1){
      for (i=0; i<net->links.size(); ++i){
        if (genotype[i]==1 && fabs(solvers.at(j).x[i]) >= 1.0e-8)
          agen[i]=1;
      }
//      break;
    }
  }

  int c,t;
  c=0;t=0;
  for (i=0; i<net->links.size(); ++i){
    if (genotype[i]==1){
      ++t;
      if (agen[i]==1) ++c;
    }
  }

//  cout << "Total reactions: "<<t<<" | Inactive: "<<t-c<<endl;
  for (i=0; i<net->links.size(); ++i){
    if (genotype[i]==1 && agen[i]==0)
      disable(i);
  }
  eintarray ophe(phenotype);

  updatePhenotypeRemoval();

  ldieif(ophe != phenotype,"some inactive reactions appear to be essential for phenotype!: "+estr(countPhenotype(ophe))+" "+estr(countPhenotype(phenotype)));
//   cout << "Everything is fine!!!" << endl;

  int inviable=0;
  int viable=0;
  int transport=0;

  for (i=1; i<genotype.size(); ++i){
    if (net->links[i].transport && !mutate_transport)
      ++transport;
  }

  eintarray ess;
  for (i=0; i<genotype.size(); ++i) ess.add(0);

  ophe=phenotype;

  int mut=0;
  int esscount=0;
  while (-1!=(mut=mutate_remove_ess_mincount(esscount,ess))){
    updatePhenotypeRemoval();
    if (!isViable()){
      ess[mut]=1; esscount++;
      phenotype=ophe; activate(mut);
    }
  }
  mingenotype.add(genotype);
  for (i=1; i<genotype.size(); ++i)
    if (genotype[i]==1) ++mincount[i];

  load(ogen);
  cout << "# found minimal network ("<< mingenotype.size()-1 << "): " << esscount+secount << "  total initial: " << t << " inactive: " << t-c << endl;
}


void erandomWalk::findmin_similar()
{
  eintarray ogen(genotype);

  eintarray ess;
  int i;
  for (i=0; i<genotype.size(); ++i) ess.add(0);

  eintarray ophe;
  ophe=phenotype;

//  for (i=1; i<genotype.size(); ++i)
//    if (genotype[i]==1 && mincount[i]==0) disable(i);

  updatePhenotypeRemoval();
  if (!isViable()) load(ogen);

  int mut=0;
  int esscount=0;
  while (-1!=(mut=mutate_remove_ess_mincount_similar(esscount,ess))){
    updatePhenotypeRemoval();
    if (!isViable()){
      ess[mut]=1; esscount++;
      phenotype=ophe; activate(mut);
    }
  }
  mingenotype.add(genotype);
  for (i=1; i<genotype.size(); ++i)
    if (genotype[i]==1) ++mincount[i];

  load(ogen);
  cout << "# found minimal network ("<< mingenotype.size()-1 << "): " << esscount+secount+net->transport_count << endl;
}

void erandomWalk::findminKeep(eintarray& keepgen)
{
  eintarray ess(keepgen); // we set all the reactions we want to keep as essential

  ess[0]=0;
  int i;
  for (i=1; i<ess.size(); ++i)
    if (genotype[i]==0 || (mutate_transport==0 && net->links[i].transport) || superess[i]==1) ess[i]=0;


  calcPhenotype();
  ldieif(!isViable(),"initial network is not viable");
  eintarray ophe(phenotype);

  int mut=0;
  int esscount=countPhenotype(ess);

  while (-1!=(mut=mutate_remove_ess(esscount,ess))){
    updatePhenotypeRemoval();
    if (!isViable()){
      ess[mut]=1; esscount++;
      phenotype=ophe; activate(mut);
    }
  }
}

bool erandomWalk::fluxVar(int ind,double& min,double& max)
{
  solvers.at(0).setxbounds(0,0.0,1000.0);
  solvers.at(0).setxbounds(ind,0.0,1000.0); // So we do not get unbounded solutions in case there are futile cycles
  solvers.at(0).setobjective(ind);
  max=solvers.at(0).solve();

  min=0.0;
  if (!net->links.values(ind).irreversible){
    solvers.at(0).setxbounds(ind,-1000.0,0.0); // So we do not get unbounded solutions in case there are futile cycles
    solvers.at(0).setobjective(ind,-1);
    min=solvers.at(0).solve();
  }

  if (max==-1.0 || min==-1.0){
    lwarn("Infeasible model");
    return(false);
  }

  solvers.at(0).setobjective(0);  
  solvers.at(0).setxbounds(0,0.0,1000.0); // reset biomass function bounds
  solvers.at(0).activate(ind); // set default values

//  if (max<=1.0e-8 && min>=-1.0e-8) return(false); // blocked reaction
  if (abs(max)<=1.0e-800 && abs(min)<=1.0e-800) return(false); // blocked reaction

  return(true);
}

bool erandomWalk::findminWith2(int ind)
{
  ldieif(superess[ind]==1,"Reaction is super essential");
  eintarray ess;
  int i;
  for (i=0; i<genotype.size(); ++i) ess.add(0);

  calcPhenotype();
  ldieif(!isViable(),"initial network is not viable");

  eintarray ogen(genotype);
  eintarray ophe(phenotype);

  mingenotype.clear();
  mincount.clear();
  for (i=0; i<genotype.size(); ++i)
    mincount.add(0);


  while (isViable()){
    load(ogen);
    for (i=0; i<genotype.size(); ++i) ess[i]=0;
    ess[ind]=1; // we set the reaction as essential so that it does not get removed

    // Lets force a flux through the reaction and then find the minimal network
    double fluxmin,fluxmax;
    if (!fluxVar(ind,fluxmin,fluxmax)){ lwarn("blocked reaction: "+net->links.keys(ind)); return(false); }
  
    cout << " fluxmin: " << fluxmin << " fluxmax: "<<fluxmax << endl;
    int mut=0;
    int esscount=1;
    while (-1!=(mut=mutate_remove_ess_mincount(esscount,ess))){
      updatePhenotypeRemoval();

      if (!isViable() || !fluxVar(ind,fluxmin,fluxmax)){ // make sure that removed reactions do not block this reaction or make the network inviable
        ess[mut]=1; esscount++;
        phenotype=ophe; activate(mut); continue;
      }
      cout << " fluxmin: " << fluxmin << " fluxmax: "<<fluxmax << endl;
//    linfo(" fluxmin: "+estr(fluxmin)+" fluxmax: "+fluxmax);
    }

    // We now check if the reaction is still essential
    disable(ind);
    updatePhenotypeRemoval();

    mingenotype.add(genotype);
    for (i=1; i<genotype.size(); ++i)
      if (genotype[i]==1) ++mincount[i];
  }

  if (isViable()) { lwarn("reaction not essential"); return(false); } // Reaction is not needed in this minimal network

  activate(ind);

  return(true);
}

bool erandomWalk::findminWith(int ind)
{
  ldieif(superess[ind]==1,"Reaction is super essential");
  eintarray ess;
  int i;
  for (i=0; i<genotype.size(); ++i) ess.add(0);

  calcPhenotype();
  ldieif(!isViable(),"initial network is not viable");

  eintarray ophe(phenotype);

  ess[ind]=1; // we set the reaction as essential so that it does not get removed

  // Lets force a flux through the reaction and then find the minimal network
  double fluxmin,fluxmax;
  if (!fluxVar(ind,fluxmin,fluxmax)){ lwarn("blocked reaction: "+net->links.keys(ind)); return(false); }
  
  cout << " fluxmin: " << fluxmin << " fluxmax: "<<fluxmax << endl;
  int mut=0;
  int esscount=1;
  while (-1!=(mut=mutate_remove_ess(esscount,ess))){
    updatePhenotypeRemoval();

    if (!isViable() || !fluxVar(ind,fluxmin,fluxmax)){ // make sure that removed reactions do not block this reaction or make the network inviable
      ess[mut]=1; esscount++;
      phenotype=ophe; activate(mut); continue;
    }
    cout << " fluxmin: " << fluxmin << " fluxmax: "<<fluxmax << endl;
//    linfo(" fluxmin: "+estr(fluxmin)+" fluxmax: "+fluxmax);
  }

  // We now check if the reaction is still essential
  disable(ind);
  updatePhenotypeRemoval();

  if (isViable()) { lwarn("reaction not essential"); return(false); } // Reaction is not needed in this minimal network

  activate(ind);

  return(true);
}

void erandomWalk::findmin()
{
  eintarray ogen(genotype);

  eintarray ess;
  int i;
  for (i=0; i<genotype.size(); ++i) ess.add(0);

  eintarray ophe;
  ophe=phenotype;

  int mut=0;
  int esscount=0;
  while (-1!=(mut=mutate_remove_ess_mincount(esscount,ess))){
    updatePhenotypeRemoval();
    if (!isViable()){
      ess[mut]=1; esscount++;
      phenotype=ophe; activate(mut);
    }
  }
  mingenotype.add(genotype);
  for (i=1; i<genotype.size(); ++i)
    if (genotype[i]==1) ++mincount[i];

  load(ogen);
  cout << "# found minimal network ("<< mingenotype.size()-1 << "): " << esscount+secount+net->transport_count << endl;
}

bool allSuperess(eintarray& gen,eintarray& superess)
{
  int i;
  for (i=0; i<gen.size(); ++i){
    if (superess[i]==1 && gen[i]==0) return(false);
  }
  return(true);
}

bool isComplete(eintarray& gen,earray<eintarray>& mingenotypes,estr& nummin)
{
  nummin="";
  int i,j;
  for (i=0; i<mingenotypes.size(); ++i){
    for (j=0; j<gen.size(); ++j){
      if (mingenotypes[i][j]==1 && gen[j]==0) break;
    }
    if (j==gen.size()) {nummin+=estr(i)+",";} // return(true);
  }
  
  if (nummin.len()){ nummin.del(-1); return(true); }
  return(false);
}

void erandomWalk::runmin(const enet& net2,int niter)
{
  int i;

  eintarray gref;
  eintarray oldphe;
  int grefcount;

  double maxgendist=0.0;

  calcPhenotype();

  cout << "# Growth with whole network: "<<printGrowthRate()<<endl;
  cout << "# Number of total reactions in whole network: "<<acount<<endl;

  load(net2);
  gref = genotype;
  grefcount = acount;

  calcPhenotype();
  oldphe=phenotype;
  cout << "# Growth only with start network: " << printPhenotype()<<endl;
  cout << "# Number of total reactions in start network: "<<acount<<endl;
  cout << "# Reference Size: "<< 1.0/icount << endl;

  cout << "# iter   changed_reaction   total_reactions  hamming_distance  growth_rates  phenotype" << endl;

  estr nummin;
  for (i=0; i<niter; ++i){
    mutate();
    if (!allSuperess(genotype,superess)){
      revert(); --i; continue;
    }

    if (!isComplete(genotype,mingenotype,nummin)){
      calcPhenotype();
      if (!isViable()){
        if (print_rejected){
          acount <= count ? cout << "#- "<<net->links[lastRemoveMutation].info[0] << "("<<lastRemoveMutation<<") " : cout << "#+ "<<net->links[lastAddMutation].info[0] << "("<<lastAddMutation<<") ";
          cout << endl;
        }
//      cout << acount << " " << gendistance(genotype,gref,this) << " ["<< printPhenotype()<<"]" << endl;
        revert();
        phenotype=oldphe;

//      ldieif(lastAddMutation==-1 || lastRemoveMutation==-1,"unable to add or delete reaction");
        --i; // do not count non-viable mutations
        continue;
      }else{
        findmin_similar();
      }
    }
//    ldieif(lastAddMutation==-1 || lastRemoveMutation==-1,"unable to add or delete reaction");

    double tmpgendist=gendistance(genotype,gref,this);
    if (tmpgendist>maxgendist) maxgendist=tmpgendist;

    cout << i << " ";
    acount <= count ? cout << "- "<<net->links[lastRemoveMutation].info[0] << "("<<lastRemoveMutation<<") " : cout << "+ "<<net->links[lastAddMutation].info[0] << "("<<lastAddMutation<<") ";
    cout << acount << " " << tmpgendist << " " << maxgendist;
    if (phenotype != oldphe) cout << " [ " << printPhenotype() << " ]";
    cout << " " << nummin;
    cout << endl;
    oldphe = phenotype;
  }

  calcPhenotype();
  cout << "# final: " << i << " " << acount << " " << gendistance(genotype,gref,this) << " " << maxgendist << " "<< printGrowthRate() <<" [" << printPhenotype()<<"]" << endl;
}

void erandomWalk::run_univ(const enet& net2,int niter,int univ)
{
  int i;

  eintarray gref;
  eintarray oldphe;
  int grefcount;

  double maxgendist=0.0;

  calcPhenotype();

  cout << "# Growth with whole network: "<<printGrowthRate()<<endl;
  cout << "# Number of total reactions in whole network: "<<acount<<endl;

  load(net2);
  gref = genotype;
  grefcount = acount;

  calcPhenotype();
  oldphe=phenotype;
  cout << "# Growth only with start network: " << printPhenotype()<<endl;
  cout << "# Number of total reactions in start network: "<<acount<<endl;
  cout << "# Reference Size: "<< 1.0/icount << endl;

  cout << "# changed_reaction   total_reactions  hamming_distance  growth_rates  phenotype" << endl;

  lastMutationType=false;

  for (i=0; i<niter; ++i){
    mutate_univ(univ);

    updatePhenotype_univ();
    if (!isViable()){
      if (print_rejected){
        if (!lastMutationType && lastRemoveMutation==-1)
          cout << "#- UREACTION";
        else if (lastMutationType && lastAddMutation==-1)
          cout << "#+ UREACTION";
        else
          !lastMutationType ? cout << "#- "<<net->links[lastRemoveMutation].info[0] << " " : cout << "#+ "<<net->links[lastAddMutation].info[0] << " ";
        cout << endl;
      }
//      cout << acount << " " << gendistance(genotype,gref,this) << " ["<< printPhenotype()<<"]" << endl;
      revert_univ();
      lastMutationType=!lastMutationType;
      phenotype=oldphe;

//      ldieif(lastAddMutation==-1 || lastRemoveMutation==-1,"unable to add or delete reaction");
      --i; // do not count non-viable mutations
      continue;
    }
//    ldieif(lastAddMutation==-1 || lastRemoveMutation==-1,"unable to add or delete reaction");

    double tmpgendist=gendistance(genotype,gref,this);
    if (tmpgendist>maxgendist) maxgendist=tmpgendist;

    if (!lastMutationType && lastRemoveMutation==-1)
      cout << "- UREACTION ";
    else if (lastMutationType && lastAddMutation==-1)
      cout << "+ UREACTION ";
    else
      !lastMutationType ? cout << "- "<<net->links[lastRemoveMutation].info[0] << " " : cout << "+ "<<net->links[lastAddMutation].info[0] << " ";
    cout << acount << " " << tmpgendist << " " << maxgendist;
    cout << " " << printGrowthRate();
    if (phenotype != oldphe) cout << " [ " << printPhenotype() << " ]";
    cout << endl;
    oldphe = phenotype;
  }

  calcPhenotype();
  cout << "# final: " << acount << " " << gendistance(genotype,gref,this) << " " << maxgendist << " "<< printGrowthRate() <<" [" << printPhenotype()<<"]" << endl;
}

void erandomWalk::run(const enet& net2,int niter)
{
  int i;

  eintarray gref;
  eintarray oldphe;
  int grefcount;

  double maxgendist=0.0;

  calcPhenotype();

  cout << "# Growth with whole network: "<<printGrowthRate()<<endl;
  cout << "# Number of total reactions in whole network: "<<acount<<endl;

  load(net2);
  gref = genotype;
  grefcount = acount;

  calcPhenotype();
  oldphe=phenotype;
  cout << "# Growth only with start network: " << printPhenotype()<<endl;
  cout << "# Number of total reactions in start network: "<<acount<<endl;
  cout << "# Reference Size: "<< 1.0/icount << endl;

  cout << "# changed_reaction   total_reactions  hamming_distance  growth_rates  phenotype" << endl;

  for (i=0; i<niter; ++i){
    mutate();

    updatePhenotype();
    if (!isViable()){
      if (print_rejected){
        !lastMutationType ? cout << "#- "<<net->links[lastRemoveMutation].info[0] << " " : cout << "#+ "<<net->links[lastAddMutation].info[0] << " ";
        cout << endl;
      }
//      cout << acount << " " << gendistance(genotype,gref,this) << " ["<< printPhenotype()<<"]" << endl;
      revert();
      phenotype=oldphe;

//      ldieif(lastAddMutation==-1 || lastRemoveMutation==-1,"unable to add or delete reaction");
      --i; // do not count non-viable mutations
      continue;
    }
//    ldieif(lastAddMutation==-1 || lastRemoveMutation==-1,"unable to add or delete reaction");

    double tmpgendist=gendistance(genotype,gref,this);
    if (tmpgendist>maxgendist) maxgendist=tmpgendist;

    !lastMutationType ? cout << "- "<<net->links[lastRemoveMutation].info[0] << " " : cout << "+ "<<net->links[lastAddMutation].info[0] << " ";
    cout << acount << " " << tmpgendist << " " << maxgendist;
    cout << " " << printGrowthRate();
    if (phenotype != oldphe) cout << " [ " << printPhenotype() << " ]";
    cout << endl;
    oldphe = phenotype;
  }

  calcPhenotype();
  cout << "# final: " << acount << " " << gendistance(genotype,gref,this) << " " << maxgendist << " "<< printGrowthRate() <<" [" << printPhenotype()<<"]" << endl;
}


void erandomWalk::run2(const enet& net2,int niter, int num, int cs)
{
  int i;
  
  eintarray gref;
  eintarray oldphe;
  int grefcount;

  double maxgendist=0.0;

  calcPhenotype();

  cout << "# Growth with whole network: "<<printGrowthRate()<<endl;
  cout << "# Number of total reactions in whole network: "<<acount<<endl;

  load(net2);
  gref = genotype;
  grefcount = acount;

  calcPhenotype();
  oldphe=phenotype;
  cout << "# Growth only with start network: " << printPhenotype()<<endl;
  cout << "# Number of total reactions in start network: "<<acount<<endl;
  cout << "# Reference Size: "<< 1.0/icount << endl;

  cout << "# changed_reaction   total_reactions  hamming_distance  growth_rates  phenotype" << endl;

  for (i=0; i<niter; ++i){
    mutate();

    updatePhenotype();
    if (!isViable3(num,cs)){
      if (print_rejected){
        !lastMutationType ? cout << "#- "<<net->links[lastRemoveMutation].info[0] << " " : cout << "#+ "<<net->links[lastAddMutation].info[0] << " ";
        cout << endl;
      }
//      cout << acount << " " << gendistance(genotype,gref,this) << " ["<< printPhenotype()<<"]" << endl;
      revert();
      phenotype=oldphe;

//      ldieif(lastAddMutation==-1 || lastRemoveMutation==-1,"unable to add or delete reaction");
      --i; // do not count non-viable mutations
      continue;
    }
//    ldieif(lastAddMutation==-1 || lastRemoveMutation==-1,"unable to add or delete reaction");

    double tmpgendist=gendistance(genotype,gref,this);
    if (tmpgendist>maxgendist) maxgendist=tmpgendist;

    !lastMutationType ? cout << "- "<<net->links[lastRemoveMutation].info[0] << " " : cout << "+ "<<net->links[lastAddMutation].info[0] << " ";
    cout << acount << " " << tmpgendist << " " << maxgendist;
    cout << " " << printGrowthRate();
    if (phenotype != oldphe) cout << " [ " << printPhenotype() << " ]";
    cout << endl;
    oldphe = phenotype;
  }

  calcPhenotype();
  cout << "# final: " << acount << " " << gendistance(genotype,gref,this) << " " << maxgendist << " "<< printGrowthRate() <<" [" << printPhenotype()<<"]" << endl;
}

///////////////////////////////////////////////////////////

void erandomWalk::run_strict(const enet& net2,int niter,eintarray& phe_target)
{
  int i,j,tmpcount;
	viablePhenotype=phe_target;
  eintarray gref;
  eintarray oldphe;
  int grefcount;

  double maxgendist=0.0;

  calcPhenotype();

  cout << "# Growth with whole network: "<<printGrowthRate()<<endl;
  cout << "# Number of total reactions in whole network: "<<acount<<endl;

  load(net2);
  gref = genotype;
  grefcount = acount;

  calcPhenotype();
  oldphe=phenotype;
  cout << "# Growth only with start network: " << printPhenotype()<<endl;
  cout << "# Number of total reactions in start network: "<<acount<<endl;
  cout << "# Reference Size: "<< 1.0/icount << endl;
  cout << "# viablePhenotype: " << intarr2str(viablePhenotype) << endl;
  cout << "# changed_reaction   total_reactions  hamming_distance  growth_rates  phenotype" << endl;


  for (i=0; i<niter; ++i){
    mutate();
//		cout << "entering FOR after mutate" <<endl;
    updatePhenotype();
		
    if (!isViable()){
      if (print_rejected){
        !lastMutationType ? cout << "#- "<<net->links[lastRemoveMutation].info[0] << " " : cout << "#+ "<<net->links[lastAddMutation].info[0] << " ";
        cout << endl;
      }
//      cout << acount << " " << gendistance(genotype,gref,this) << " ["<< printPhenotype()<<"]" << endl;
      revert();
			
      phenotype=oldphe;

//      ldieif(lastAddMutation==-1 || lastRemoveMutation==-1,"unable to add or delete reaction");
      --i; // do not count non-viable mutations
      continue;
    }
		else {
			if (countPhenotype(phenotype) > countPhenotype(oldphe)) {
        !lastMutationType ? cout << "#- "<<net->links[lastRemoveMutation].info[0] << " " : cout << "#+ "<<net->links[lastAddMutation].info[0] << " ";
        cout << endl;

	     revert();
	     phenotype=oldphe;
      --i; // do not count non-viable mutations
      continue;
			}
		}

//    ldieif(lastAddMutation==-1 || lastRemoveMutation==-1,"unable to add or delete reaction");

    double tmpgendist=gendistance(genotype,gref,this);
    if (tmpgendist>maxgendist) maxgendist=tmpgendist;

    !lastMutationType ? cout << "- "<<net->links[lastRemoveMutation].info[0] << " " : cout << "+ "<<net->links[lastAddMutation].info[0] << " ";
    cout << acount << " " << tmpgendist << " " << maxgendist;
    cout << " " << printPhenotype();
    if (phenotype != oldphe) cout << " [ " << printPhenotype() << " ]";
    cout << endl;
    oldphe = phenotype;
		tmpcount = 0;
		for (j=0; j<viablePhenotype.size(); ++j) {
			if (viablePhenotype[j]==phenotype[j]) {tmpcount++;} 
		}
		if (tmpcount==countPhenotype(phenotype)) break;
  }

  calcPhenotype();
  cout << "# final: " << acount << " " << gendistance(genotype,gref,this) << " " << maxgendist << " "<< " [" << printPhenotype()<<"]" << endl;
}
///////////////////////////////////////////////////////////

void erandomWalk::run_dist(const enet& net2,double gendist)   //const enet& net2,double gendistance
{
 int i=0;

  eintarray gref;
  eintarray oldphe;
  int grefcount;


  double maxgendist=0.0;

  calcPhenotype();
  cout << "# Growth with start network: "<<printGrowthRate()<<endl;
  cout << "# Number of total reactions in whole network: "<<acount<<endl;

 // load(net2);
  gref = genotype;
  grefcount = acount;

//  calcPhenotype();
  oldphe=phenotype;

  cout << "# Phenotype of the start network: " << printPhenotype()<<endl;
  cout << "# Number of total reactions in start network: "<<acount<<endl;
  cout << "# Reference Size: "<< 1.0/icount << endl;

  cout << "# changed_reaction   total_reactions  hamming_distance  growth_rates  phenotype" << endl;

  double tmpgendist=0.0;
  while (tmpgendist<gendist){
//    if (acount*icount-0.5 >= 1.0) { cout << "# reached 1398 links" << endl; break; }// we reached the maximum number of reactions when only removals are possible since Pr=1398/932-0.5 = 1.0

    mutate();
    i+=1;
    updatePhenotype();
    if (!isViable()){
      if (print_rejected){
        acount <= count ? cout << "#- "<<net->links[lastRemoveMutation].info[0] << "("<<lastRemoveMutation<<") " : cout << "#+ "<<net->links[lastAddMutation].info[0] << "("<<lastAddMutation<<") ";
        cout << endl;
      }
//      cout << acount << " " << gendistance(genotype,gref,this) << " ["<< printPhenotype()<<"]" << " " << i << endl;
      revert();
      phenotype=oldphe;

//      ldieif(lastAddMutation==-1 || lastRemoveMutation==-1,"unable to add or delete reaction");
      --i; // do not count non-viable mutations
      continue;
    }
//    ldieif(lastAddMutation==-1 || lastRemoveMutation==-1,"unable to add or delete reaction");

    tmpgendist=gendistance(genotype,gref,this);
    if (tmpgendist>maxgendist) maxgendist=tmpgendist;

    acount <= count ? cout << "- "<<net->links[lastRemoveMutation].info[0] << "("<<lastRemoveMutation<<") " : cout << "+ "<<net->links[lastAddMutation].info[0] << "("<<lastAddMutation<<") ";
    cout << acount << " " << tmpgendist << " " << maxgendist;
    if (phenotype != oldphe) cout << " [ " << printPhenotype() << " ]";
    
    cout << " " << i << endl;

    oldphe = phenotype;
    if (tmpgendist>=gendist) {break;}
  }

  calcPhenotype();
  cout << "# final: " << acount << " " <<gendistance(genotype,gref,this) << " " << maxgendist << " "<< printGrowthRate() << " [" << printPhenotype()<<"]" << endl;

}



void erandomWalk::run_dist2(const enet& net2,double gendist)   //const enet& net2,double gendistance
{
 int i=0;

  eintarray gref;
  eintarray oldphe;
  int grefcount;


  double maxgendist=0.0;

  calcPhenotype();
  cout << "# Growth with start network: "<<printGrowthRate()<<endl;
  cout << "# Number of total reactions in whole network: "<<acount<<endl;

 // load(net2);
  gref = genotype;
  grefcount = acount;

//  calcPhenotype();
  oldphe=phenotype;

  cout << "# Phenotype of the start network: " << printPhenotype()<<endl;
  cout << "# Number of total reactions in start network: "<<acount<<endl;
  cout << "# Reference Size: "<< 1.0/icount << endl;

  cout << "# changed_reaction   total_reactions  hamming_distance  growth_rates  phenotype" << endl;

  double tmpgendist=0.0;
  while (tmpgendist<gendist){
//    if (acount*icount-0.5 >= 1.0) { cout << "# reached 1398 links" << endl; break; }// we reached the maximum number of reactions when only removals are possible since Pr=1398/932-0.5 = 1.0

    mutate();
    i+=1;
    updatePhenotype();
    if (!isViable()){
      if (print_rejected){
        acount <= count ? cout << "#- "<<net->links[lastRemoveMutation].info[0] << "("<<lastRemoveMutation<<") " : cout << "#+ "<<net->links[lastAddMutation].info[0] << "("<<lastAddMutation<<") ";
        cout << endl;
      }
//      cout << acount << " " << gendistance(genotype,gref,this) << " ["<< printPhenotype()<<"]" << " " << i << endl;
      revert();
      phenotype=oldphe;

//      ldieif(lastAddMutation==-1 || lastRemoveMutation==-1,"unable to add or delete reaction");
      --i; // do not count non-viable mutations
      continue;
    }
//    ldieif(lastAddMutation==-1 || lastRemoveMutation==-1,"unable to add or delete reaction");

    tmpgendist=gendistance2(genotype,gref,this);
    if (tmpgendist>maxgendist) maxgendist=tmpgendist;

    acount <= count ? cout << "- "<<net->links[lastRemoveMutation].info[0] << "("<<lastRemoveMutation<<") " : cout << "+ "<<net->links[lastAddMutation].info[0] << "("<<lastAddMutation<<") ";
    cout << acount << " " << tmpgendist << " " << maxgendist;
    if (phenotype != oldphe) cout << " [ " << printPhenotype() << " ]";
    
    cout << " " << i << endl;

    oldphe = phenotype;
    if (tmpgendist>=gendist) {break;}
  }

  calcPhenotype();
  cout << "# final: " << acount << " " <<gendistance2(genotype,gref,this) << " " << maxgendist << " "<< printGrowthRate() << " [" << printPhenotype()<<"]" << endl;

}


void erandomWalk::run_dist3(const enet& net2,double gendist, double phendist) {
  int i=0;
  eintarray gref;
  eintarray oldphe;
  eintarray veryoldphe;
  eintarray tempfe;
  int grefcount;

  double maxgendist=0.0;

  calcPhenotype();
  cout << "# Growth with start network: "<<printGrowthRate()<<endl;
  cout << "# Number of total reactions in whole network: "<<acount<<endl;

  //load(net2);
  gref = genotype;
  grefcount = acount;

  //calcPhenotype();
  oldphe=phenotype;
  veryoldphe=phenotype;
  int fendist=gendistance2(veryoldphe,oldphe,this);
  double fendist2=(double) fendist;
  cout << "# Phenotype of the start network: " << printPhenotype()<<endl;
  cout << "# Number of total reactions in start network: "<<acount<<endl;
  cout << "# Reference Size: "<< 1.0/icount << endl;
  cout << "# changed_reaction   total_reactions  hamming_distance  growth_rates  phenotype" << endl;

  double tmpgendist=0.0;
  int definer=0;

  while (tmpgendist<gendist){

    mutate();
    i+=1;
    updatePhenotype();

    if (!isViable2()){
       if (print_rejected){
          acount <= count ? cout << "#- "<<net->links[lastRemoveMutation].info[0] << "("<<lastRemoveMutation<<") " : cout << "#+ "<<net->links[lastAddMutation].info[0] << "("<<lastAddMutation<<") ";
          cout << endl;
       }
       revert();
       phenotype=oldphe;

       --i;
       continue;
    }

    if (definer==1){
        tempfe=phenotype;
        int tempdist=gendistance2(veryoldphe,tempfe,this);
        if (tempdist!=phendist){revert();phenotype=oldphe;--i;continue;}
    }

    tmpgendist=gendistance2(genotype,gref,this);
    if (tmpgendist>maxgendist) maxgendist=tmpgendist;

    acount <= count ? cout << "- "<<net->links[lastRemoveMutation].info[0] << "("<<lastRemoveMutation<<") " : cout << "+ "<<net->links[lastAddMutation].info[0] << "("<<lastAddMutation<<") ";
    cout << acount << " " << tmpgendist << " " << maxgendist;
    if (phenotype != oldphe) cout << " [ " << printPhenotype() << " ]";
    
    cout << " " << i << endl;

    oldphe = phenotype;
    int fendist=gendistance2(veryoldphe,oldphe,this);
    double fendist2= (double) fendist;
    if (fendist2==phendist) {definer=1;}
    if (tmpgendist>=gendist) {break;}
  }

  calcPhenotype();
  cout << "# final: " << acount << " " <<gendistance2(genotype,gref,this) << " " << maxgendist << " "<< printGrowthRate() << " [" << printPhenotype()<<"]" << endl;

}



void erandomWalk::run_genpool_univ(const enet& net2,int niter,eintarray& genpool,int genpoolcount,float exthgt,int univ)
{
  int i;

  eintarray gref;
  eintarray oldphe;
  int grefcount;

  double maxgendist=0.0;

  calcPhenotype();

  cout << "# Growth with whole network: "<<printGrowthRate()<<endl;
  cout << "# Number of total reactions in whole network: "<<acount<<endl;

  load(net2);
  gref = genotype;
  grefcount = acount;

  calcPhenotype();
  oldphe=phenotype;
  cout << "# Growth only with start network: " << printPhenotype()<<endl;
  cout << "# Number of total reactions in start network: "<<acount<<endl;
  cout << "# Reference Size: "<< 1.0/icount << endl;

  cout << "# changed_reaction   total_reactions  hamming_distance  growth_rates  phenotype" << endl;


  for (i=0; i<niter; ++i){
    mutate_genpool_univ(genpool,genpoolcount,exthgt,univ);

    updatePhenotype_univ();
    if (!isViable()){
      if (print_rejected){
        if (!lastMutationType && lastRemoveMutation==-1)
          cout << "#- UREACTION";
        else if (lastMutationType && lastAddMutation==-1)
          cout << "#+ UREACTION";
        else
          !lastMutationType ? cout << "#- "<<net->links[lastRemoveMutation].info[0] << "("<<lastRemoveMutation<<") " : cout << "#+ "<<net->links[lastAddMutation].info[0] << "("<<lastAddMutation<<") ";
        cout << endl;
      }
//      cout << acount << " " << gendistance(genotype,gref,this) << " ["<< printPhenotype()<<"]" << endl;
      revert_univ();
      lastMutationType=!lastMutationType;
      phenotype=oldphe;

//      ldieif(lastAddMutation==-1 || lastRemoveMutation==-1,"unable to add or delete reaction");
      --i; // do not count non-viable mutations
      continue;
    }
//    ldieif(lastAddMutation==-1 || lastRemoveMutation==-1,"unable to add or delete reaction");

    double tmpgendist=gendistance(genotype,gref,this);
    if (tmpgendist>maxgendist) maxgendist=tmpgendist;

   if (!lastMutationType && lastRemoveMutation==-1)
      cout << "- UREACTION ";
    else if (lastMutationType && lastAddMutation==-1)
      cout << "+ UREACTION ";
    else
      !lastMutationType ? cout << "- "<<net->links[lastRemoveMutation].info[0] << "("<<lastRemoveMutation<<") " : cout << "+ "<<net->links[lastAddMutation].info[0] << "("<<lastAddMutation<<") ";
    cout << acount << " " << tmpgendist << " " << maxgendist;
    if (phenotype != oldphe) cout << " [ " << printPhenotype() << " ]";
    cout << endl;
    oldphe = phenotype;
  }

  calcPhenotype();
  cout << "# final: " << acount << " " << gendistance(genotype,gref,this) << " " << maxgendist << " "<< printGrowthRate() <<" [" << printPhenotype()<<"]" << endl;
}

void erandomWalk::run_genpool(const enet& net2,int niter,eintarray& genpool,int genpoolcount,float exthgt)
{
  int i;

  eintarray gref;
  eintarray oldphe;
  int grefcount;

  double maxgendist=0.0;

  calcPhenotype();

  cout << "# Growth with whole network: "<<printGrowthRate()<<endl;
  cout << "# Number of total reactions in whole network: "<<acount<<endl;

  load(net2);
  gref = genotype;
  grefcount = acount;

  calcPhenotype();
  oldphe=phenotype;
  cout << "# Growth only with start network: " << printPhenotype()<<endl;
  cout << "# Number of total reactions in start network: "<<acount<<endl;
  cout << "# Reference Size: "<< 1.0/icount << endl;

  cout << "# changed_reaction   total_reactions  hamming_distance  growth_rates  phenotype" << endl;


  for (i=0; i<niter; ++i){
    mutate_genpool(genpool,genpoolcount,exthgt);

    updatePhenotype();
    if (!isViable()){
      if (print_rejected){
        !lastMutationType ? cout << "#- "<<net->links[lastRemoveMutation].info[0] << "("<<lastRemoveMutation<<") " : cout << "#+ "<<net->links[lastAddMutation].info[0] << "("<<lastAddMutation<<") ";
        cout << endl;
      }
//      cout << acount << " " << gendistance(genotype,gref,this) << " ["<< printPhenotype()<<"]" << endl;
      revert();
      phenotype=oldphe;

//      ldieif(lastAddMutation==-1 || lastRemoveMutation==-1,"unable to add or delete reaction");
      --i; // do not count non-viable mutations
      continue;
    }
//    ldieif(lastAddMutation==-1 || lastRemoveMutation==-1,"unable to add or delete reaction");

    double tmpgendist=gendistance(genotype,gref,this);
    if (tmpgendist>maxgendist) maxgendist=tmpgendist;

    !lastMutationType ? cout << "- "<<net->links[lastRemoveMutation].info[0] << "("<<lastRemoveMutation<<") " : cout << "+ "<<net->links[lastAddMutation].info[0] << "("<<lastAddMutation<<") ";
    cout << acount << " " << tmpgendist << " " << maxgendist;
    if (phenotype != oldphe) cout << " [ " << printPhenotype() << " ]";
    cout << endl;
    oldphe = phenotype;
  }

  calcPhenotype();
  cout << "# final: " << acount << " " << gendistance(genotype,gref,this) << " " << maxgendist << " "<< printGrowthRate() <<" [" << printPhenotype()<<"]" << endl;
}

void erandomWalk::run_away2(const enet& net2,int niter)
{
  int i,r;

  eintarray gref;
  int grefcount;

  calcPhenotype();

  cout << "# Growth with whole network: "<<printGrowthRate()<<endl;
  cout << "# Number of total reactions in whole network: "<<acount<<endl;

  load(net2);
  gref = genotype;
  grefcount = acount;

  calcPhenotype();

  eintarray oldphe;
  oldphe = phenotype;

  cout << "# Growth only with start network: " << printPhenotype()<<endl;
  cout << "# Number of total reactions in start network: "<<acount<<endl;

  cout << "# changed_reaction    growth    total_reactions" << endl;


  for (i=0; i<niter; ++i){
    r=mutate_away2(gref,(double)i/niter);
    if (r==-1) break;

    updatePhenotype();
    if (!isViable()){
      if (print_rejected){
        acount <= count ? cout << "#- "<<net->links[lastRemoveMutation].info[0] << "("<<lastRemoveMutation<<") " : cout << "#+ "<<net->links[lastAddMutation].info[0] << "("<<lastAddMutation<<") ";
        cout << endl;
      }
//      cout << acount << " " << gendistance(genotype,gref,this) << " ["<< printPhenotype()<<"]" << endl;

//      cout << "#" << (net->links[r].active ? "+ " : "- ") << net->links[r].info[0] << "("<<r<<") "<< acount << " " << gendistance(genotype,gref) << " [ "<<printPhenotype() <<" ]"<< endl;

      revert(); phenotype=oldphe;
      --i; // do not count non-viable mutations
      continue;
    }
    acount <= count ? cout << "- "<<net->links[lastRemoveMutation].info[0] << "("<<lastRemoveMutation<<") " : cout << "+ "<<net->links[lastAddMutation].info[0] << "("<<lastAddMutation<<") ";
    cout << acount << " " << gendistance(genotype,gref,this);
 //   cout << (net->links[r].active ? "+ " : "- ") <<net->links[r].info[0] << "("<<r<<") " << acount << " " << gendistance(genotype,gref);
    if (phenotype != oldphe) cout << " [ " << printPhenotype() << " ]";
    cout << endl;
    oldphe=phenotype;
  }

  calcPhenotype();
  cout << "# final: "<<i<<" " << acount << " " << gendistance(genotype,gref,this) << " [ " << printPhenotype() << " ]" << endl;
}

void erandomWalk::run_away(const enet& net2,int niter)
{
  int i,r;

  eintarray gref;
  int grefcount;

  calcPhenotype();

  cout << "# Growth with whole network: "<<printGrowthRate()<<endl;
  cout << "# Number of total reactions in whole network: "<<acount<<endl;

  load(net2);
  gref = genotype;
  grefcount = acount;

  calcPhenotype();

  eintarray oldphe;
  oldphe = phenotype;

  cout << "# Growth only with start network: " << printPhenotype()<<endl;
  cout << "# Number of total reactions in start network: "<<acount<<endl;

  cout << "# changed_reaction    growth    total_reactions" << endl;


  for (i=0; i<niter; ++i){
    r=mutate_away(gref);
    if (r==-1) break;

    updatePhenotype();
    if (!isViable()){
      if (print_rejected){
        acount <= count ? cout << "#- "<<net->links[lastRemoveMutation].info[0] << "("<<lastRemoveMutation<<") " : cout << "#+ "<<net->links[lastAddMutation].info[0] << "("<<lastAddMutation<<") ";
        cout << endl;
      }
//      cout << acount << " " << gendistance(genotype,gref,this) << " ["<< printPhenotype()<<"]" << endl;

//      cout << "#" << (net->links[r].active ? "+ " : "- ") << net->links[r].info[0] << "("<<r<<") "<< acount << " " << gendistance(genotype,gref) << " [ "<<printPhenotype() <<" ]"<< endl;

      revert(); phenotype=oldphe;
      --i; // do not count non-viable mutations
      continue;
    }
    acount <= count ? cout << "- "<<net->links[lastRemoveMutation].info[0] << "("<<lastRemoveMutation<<") " : cout << "+ "<<net->links[lastAddMutation].info[0] << "("<<lastAddMutation<<") ";
    cout << acount << " " << gendistance(genotype,gref,this);
 //   cout << (net->links[r].active ? "+ " : "- ") <<net->links[r].info[0] << "("<<r<<") " << acount << " " << gendistance(genotype,gref);
    if (phenotype != oldphe) cout << " [ " << printPhenotype() << " ]";
    cout << endl;
    oldphe=phenotype;
  }

  calcPhenotype();
  cout << "# final: "<<i<<" " << acount << " " << gendistance(genotype,gref,this) << " [ " << printPhenotype() << " ]" << endl;
}

void erandomWalk::run_toward(enet& net2,enet& net3,int niter)
{
  int i,r,tmpcount;

//  ldie("check code");

  eintarray gref,phenet1,phenet2;
  int grefcount;

  calcPhenotype();

  cout << "# Growth with whole network: "<<printGrowthRate()<<endl;
  cout << "# Number of total reactions in whole network: "<<acount<<endl;
///
	load(net3);
  gref = genotype;
  calcPhenotype();
	phenet1=phenotype;


  load(net2);
  grefcount = acount;
  calcPhenotype();
	phenet2=phenotype;
	
	tmpcount = 0;
	for (i=0; i<phenotype.size(); ++i) {
		if (phenet1[i]==phenet2[i]) tmpcount+=1;
	}
	ldieif(tmpcount==phenotype.size(),"Phenotypes of both networks similar. Try with networks with diff phenotypes");
  viablePhenotype=phenotype;
////

  cout << "# Growth only with start network: " << printPhenotype()<<endl;
  cout << "# Number of total reactions in start network: "<<acount<<endl;

  cout << "# changed_reaction    growth    total_reactions" << endl;


  for (i=0; i<niter; ++i){
//    if (acount*icount-0.5 >= 1.0) { cout << "# reached 1398 links" << endl; break; }// we reached the maximum number of reactions when only removals are possible since Pr=1398/932-0.5 = 1.0

    r=mutate_toward(gref);

    calcPhenotype();
    if (!isViable()){
      revert();
      cout << "#" << (net->links[r].active ? "+ " : "- ") << net->links[r].info[0] << "("<<r<<") "<< acount << " " << gendistance(genotype,gref,this) << printPhenotype() << endl;
      --i; // do not count non-viable mutations
      continue;
    }
    cout << (net->links[r].active ? "+ " : "- ") <<net->links[r].info[0] << "("<<r<<") " << acount << " " << gendistance(genotype,gref,this) << " " << printPhenotype() << endl;

  }

  calcPhenotype();
  cout << "# final: " << acount << " " << gendistance(genotype,gref,this) << " " << printPhenotype() << endl;
}






int getmul2(int a)
{
  int r;
  r=0x01;
  while(a!=0x00){
    r=(r<<1);
    a=(a>>1);
  }
  return(r); 
}


estr pheessential(erandomWalk& rw,earray<eintarray>& cphenotypes,bool show)
{
  eintarray oarr;
  int phecount;
  int i;
  int transport;

  rw.calcPhenotype();
  oarr=rw.phenotype;

  phecount = countPhenotype(rw.phenotype);
  earray<eintarray> phenotypes;

  int inviable=0;
  int viable=0;
  transport=0;

  for (i=1; i<rw.genotype.size(); ++i){
    if (rw.net->links[i].transport && !rw.mutate_transport)
      { ++transport; continue; }
    if (rw.genotype[i]==0)
      continue;
    rw.disable(i);
    rw.updatePhenotypeRemoval();

    if (oarr != rw.phenotype){
      if (countPhenotype(rw.phenotype)!=0){
        ++viable;
        if (phenotypes.find(rw.phenotype) == -1)
          phenotypes.add(rw.phenotype);
        if (cphenotypes.find(rw.phenotype) == -1)
          cphenotypes.add(rw.phenotype);
      }else
        ++inviable;
      rw.phenotype = oarr;
    }
    rw.activate(i);
  }

  estr res;
  res += rw.acount-transport;
  res += " ";
  res += viable;
  res += " ";
  res += (int)phenotypes.size();
  res += " ";
  res += inviable;
  return(res);
}

estr pherobust(erandomWalk& rw,earray<eintarray>& cphenotypes,bool show)
{
  eintarray oarr;
  int phecount;
  int i;

//  cout << "Checking phenotype" << endl;
  rw.calcPhenotype();
  oarr=rw.phenotype;
//  cout << rw.phenotype << endl;

  phecount = countPhenotype(rw.phenotype);

  earray<eintarray> phenotypes;


  eintarray rlist;
  int tc,dc,nv;
  tc=0; dc=0; nv=0;
  for (i=1; i<rw.net->links.size(); ++i){
//    if (!is_connected(rw.net->links[i]) || rw.net->links[i].transport || rw.net->links[i].active) continue;
    if (rw.net->links[i].transport && !rw.mutate_transport || rw.net->links[i].active) continue;
    rlist.add(i);
  }


  int j;
  eintarray plist;
  earray<eintarray> phenotype_mask;
  int plen;
  int level;
  int tmpsize;

  level=1;
  plist.add(0);
  phenotype_mask.add(eintarray());
  for (i=0; i<rw.solvers.size(); ++i)
    phenotype_mask[0].add(1);

  for (j=0; j<rlist.size(); ++j)
    rw.disable(rlist[j]);

  plen=getmul2(rlist.size());
  while(1){
//    cout << " checking block size: "<<plen<<endl;
    
    tmpsize=plist.size();
    for (i=0; i<tmpsize; ++i){
//      cout << plist[i]<<": "<<plen*plist[i]<<" - "<<plen*(plist[i]+1)<<endl;
    
      for (j=plen*plist[i]; j<plen*(plist[i]+1) && j<rlist.size(); ++j)
        rw.activate(rlist[j]);
      rw.updatePhenotypeAddition(phenotype_mask[i]);
      if (oarr != rw.phenotype){
        if (plen!=1){
          plist.add(plist[i]*2);
          plist.add(plist[i]*2+1);
          phenotype_mask.add(rw.phenotype);
          phenotype_mask.add(rw.phenotype);
//          cout << plist[i] <<" ";
        }else{
          plist.add(plist[i]);
          phenotype_mask.add(rw.phenotype);
          if (phenotypes.find(rw.phenotype) == -1)
            phenotypes.add(rw.phenotype);
          if (cphenotypes.find(rw.phenotype) == -1)
            cphenotypes.add(rw.phenotype);
//          cout << arr << endl;
        }
      }
      rw.phenotype=oarr;
//      cout << endl;
      for (j=plen*plist[i]; j<plen*(plist[i]+1) && j<rlist.size(); ++j)
        rw.disable(rlist[j]);
    }
    for (i=0; i<tmpsize; ++i){
      plist.erase(0);
      phenotype_mask.erase(0);
    }

    if (tmpsize==0 || plen==1) break;
    plen = plen/2;
  }

  estr res;

  if (show){
    for (i=0; i<plist.size(); ++i){
      cout << rw.net->links[rlist[plist[i]]].info[0] << ": " << intarr2str(phenotype_mask[i]) << endl;
    }
  }

  res += (int)rlist.size();
  res += " ";
  res += (int)plist.size();
  res += " ";
  res += (int)phenotypes.size();

  return(res);
}











estr pheessential(erandomWalk& rw,earrayof<int,eintarray>& cphenotypes,bool show)
{
  eintarray oarr,ogen;
  int phecount;
  int i;
  int transport;

  rw.calcPhenotype();
  oarr=rw.phenotype;
  ogen=rw.genotype;

  phecount = countPhenotype(rw.phenotype);
  earray<eintarray> phenotypes;
  eintarray reactions;
  eintarray ireactions;

  // for each of the reactions in each of the environments register the active reactions
  // the inactive reactions are more likely to be non-essential, and do not need to be 
  // tried one by one
  eintarray agen;
  for (i=0; i<rw.net->links.size(); ++i)
    agen.add(0);

  int j;
  for (j=0; j<rw.solvers.size(); ++j){
    if (rw.phenotype[j]==1){
      for (i=0; i<rw.net->links.size(); ++i){
        if (rw.genotype[i]==1 && fabs(rw.solvers.at(j).x[i]) >= 1.0e-8)
          agen[i]=1;
      }
//      break;
    }
  }

  int c,t;
  c=0;t=0;
  for (i=0; i<rw.net->links.size(); ++i){
    if (rw.genotype[i]==1){
      ++t;
      if (agen[i]==1) ++c;
    }
  }

//  cout << "Total reactions: "<<t<<" | Inactive: "<<t-c<<endl;
  for (i=0; i<rw.net->links.size(); ++i){
    if (rw.genotype[i]==1 && agen[i]==0)
      rw.disable(i);
  }
  rw.updatePhenotypeRemoval();

  lerrorif(oarr != rw.phenotype,"some inactive reactions appear to be essential for phenotype!: "+estr(countPhenotype(oarr))+" "+estr(countPhenotype(rw.phenotype)));
//   cout << "Everything is fine!!!" << endl;
  for (i=0; i<rw.net->links.size(); ++i){
    if (ogen[i]==1 && agen[i]==0)
      rw.activate(i);
  }

  if (oarr!=rw.phenotype){
    // test all reactions
    for (i=0; i<rw.net->links.size(); ++i){
      if (rw.genotype[i]==1)
        agen[i]=1;
    }
  }

  



  int inviable=0;
  int viable=0;
  transport=0;

  for (i=1; i<rw.genotype.size(); ++i){
    if (rw.net->links[i].transport && !rw.mutate_transport && rw.genotype[i]==1)
      ++transport;
  }

  for (i=1; i<rw.genotype.size(); ++i){
    if (rw.net->links[i].transport && !rw.mutate_transport || rw.genotype[i]==0 || agen[i]==0)
      continue;
    rw.disable(i);
    rw.updatePhenotypeRemoval();

    if (oarr != rw.phenotype){
      if (countPhenotype(rw.phenotype)!=0){
        ++viable;
        if (phenotypes.find(rw.phenotype) == -1){
          phenotypes.add(rw.phenotype);
          reactions.add(i);
        }
        if (cphenotypes.findkey(rw.phenotype) == -1)
          cphenotypes.add(rw.phenotype,1);
        else
          ++cphenotypes[rw.phenotype];
      }else{
        ++inviable;
        ireactions.add(i);
      }
      rw.phenotype = oarr;
    }
    rw.activate(i);
  }

  if (show){
    cout << "# reactions: phenotypes growing on less environments" << endl;
    for (i=0; i<reactions.size(); ++i){
      cout << rw.net->links[reactions[i]].info[0] << ": " << intarr2str(phenotypes[i]) << endl;
    }
    cout << "# reactions: deleterious" << endl;
    for (i=0; i<ireactions.size(); ++i){
      cout << rw.net->links[ireactions[i]].info[0] << endl;
    }
  }

  estr res;
  res += rw.acount-transport;
  res += " ";
  res += viable;
  res += " ";
  res += (int)phenotypes.size();
  res += " ";
  res += inviable;
  return(res);
}


estr pherobust(erandomWalk& rw,earrayof<int,eintarray>& cphenotypes,bool show)
{
  eintarray oarr;
  int phecount;
  int i;

//  cout << "Checking phenotype" << endl;
  rw.calcPhenotype();
  oarr=rw.phenotype;
//  cout << rw.phenotype << endl;

  phecount = countPhenotype(rw.phenotype);

  earray<eintarray> phenotypes;


  eintarray rlist;
  int tc,dc,nv;
  tc=0; dc=0; nv=0;
  for (i=1; i<rw.net->links.size(); ++i){
//    if (!is_connected(rw.net->links[i]) || rw.net->links[i].transport || rw.net->links[i].active) continue;
    if (rw.net->links[i].transport && !rw.mutate_transport || rw.net->links[i].active) continue;
    rlist.add(i);
  }

  int j;
  eintarray plist;
  earray<eintarray> phenotype_mask;
  int plen;
  int level;
  int tmpsize;

  level=1;
  plist.add(0);
  phenotype_mask.add(eintarray());
  for (i=0; i<rw.solvers.size(); ++i)
    phenotype_mask[0].add(1);

  for (j=0; j<rlist.size(); ++j)
    rw.disable(rlist[j]);

  plen=getmul2(rlist.size());
  while(1){
//    cout << " checking block size: "<<plen<<endl;
    
    tmpsize=plist.size();
    for (i=0; i<tmpsize; ++i){
//      cout << plist[i]<<": "<<plen*plist[i]<<" - "<<plen*(plist[i]+1)<<endl;
    
      for (j=plen*plist[i]; j<plen*(plist[i]+1) && j<rlist.size(); ++j)
        rw.activate(rlist[j]);
      rw.updatePhenotypeAddition(phenotype_mask[i]);
      if (oarr != rw.phenotype){
        if (plen!=1){
          plist.add(plist[i]*2);
          plist.add(plist[i]*2+1);
          phenotype_mask.add(rw.phenotype);
          phenotype_mask.add(rw.phenotype);
//          cout << plist[i] <<" ";
        }else{
          plist.add(plist[i]);
          phenotype_mask.add(rw.phenotype);
          if (phenotypes.find(rw.phenotype) == -1)
            phenotypes.add(rw.phenotype);
          if (cphenotypes.findkey(rw.phenotype) == -1)
            cphenotypes.add(rw.phenotype,1);
          else
            ++cphenotypes[rw.phenotype];
//          cout << arr << endl;
        }
      }
      rw.phenotype=oarr;
//      cout << endl;
      for (j=plen*plist[i]; j<plen*(plist[i]+1) && j<rlist.size(); ++j)
        rw.disable(rlist[j]);
    }
    for (i=0; i<tmpsize; ++i){
      plist.erase(0);
      phenotype_mask.erase(0);
    }

    if (tmpsize==0 || plen==1) break;
    plen = plen/2;
  }

  if (show){
    cout << "# reactions: phenotypes growing on more environments" << endl;
    for (i=0; i<plist.size(); ++i){
      cout << rw.net->links[rlist[plist[i]]].info[0] << ": " << intarr2str(phenotype_mask[i]) << endl;
    }
  }

  estr res;

  res += (int)rlist.size();
  res += " ";
  res += (int)plist.size();
  res += " ";
  res += (int)phenotypes.size();

  return(res);
}


void pheessential2(erandomWalk& rw,earrayof<int,eintarray>& cphenotypes,earrayof<eintarray,estr>& rreactions,estrarray& dreactions)
{
  eintarray oarr,ogen;
  int phecount;
  int i;
  int transport;

  rw.calcPhenotype();
  oarr=rw.phenotype;
  ogen=rw.genotype;

  phecount = countPhenotype(rw.phenotype);
  eintarray reactions;
  eintarray ireactions;

  // for each of the reactions in each of the environments register the active reactions
  // the inactive reactions are more likely to be non-essential, and do not need to be 
  // tried one by one
  eintarray agen;
  for (i=0; i<rw.net->links.size(); ++i)
    agen.add(0);

  int j;
  for (j=0; j<rw.solvers.size(); ++j){
    if (rw.phenotype[j]==1){
      for (i=0; i<rw.net->links.size(); ++i){
        if (rw.genotype[i]==1 && fabs(rw.solvers.at(j).x[i]) >= 1.0e-8)
          agen[i]=1;
      }
//      break;
    }
  }

  int c,t;
  c=0;t=0;
  for (i=0; i<rw.net->links.size(); ++i){
    if (rw.genotype[i]==1){
      ++t;
      if (agen[i]==1) ++c;
    }
  }

//  cout << "Total reactions: "<<t<<" | Inactive: "<<t-c<<endl;
  for (i=0; i<rw.net->links.size(); ++i){
    if (rw.genotype[i]==1 && agen[i]==0)
      rw.disable(i);
  }
  rw.updatePhenotypeRemoval();

  lerrorif(oarr != rw.phenotype,"some inactive reactions appear to be essential for phenotype!: "+estr(countPhenotype(oarr))+" "+estr(countPhenotype(rw.phenotype)));
//   cout << "Everything is fine!!!" << endl;
  for (i=0; i<rw.net->links.size(); ++i){
    if (ogen[i]==1 && agen[i]==0)
      rw.activate(i);
  }

  if (oarr!=rw.phenotype){
    // test all reactions
    for (i=0; i<rw.net->links.size(); ++i){
      if (rw.genotype[i]==1)
        agen[i]=1;
    }
  }

  int inviable=0;
  int viable=0;
  transport=0;

  for (i=1; i<rw.genotype.size(); ++i){
    if (rw.net->links[i].transport && !rw.mutate_transport)
      ++transport;
  }

  for (i=1; i<rw.genotype.size(); ++i){
    if (rw.net->links[i].transport && !rw.mutate_transport || rw.genotype[i]==0 || agen[i]==0)
      continue;
    rw.disable(i);
    cout << "# disabling reaction: " << rw.net->links[i].info[0] << endl;
    rw.updatePhenotypeRemoval();

    if (oarr != rw.phenotype){
      if (countPhenotype(rw.phenotype)!=0){
        ++viable;
        rreactions.add(rw.net->links[i].info[0],rw.phenotype);
        if (cphenotypes.findkey(rw.phenotype) == -1)
          cphenotypes.add(rw.phenotype,1);
        else
          ++cphenotypes[rw.phenotype];
      }else{
        ++inviable;
        ireactions.add(i);
      }
      rw.phenotype = oarr;
    }
    rw.activate(i);
  }

// reactions: deleterious
  for (i=0; i<ireactions.size(); ++i)
    dreactions.add(rw.net->links[ireactions[i]].info[0]);
}

void idess(erandomWalk& rw, eintarray& essnet, int& numess) {

	int i;
	numess=0;
	for (i=1; i<rw.genotype.size(); ++i){
		if (rw.net->links[i].transport && !rw.mutate_transport || rw.genotype[i]==0) 
      continue;
		rw.disable(i);
		rw.calcPhenotype();
//      rw.updatePhenotypeRemoval();
		if (!rw.isViable()) {
			essnet[i] = 1;
//				cout << "# Net 2 essential: " << rw.net->links[i].info[0] << endl;
			++numess;
		}
		rw.activate(i);
		rw.calcPhenotype();
	}
}

//identify essential reactions but needs an intarray indicating blocked reactions
void idess2(erandomWalk& rw, const eintarray& bluni, eintarray& essnet, int& numess) { 

	int i;
	for (i=1; i<rw.genotype.size(); ++i){
		if (rw.net->links[i].transport && !rw.mutate_transport || rw.genotype[i]==0 || bluni[i]==1) 
      continue;
		rw.disable(i);
		rw.calcPhenotype();
//      rw.updatePhenotypeRemoval();
		if (!rw.isViable()) {
			essnet[i] = 1;
//				cout << "# Net 2 essential: " << rw.net->links[i].info[0] << endl;
			++numess;
		}
		rw.activate(i);
		rw.calcPhenotype();
	}
}


#include "edrawlink.h"
#include "edrawnet.h"

#include <edlib-2/ecolor.h>

#include <eutils/ernd.h>

edrawlink::~edrawlink()
{
  int i;
  for (i=0; i<srcnodes.size(); ++i)
    --srcnodes[i]->linkcount;
  for (i=0; i<dstnodes.size(); ++i)
    --dstnodes[i]->linkcount;
  --src->linkcount;
  --dst->linkcount;
  cout << "destroying edrawlink!" << endl;
}

evector2 avgpos(const earray<edrawnode*>& nodes,const evector2& pos)
{
  evector2 res;
  int i;

  res = pos;
  for (i=0; i<nodes.size(); ++i)
    res += nodes[i]->pos;
  return(res/(i+1)+evector2(ernd.uniform()-0.5,ernd.uniform()-0.5)*0.02);
}

bool edrawlink::inLink(edrawnode* node)
{
  if (src == node || dst == node) return(true);

  int i;
  for (i=0; i<srcnodes.size(); ++i)
    if (srcnodes[i] == node) return(true);
  for (i=0; i<dstnodes.size(); ++i)
    if (dstnodes[i] == node) return(true);
  return(false);
}


unsigned int getRainbowColor(double v)
{
  v=1.0-v;
  float r,g,b;

  r=0.0;g=0.0;b=0.0;
  if (v<0.5){
    v=2.0*v;
    r=1.0-v;
    g=v;
  }else{
    v=(v-0.5)*2.0;
    g=1.0-v;
    b=v;
  }
  r=r*255;
  g=g*255;
  b=b*255;
  return( (unsigned int)(r)*0x010000 | (unsigned int)(g)*0x000100 | (unsigned int)(b)*0x01 );
}


/*
unsigned int getRainbowColor(double v)
{
  float r,g,b;

  r=0.0;g=0.0;b=0.0;
  if (v<0.5){
    v=2.0*v;
    r=v;
    g=1.0-v;
  }else{
    v=(v-0.5)*2.0;
    g=v;
    b=1.0-v;
  }
  r=r*255;
  g=g*255;
  b=b*255;
  return( (unsigned int)(r)*0x010000 | (unsigned int)(g)*0x000100 | (unsigned int)(b)*0x01 );
}
*/

edrawlink::edrawlink(edrawnet* _drawnet,elink& _link,enode* rootnode,const evector2& pos): drawnet(_drawnet),link(&_link),src(0x00),dst(0x00), selected(false), color(-1),highlite(false)
{
  int i;
  earrayof<enode*,int> srcrank;
  earrayof<enode*,int> dstrank;

  if (link->info["color"]=="blue")
    color=ecRed;
  else if (link->info["color"]=="green")
    color=ecLightGray;
  else if (link->info["color"]=="red")
    color=ecLightRed;
  else if (drawnet->colorinfo.findkey(link->info[0])!=-1){
    cout << "_drawnet->colorinfo: "<<drawnet->colorinfo[link->info[0]]<<endl;
    color=getRainbowColor(drawnet->colorinfo[link->info[0]].d());
  }

//  cout << "link: "<<link->info[0]<<"  colorinfo: "<<drawnet->colorinfo.findkey(link->info[0])<<endl;


  int k;
  for (i=0; i<link->src.size(); ++i){
//    if (drawnet->nodeinfo[link->src[i].node]

    k=table_find(drawnet->nodeinfo,"entry",link->src[i].node->id);
    if (k!=-1 && drawnet->nodeinfo["formula"][k].get<estr>().find("S")!=-1 || k==-1)
      srcnodes.add(drawnet->getnode(link->src[i].node,pos));
  }
/*
    if (link->src[i].node == rootnode) srcnodes.add(drawnet->getnode(rootnode,pos));
    srcrank.add_keysorted(link->src[i].node->links.size(),link->src[i].node);
  }
  if (srcrank.size() && srcrank.values(0) != rootnode){
    srcnodes.add(drawnet->getnode(srcrank.values(0),pos));
  }
*/
  
  for (i=0; i<link->dst.size(); ++i){
    k=table_find(drawnet->nodeinfo,"entry",link->dst[i].node->id);
    if (k!=-1 && drawnet->nodeinfo["formula"][k].get<estr>().find("S")!=-1 || k==-1)
      dstnodes.add(drawnet->getnode(link->dst[i].node,pos));
  }

/*
    if (link->dst[i].node == rootnode) dstnodes.add(drawnet->getnode(rootnode,pos));
    dstrank.add_keysorted(link->dst[i].node->links.size(),link->dst[i].node);
  }

  if (dstrank.size() && dstrank.values(0) != rootnode)
    dstnodes.add(drawnet->getnode(dstrank.values(0),pos));


  if (srcnodes.size() && dstnodes.size() && drawnet->areLinked(srcnodes[0],dstnodes[0])){
    if (srcnodes[0]->node == rootnode){
      if (dstrank.size()>1){
        dstnodes.erase(0);
        dstnodes.add(drawnet->getnode(dstrank.values(1),pos));
      }
    }else if (dstnodes[0]->node == rootnode){
      if (srcrank.size()>1){
        srcnodes.erase(0);
        srcnodes.add(drawnet->getnode(srcrank.values(1),pos));
      }
    }else if (link->info.findkey("FLUX")!=-1){
      if (link->info["FLUX"].f() > 0.0){
 
      }else{

      }
    }
  }
*/


  for (i=0; i<srcnodes.size(); ++i)
    ++srcnodes[i]->linkcount;

  if (srcnodes.size()>1 || !srcnodes.size()){
    src = new edrawnode(drawnet);
    ++src->linkcount;
    src->pos = avgpos(srcnodes,pos);
    src->pos2 = src->pos;
    drawnet->nodes.addref(drawnet->nodes.size(),src);
  }else{
    src=srcnodes[0]; srcnodes.clear();
  }

  for (i=0; i<dstnodes.size(); ++i)
    ++dstnodes[i]->linkcount;

  if (dstnodes.size()>1 || !dstnodes.size()){
    dst = new edrawnode(drawnet);
    ++dst->linkcount;
    dst->pos = avgpos(dstnodes,pos);
    dst->pos2=dst->pos;
    drawnet->nodes.addref(drawnet->nodes.size(),dst);
  }else{
    dst=dstnodes[0]; dstnodes.clear();
  }
}

void drawArrow(edrawnet* drawnet,evector2 p1,evector2 p2,bool directed,float flux,int srcmet,int dstmet)
{
  evector2 d,d1,d2;
  float len;
  d=p2-p1;
  len=d.len();
  d=d/len;
  d1=d.rot(M_PI/16.0)*0.02;
  d2=d.rot(-M_PI/16.0)*0.02;

  if (fabs(flux) > 1.0e-8){
    drawnet->setLineWidth(1.0);
    flux=len/2.0*flux*20.0;
    if (flux > 0.5*len) flux=0.5*len;
    if (flux < -0.5*len) flux=-0.5*len;
    drawnet->moveTo(p1+(len/2.0 - flux/2.0)*d + d.perp()*0.01);
    drawnet->lineTo(p1+(len/2.0 + flux/2.0)*d + d.perp()*0.01);

    if (flux > 0.0){
      drawnet->moveTo(p1+(len/2.0 + flux/2.0)*d + d.perp()*0.01-d1*0.3);
      drawnet->lineTo(p1+(len/2.0 + flux/2.0)*d + d.perp()*0.01);
      drawnet->lineTo(p1+(len/2.0 + flux/2.0)*d + d.perp()*0.01-d2*0.3);
    }else{
      drawnet->moveTo(p1+(len/2.0 + flux/2.0)*d + d.perp()*0.01+d1*0.3);
      drawnet->lineTo(p1+(len/2.0 + flux/2.0)*d + d.perp()*0.01);
      drawnet->lineTo(p1+(len/2.0 + flux/2.0)*d + d.perp()*0.01+d2*0.3);
    }
  }

  if (!srcmet)
    p1+=d*0.01;
  if (!dstmet)
    p2-=d*0.01;

  drawnet->setLineWidth(3.0);
  if (!directed){
    drawnet->moveTo(p1+d1*0.5);
    drawnet->lineTo(p1);
    drawnet->lineTo(p1+d2*0.5);
  }
  drawnet->moveTo(p2-d1);
  drawnet->lineTo(p2);
  drawnet->lineTo(p2-d2);

  drawnet->moveTo(p1);
  drawnet->lineTo(p2);
}

void edrawlink::draw()
{
  int i;
  int col;

  if (selected)
//    col = 0xFF6666;
    col = ecLightYellow;
  else if (highlite)
    col = ecLightBlue;
  else if (color!=-1)
    col = color;
  else if (link->irreversible)
    col = 0x99FF99;
  else
    col = 0x9999FF;

  drawnet->setColor(col);
  drawnet->setLineWidth(3.0);

  float flux=0.0;
  if (link->info.findkey("FLUX")!=-1)
    flux = link->info["FLUX"].f();

  drawArrow(drawnet,src->pos-drawnet->vpoint,dst->pos-drawnet->vpoint,link->irreversible,flux,srcnodes.size(),dstnodes.size());

  drawnet->setColor(dimColor(col,10));

  evector2 d;
  for (i=0; i<srcnodes.size(); ++i){
    d=(srcnodes[i]->pos-src->pos).unit();
    drawnet->moveTo(src->pos-drawnet->vpoint);
    drawnet->lineTo(srcnodes[i]->pos-drawnet->vpoint-d*0.01);
  }

  for (i=0; i<dstnodes.size(); ++i){
    d=(dstnodes[i]->pos-dst->pos).unit();
    drawnet->moveTo(dst->pos-drawnet->vpoint);
    drawnet->lineTo(dstnodes[i]->pos-drawnet->vpoint-d*0.01);
  }
}

const double MINDIST=0.1;

void applyForceCoil(edrawnet* drawnet,edrawnode* node1,edrawnode* node2,float coilfactor)
{
  evector2 acc;
  evector2 dir;

  float dist;
  float idist;
  float idist2;

  dir = node1->pos - node2->pos;
  dist = dir.len();
  if (dist==0.0) return;

  idist = 1.0/(dist+0.01);
  idist2= 2.0/(dist+0.3);
  dir = dir*idist;

  if (dist < MINDIST)
    acc = (drawnet->forcefactor*coilfactor*dist*(dist*2.0+1.0)*20.0)/MINDIST*dir;
  else
    acc = (drawnet->forcefactor*coilfactor*(dist*2.0+1.0)*20.0)*dir;
    

/*
  if (dist < drawnet->frangeAttraction)      
    acc += drawnet->ffactorAttraction*drawnet->forcefactor*idist2*dir;
  if (dist < drawnet->frangeRepulsion)
    acc -= 0.05*drawnet->ffactorRepulsion*idist*dir;
*/

  node2->acc += acc;
  node1->acc -= acc;
}

void applyForceRepulsion(edrawnet* drawnet,edrawnode* node1,edrawnode* node2,float repulsionfactor)
{
  evector2 acc;
  evector2 dir;
  float dist;
  float idist;
  float idist2;

  dir = node1->pos - node2->pos;
  dist = sqrt(dir*dir);
  if (dist==0.0) return;
  idist2= 1.0/(dist+0.3);
  dir = dir/dist;
  acc = drawnet->forcefactor*repulsionfactor*idist2*dir;
  node1->acc += acc;
  node2->acc -= acc;
}

void edrawlink::update()
{
  int i;

  for (i=0; i<srcnodes.size(); ++i){
    applyForceCoil(drawnet,src,srcnodes[i],drawnet->ffactorTLink);
    applyForceRepulsion(drawnet,dst,srcnodes[i],drawnet->ffactorSDRepulsion);
  }

  applyForceCoil(drawnet,src,dst,drawnet->ffactorMLink);
  applyForceRepulsion(drawnet,src,dst,drawnet->ffactorSDRepulsion);

  for (i=0; i<dstnodes.size(); ++i){
    applyForceCoil(drawnet,dst,dstnodes[i],drawnet->ffactorTLink);
    applyForceRepulsion(drawnet,src,dstnodes[i],drawnet->ffactorSDRepulsion);
  }

  int j;
  for (i=0; i<srcnodes.size(); ++i){
    for (j=0; j<dstnodes.size(); ++j)
      applyForceRepulsion(drawnet,srcnodes[i],dstnodes[j],drawnet->ffactorSDRepulsion);
  }
  for (i=0; i<srcnodes.size(); ++i)
    applyForceRepulsion(drawnet,src,srcnodes[i],drawnet->ffactorSDRepulsion);
  for (i=0; i<dstnodes.size(); ++i)
    applyForceRepulsion(drawnet,dst,dstnodes[i],drawnet->ffactorSDRepulsion);
}




int getColor(double v)
{
  int tmpi = 255*v;
//  return(((int)(160 * v)*0x010101+0x404040)&0xFFFFFF);
  return((tmpi*0x010000 + (255-tmpi)*0x01)&0xFFFFFF);
}

edrawlink::edrawlink(edrawnet* _drawnet,elink& _link,const estr& rpairs,const evector2& pos): drawnet(_drawnet),link(&_link),src(0x00),dst(0x00), selected(false), color(-1),highlite(false)
{
  int i;
  earrayof<enode*,int> srcrank;
  earrayof<enode*,int> dstrank;

/*
  if (link->info["color"]=="blue")
    color=ecRed;
  else if (link->info["color"]=="green")
    color=ecLightGray;
  else if (link->info["color"]=="red")
    color=ecLightRed;
  else
*/
  if (drawnet->colorinfo.findkey(link->info[0])!=-1){
//    cout << "_drawnet->colorinfo: "<<drawnet->colorinfo[link->info[0]]<<endl;
    color=getRainbowColor(drawnet->colorinfo[link->info[0]].d());
//    color=getColor(drawnet->colorinfo[link->info[0]].d());
  }else
    color=ecGray;

  cout << "link: "<<link->info[0]<<"  colorinfo: "<<color<<endl;

  estrarray arrpairs(rpairs);
  estr tmpstr;

  // not an elegant solution, but does the job
//  for (i=0; i<arrpairs.size(); ++i){
//    if (arrpairs.values(i) == "main")
//      tmpstr += arrpairs.keys(i);
//  }
  int k;

  for (i=0; i<link->src.size(); ++i){
    k=table_find(drawnet->nodeinfo,"entry",link->src[i].node->id);
    if ((!tmpstr.len() || tmpstr.find(link->src[i].node->id)!=-1) && (k!=-1 && drawnet->nodeinfo["formula"][k].get<estr>().find("S")!=-1 || k==-1) )
      srcnodes.add(drawnet->getnode(link->src[i].node,pos));
  }
 
  for (i=0; i<link->dst.size(); ++i){
    k=table_find(drawnet->nodeinfo,"entry",link->dst[i].node->id);
    if ((!tmpstr.len() || tmpstr.find(link->dst[i].node->id)!=-1) && (k!=-1 && drawnet->nodeinfo["formula"][k].get<estr>().find("S")!=-1 || k==-1) )
      dstnodes.add(drawnet->getnode(link->dst[i].node,pos));
  }

  for (i=0; i<srcnodes.size(); ++i)
    ++srcnodes[i]->linkcount;

  if (srcnodes.size()>1 || !srcnodes.size()){
    src = new edrawnode(drawnet);
    ++src->linkcount;
    src->pos = avgpos(srcnodes,pos);
    src->pos2 = src->pos;
    drawnet->nodes.addref(drawnet->nodes.size(),src);
  }else{
    src=srcnodes[0]; srcnodes.clear();
  }

  for (i=0; i<dstnodes.size(); ++i)
    ++dstnodes[i]->linkcount;

  if (dstnodes.size()>1 || !dstnodes.size()){
    dst = new edrawnode(drawnet);
    ++dst->linkcount;
    dst->pos = avgpos(dstnodes,pos);
    dst->pos2=dst->pos;
    drawnet->nodes.addref(drawnet->nodes.size(),dst);
  }else{
    dst=dstnodes[0]; dstnodes.clear();
  }
}


#include "enet.h"
#include "esolver_clp.h"

#include <eutils/emain.h>


enet net;
esolver_clp solver;


int main()
{
  ldieif (argvc<3,"syntax: ./metnet-clp <file.net> <env>");  

  net.load(argv[1]);
  net.correct_malformed();

  int reactions;
  reactions=net.links.size();

  int nodes;
  nodes=net.nodes.size();

  int i;
  for (i=0; i<net.links[0].src.size(); ++i)
    net.addlink(net.links[0].src[i].node->id+" --> "+net.links[0].src[i].node->id+"_out");

  cout << "loading network" << endl;
  solver.parse(net);
  cout << "loading fluxbounds" << endl;
  solver.load_fluxbounds(argv[2]);
  cout << solver.solve() << endl;

  cout << "checking free biomass production" << endl;

  solver.setobjective2(0,0.0);
  int j;
  double obj;
  for (i=reactions; i<net.links.size(); ++i){
    if (net.links[0].src[i-reactions].node->id=="C00001") continue;
    solver.setobjective2(i,1.0);
    obj=solver.solve();
    cout << obj << " " << net.links[0].src[i-reactions].node->id << " " << solver.x[i] << endl;
  }
  cout << solver.solve() << endl;
  for (i=reactions; i<net.links.size(); ++i)
    cout << net.links[0].src[i-reactions].node->id << " " << solver.x[i] << endl;
  return(0);
}

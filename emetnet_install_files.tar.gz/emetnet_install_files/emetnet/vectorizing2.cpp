#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/eheap.h>
#include <algorithm>
#include <eutils/ernd.h>

int emain()
{ ldieif(argvc<1,"syntax: ./vectorizing2  ");
  //generate total pop array
  int totalsize=30;
  int selected=10;
  //epregister(totalsize);
  int i;
  eintarray pop;
  for (i=0; i<totalsize; ++i) {
      pop.add(i);
  }
  //cout << "pop created" << endl;
  int tmp1; 
  for (i=(totalsize-1); i>=0; --i) {
    int r = (int)(ernd.uniform()*i);
    tmp1 = pop[r];
    pop[r] = pop[i];
    pop[i]=tmp1;
  }

  //eintarray sorted1=sort(pop); 
  estr intstr1 = intarr2str2(pop);	 
  cout << intstr1<<endl;


  eintarray pop2;
  for (int j=0;j<selected;j++){
      int x=pop[j];
      pop2.add(x);
  }
  eintarray sorted2=sort(pop2);
  eintarray final2;
  for (int j=0;j<selected;j++){
      int y=sorted2[j];
      final2.add(pop2[y]);
  }
  //estr intstr2 = intarr2str2(pop2);	 
  //cout << intstr2<<endl;
  estr intstr2 = intarr2str2(final2);	 
  cout << intstr2<<endl;
  return(0);
}





  //efile f;
  //estrarray parts;
  //eintarray tmpr;
  //eparseArgs(argvc,argv);
  //estr str;
  //estr astar=argv[1];
  //f.open(argv[1],"r");
  //while (f.readln(str)) {	
        //parts=str.explode(" ");
        //int tmp = parts[0].i();
        //tmpr.add(tmp);	
  //}
  //eintarray tmpr2=sort(tmpr);


	//estr test = astar+"_vecing";		// concatanate string "sizestr", int length and .dat and assign to estr test
	//estr intstr = intarr2str2(tmpr2);						// convert int array tmparr to a string called intstr  
  //cout << intstr<<endl;
  //estrarray intstr2=intstr.explode(" ");
  //estr printed;
  //efile files;
  //files.open(test,"a");
  //for (int j=0; j<intstr2.size(); ++j) {
    //  int intprinted=intstr2[j].i();
    //   printed=intarr2str2(intprinted);
	  //  files.write(printed+"\n");
  //}
  //files.write(intstr+"\n");
	//files.close();

 






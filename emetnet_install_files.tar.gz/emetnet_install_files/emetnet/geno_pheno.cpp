#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
#include <vector>
using std::vector;
int size=0;

int emain() {
ldieif(argvc<3,"syntax: ./geno_pheno <inputfilename.dat> <outputfilename.dat> -size <S>");
// Arguments
estr filename=argv[1];
estr outname=argv[2];

epregister(size);
/////////////////////////////////////////////////////////////////////////////////
int S=size;

// Reading the files and filling the arrays
estr str;
estrarray parts;
efile f;
int intcount=0;
unsigned long genbits=0x00ul; // start with a 64bit value representing the network with all bits set to zero

int mat[9989][S];
for (int i=0;i<9989;i++){
     for (int j=0;j<9989;j++){
          mat[i][j]=0;
     }
}
f.open(argv[1],"r");
while (f.readln(str)) {
      parts=str.explode(" ");
      genbits=0x00ul; 
      for (int m=0; m<parts.size(); ++m){mat[intcount][m]=parts[m].i();}
      intcount++;
}
f.close();

efile outfile;
outfile.open(outname,"a");

for (int i=0; i<9989; i++){
    for (int j=0; j<9989; j++){
         int distan=0;
         for (int k=0;k<S;k++){if (mat[i][k]!=mat[j][k]){distan++;}}
         double distane= (double) distan;
         estr distane_str=distane;
         outfile.write(distane_str+" ");
    }
    outfile.write("\n");
}
outfile.close();

}

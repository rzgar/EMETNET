#include "enet.h"
#include "erandomwalk.h"

#include <eutils/emain.h>
#include <eutils/ernd.h>


bool isViable(eintarray phe,eintarray mphe)
{
  int i;
  for (i=0; i<phe.size(); ++i)
    if (mphe[i]==1 && phe[i]==0) return(false);
  return(true);
}

void phemerge(eintarray phe,earrayof<int,eintarray>& pheadd,earrayof<int,eintarray> &phedel,earrayof<int,eintarray>& phelist)
{
  int i,j;

  int ccount,tcount;
  ccount=0;
  tcount=0;

  for (j=0; j<phelist.size(); ++j){
    if (isViable(phelist.keys(j),phe)){
      i=pheadd.findkey(phelist.keys(j));
      if (i==-1)
        pheadd.add(phelist.keys(j),phelist.values(j));
      else
        pheadd.values(i)+=phelist.values(j);
    }else{
      i=phedel.findkey(phelist.keys(j));
      if (i==-1)
        phedel.add(phelist.keys(j),phelist.values(j));
      else
        phedel.values(i)+=phelist.values(j);
    }
  }
}

void addGenotype(eintarray& genpool,int& genpoolcount,const eintarray& gen)
{
  int i;
  for (i=1; i<gen.size(); ++i){
    genpool[i]+=gen[i];
    genpoolcount+=gen[i];
  }
}
void resetCount(eintarray& genpool,int& genpoolcount)
{
  int i;
  for (i=0; i<genpool.size(); ++i)
    genpool[i]=0;
  genpoolcount=0;
}

int countGenes(eintarray& genpool)
{
  int count=0;
  int i;
  for (i=1; i<genpool.size(); ++i)
    if (genpool[i]!=0) ++count;
  return(count);
}

inline int get2DRand(int i,int w,int s)
{
  int x=i%w;
  int y=i/w;
  switch ((int)floor(4*ernd.uniform())){
    case 0: return(y*w+(x+1)%w);
    case 1: return(y*w+(x-1+w)%w);
    case 2: return(((y+1)%w)*w+x);
    case 3: return(((y-1+w)%w)*w+x);
  }
  ldie("not supposed to happen");
  return(-1);
}

int emain()
{
  ldieif (argvc<4,"syntax: ./metnet-genphedist <file.net> <starter.net> <env.flx env2.flx ...>"); 

  estr outnet="";
  estr solver="cplex";
  int strict=0;
  int mstep=50;
  int dstep=100;
  int popsize=25*25;
  int w=25;
  int iter=20000;
  int check_gendist=1;
  int check_phenotypes=0;
  int internal_secretion=0;
  double mutrate=0.01;
  float  exthgt=0.1;
  int varsize=0;

  int periphery_only=0;
  int mutate_transport=0;

  epregister(outnet);
  epregister(check_phenotypes);
  epregister(check_gendist);
  epregister(solver);
  epregister(strict);
  epregister(mstep);
  epregister(dstep);
  epregister(popsize);
  epregister(iter);
  epregister(mutrate);
  epregister(exthgt);
  epregister(varsize);

  epregister(periphery_only);

  epregister(mutate_transport);
  epregister(internal_secretion);

  eparseArgs(argvc,argv);



  enet net;
  net.load(argv[1]); 
  net.correct_malformed();

  enet net2;
  net2.load(argv[2]);

  erandomWalk rw(net,solver,strict);
  rw.periphery_only=periphery_only;
  rw.mutate_transport=mutate_transport;
  rw.internal_secretion=internal_secretion;

  cout << "# using solver: "<<solver<<endl;
  cout << "# strictViable: "<<strict<<endl;
  cout << "# periphery_only: "<<rw.periphery_only<<endl;
  cout << "# mutate_transport: "<<rw.mutate_transport<<endl;
  cout << "# internal_secretion: "<<rw.internal_secretion<<endl;
  cout << "# check_gendist: "<<check_gendist<<endl;
  cout << "# check_phenotypes: "<<check_phenotypes<<endl;
  cout << "# outnet: "<<outnet<<endl;
  cout << "# popsize: "<<popsize<<endl;
  cout << "# iter: "<<iter<<endl;
  cout << "# mutrate: "<<mutrate<<endl;
  cout << "# mstep: "<<mstep<<endl;
  cout << "# exthgt: " << exthgt << endl;
  cout << "# varsize: " << varsize << endl;
//  cout << "# number of total reactions: " << net.links.size() << endl;
  cout << "# world network: "<<argv[1] << endl;
  cout << "# reactions (world): "<<net.links.size()<<endl;

  rw.getEnv(argvc,argv);

  rw.load(net2);
  rw.calcPhenotype();

  cout << "# initial network: "<<argv[2]<<endl;
  cout << "# reactions (initial): "<<net2.links.size() << endl;
  cout << "# initial phenotype: "<<rw.printPhenotype()<<endl;

  rw.viablePhenotype=rw.phenotype;
  if (net2.info.findkey("phetarget")!=-1){
    net.info.add("phetarget",net2.info["phetarget"]);
    str2intarr(net2.info["phetarget"].substr(4),rw.viablePhenotype);
    cout << "# using phetarget from initial network file!"<<endl;
  }

  cout << "# viablePhenotype: " << intarr2str(rw.viablePhenotype) << endl;


  int i;
  eintarray phe_f,gen_f;

  gen_f = rw.genotype;
  phe_f = rw.phenotype;


  int op=0;
  int np=1;
  earray<eintarray> genotypes[2];
  earray<eintarray> phenotypes[2];
  int mutants,survivors;
  int j;
  int k;
  double gendist,gendist2,metnetsize;

  eintarray genpool[2];
  int genpoolcount[2];

  genpoolcount[op]=0;
  genpoolcount[np]=0;
  for (i=0; i<rw.genotype.size(); ++i){
    genpool[op].add(0);
    genpool[np].add(0);
  }

  cout << "# Populating world with individuals with genotype = g_S" << endl;
  for (i=0; i<popsize; ++i){
    genotypes[op].add(rw.genotype);
    phenotypes[op].add(rw.phenotype);
    genotypes[np].add(rw.genotype);
    phenotypes[np].add(rw.phenotype);
    addGenotype(genpool[op],genpoolcount[op],rw.genotype);
    addGenotype(genpool[np],genpoolcount[np],rw.genotype);
  }

  earrayof<int,eintarray> addphenotypes,delphenotypes;
  earrayof<int,eintarray> tpopphenotypes,tphenotypes,taddphenotypes,tdelphenotypes;

  pherobust(rw,addphenotypes);
  pheessential(rw,delphenotypes);

  bool mutated;
  double mutcounter=ernd.exponential(1.0/mutrate);

  cout << mutcounter << endl;

  cout << "# Starting population evolution" << endl;
  for (i=0; i<iter; ++i){
    resetCount(genpool[np],genpoolcount[np]);
    mutants=0; survivors=0;
    linfo("mutating and calculating new phenotype");
    for (j=0; j<genotypes[np].size(); ++j){
//      k=(int)(ernd.uniform()*genotypes[op].size());
//      k=((int)(3.0*(ernd.uniform()-0.5))+genotypes[op].size()+j)%genotypes[op].size();  // linear space neighbor selection
      k=get2DRand(j,w,popsize);

      rw.phenotype=phenotypes[op][k];
      rw.load(genotypes[op][k]);

      if (ernd.uniform() < mutrate){
        rw.mutate_genpool(genpool[op],genpoolcount[op],exthgt);
        rw.updatePhenotype();
      }

/*
      mutated=false;
      mutcounter-=1.0;
      while (mutcounter<=0.0) {
        rw.mutate_genpool(genpool[op],genpoolcount[op],exthgt);
        mutcounter+=ernd.exponential(1.0/mutrate);
        mutated=true;
      }
      if (mutated==true)
        rw.calcPhenotype();
 */




/*
      if (ernd.uniform() < mutrate){
        rw.phenotype=phenotypes[op][k];
        rw.load(genotypes[op][k]);

        if (varsize==1){
          if (ernd.uniform()<0.666)
            rw.mutate_add_genpool(genpool[op],genpoolcount[op],exthgt);
          else{
            rw.mutate_remove();
            rw.updatePhenotypeRemoval();
          }
        }else{
          rw.mutate_genpool(genpool[op],genpoolcount[op],exthgt);
          rw.updatePhenotype();
        }
*/

        
      if (rw.isViable()){
        genotypes[np][j]=rw.genotype;
        phenotypes[np][j]=rw.phenotype;
      }else{
        --j; continue; // if the mutant is not viable we give the place to another individual
      }
      addGenotype(genpool[np],genpoolcount[np],genotypes[np][j]);
    }
    op=np;
    np=(op+1)%2;

    if (check_gendist && !(i%dstep) && i){
      cout << i;

      cout << " " << countGenes(genpool[op]);

      metnetsize=0;
      gendist2=0.0;
      gendist=0.0;
      for (j=0; j<genotypes[op].size(); ++j){
        metnetsize+=countGenes(genotypes[op][j]);
        gendist2+=gendistance(genotypes[op][j],gen_f,&rw);
//        for (k=j+1; k<genotypes[op].size(); ++k)
//          gendist+=gendistance(genotypes[op][j],genotypes[op][k],&rw);
      }
//      cout << i << " " << gendist2/(double)genotypes[op].size() << " "<<gendist*2.0/(genotypes[op].size()*(genotypes[op].size()-1))<< " " << (double)survivors/mutants;
      cout << " " << gendist2/(double)genotypes[op].size() << " " << (double)metnetsize/(double)genotypes[op].size();
    }

    if (check_phenotypes && !(i%mstep) && i){
      tpopphenotypes.clear();
      for (j=0; j<genotypes[op].size(); ++j){
        rw.load(genotypes[op][j]);

        tphenotypes.clear();
        pherobust(rw,tphenotypes);
        pheessential(rw,tphenotypes);
        phemerge(tpopphenotypes,tphenotypes);

//        pherobust(rw,tphenotypes);
//        pheessential(rw,tphenotypes);
//        phemerge(pop_phenotypes,tphenotypes);
//        cout << " " << phediff(ophenotypes,tphenotypes) << " "<<uniqphediff(ophenotypes,tphenotypes) << " "<<phenotypes.size()<<endl;
//        tphenotypes.clear();
      }
      taddphenotypes.clear();
      tdelphenotypes.clear();
      phemerge(rw.viablePhenotype,taddphenotypes,tdelphenotypes,tpopphenotypes);
      cout << " " << taddphenotypes.size() << " " << tdelphenotypes.size() << " "; 
      phemerge(addphenotypes,taddphenotypes);
      phemerge(delphenotypes,tdelphenotypes);
      cout << " "<<addphenotypes.size()<< " " <<delphenotypes.size()<<endl;

//      phemerge(all_phenotypes,pop_phenotypes);
//      cout << i << " " << gendist2/(double)genotypes.size() << " "<<gendist*2.0/(genotypes.size()*(genotypes.size()-1))<< " " << survivors.size() << " "<< all_phenotypes.size() << " " << pop_phenotypes.size() << endl;
    }
    
    if (check_gendist && !(i%dstep) && i)
      cout << endl;
  }

  if (outnet.length()>0){
    for (j=0; j<genotypes[op].size(); ++j)
      net.saveactive(genotypes[op][j],outnet+"-"+estr(i)+"-"+estr(j)+".net");
  }

  return(0);
}

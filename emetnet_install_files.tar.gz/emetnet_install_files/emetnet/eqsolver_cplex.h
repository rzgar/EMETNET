#ifndef __EQSOLVER_CPLEX__
#define __EQSOLVER_CPLEX__

#include "esolver.h"

#include <ilcplex/cplex.h>


class eqsolver_cplex : public esolver
{
 public:
  enet* net;

  double   *x;
  double   *pi;
  double   *slack;
  double   *dj;


  CPXENVptr     env;
  CPXLPptr      lp;

  void parse(enet& net);
  double solve();

  void setxbounds(int i,double min,double max);
  void setxzero(int i);

  void positiveQ(int i);
  void negativeQ(int i);

  void activate(int i);
  void disable(int i);
};

class eqsolver_cplex2
{
 public:
  enet* net;

  double   *x;
  double   *pi;
  double   *slack;
  double   *dj;


  CPXENVptr     env;
  CPXLPptr      lp;

  void parse(enet& net);
  double solve();

  void setxbounds(int i,double min,double max);
  void setxzero(int i);

  void positiveQ(int i);
  void negativeQ(int i);
};

#endif


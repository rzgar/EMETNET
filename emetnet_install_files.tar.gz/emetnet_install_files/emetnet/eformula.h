#ifndef __EFORMULA__
#define __EFORMULA__

#include <eutils/eregexp.h>

class eformula
{
 public:
  mutable earrayof<float,estr> elements;

  eformula();
  eformula(const estr& formula);
  eformula(const eformula& formula);
  ~eformula();

  eformula& operator=(const estr& formula);
  eformula& operator+=(const estr& formula);

  eformula& operator=(const eformula& formula);

  eformula& operator+=(const eformula& formula);
  eformula& operator-=(const eformula& formula);
  eformula operator-(const eformula& formula);
  eformula operator*(int factor);
  eformula operator*(double factor);

  bool operator==(const eformula& formula);

  void clearZero() const;
  void clear();

  estr str();
};

eregexp re_element("[A-Z][a-z]?");
eregexp re_numerator("-?[0-9]+");


eformula::eformula(){}
eformula::~eformula(){}

eformula::eformula(const estr& formula)
{
  *this=formula;
}

eformula::eformula(const eformula& formula)
{
  *this=formula;
}

eformula& eformula::operator=(const eformula& f)
{
  elements=f.elements;
  return(*this);
}

eformula& eformula::operator=(const estr& f)
{
  int i,j;

  clear();

  estr elemstr;
  estr  numstr;
  for (i=0; i<f.size(); ){

    elemstr=re_match(f,re_element,i);
//    cout << "i: "<<i<<", e: " << elemstr << " - ";
    i=re_element.b;
    if (i==-1) break;
    numstr=re_match(f,re_numerator,i);
    j=re_numerator.b;
    if (j==-1 || j!=re_element.e){ numstr="1"; j=i+1; }

    i=j;

//    cout << "n: " << numstr << endl;
//    cout << "i: " << i << endl;
    elements[elemstr] = numstr.i();
  }
//  cout << "out" << endl;
  return(*this);
}

eformula& eformula::operator+=(const estr& formula)
{
  return(operator+=(eformula(formula)));
}

eformula& eformula::operator+=(const eformula& formula)
{
  int i;
  for (i=0; i<formula.elements.size(); ++i){
//    cout << "elements["<<formula.elements.keys(i)<<"] ("<<elements[formula.elements.keys(i)]<<") += "<<formula.elements.values(i) << endl;
    elements[formula.elements.keys(i)] += formula.elements.values(i);
//    cout << "elements["<<formula.elements.keys(i)<<"] == "<<elements[formula.elements.keys(i)]<< endl;
  }
  return(*this);
}

eformula& eformula::operator-=(const eformula& formula)
{
  int i;
  for (i=0; i<formula.elements.size(); ++i)
    elements[formula.elements.keys(i)] -= formula.elements.values(i);
  return(*this);
}

eformula eformula::operator-(const eformula& formula)
{
  eformula f;
  f=*this;
  f-=formula;
  return(f);
}

void eformula::clear()
{
  elements.clear();
}

void eformula::clearZero() const
{
  int i;
  for (i=0; i<elements.size(); ++i){
    if (elements.values(i)==0)
      { elements.erase(i); --i; }
  }
}

eformula eformula::operator*(double factor)
{
  int i;
  eformula f;

  f = *this;
  for (i=0; i<f.elements.size(); ++i)
    f.elements.values(i) = f.elements.values(i)*factor;
  return(f); 
}

eformula eformula::operator*(int factor)
{
  int i;
  eformula f;

  f = *this;
  for (i=0; i<f.elements.size(); ++i)
    f.elements.values(i) = f.elements.values(i)*factor;
  return(f); 
}

bool eformula::operator==(const eformula& formula)
{
  clearZero(); formula.clearZero();

  eformula diff;

  diff=*this-formula;
  diff.clearZero();
 
  if (diff.elements.size()==0) return(true);
 
  if (diff.elements.size()==1 && diff.elements.findkey("H") != -1) return(true);

  return(false);
}

estr eformula::str()
{
  int i;
  estr res;
  for (i=0; i<elements.size(); ++i){
    if (elements.values(i)!=0){
      res+=elements.keys(i);
      if (elements.values(i)!=1)
        res+=elements.values(i);
    }
  }
  return(res);
}

#endif


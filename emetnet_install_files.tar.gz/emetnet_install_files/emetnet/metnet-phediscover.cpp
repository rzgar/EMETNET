#include "enet.h"
#include "erandomwalk.h"

#include <eutils/emain.h>
#include <eutils/ernd.h>
#include <eutils/earrayof.h>

#define MIN(a,b) ( (a) < (b) ? (a) : (b) )

bool isViable(eintarray phe,eintarray mphe)
{
  int i;
  for (i=0; i<phe.size(); ++i)
    if (mphe[i]==1 && phe[i]==0) return(false);
  return(true);
}

void phemerge(eintarray phe,earrayof<int,eintarray>& pheadd,earrayof<int,eintarray> &phedel,earrayof<int,eintarray>& phelist)
{
  int i,j;

  int ccount,tcount;
  ccount=0;
  tcount=0;

  for (j=0; j<phelist.size(); ++j){
    if (isViable(phelist.keys(j),phe)){
      i=pheadd.findkey(phelist.keys(j));
      if (i==-1)
        pheadd.add(phelist.keys(j),phelist.values(j));
      else
        pheadd.values(i)+=phelist.values(j);
    }else{
      i=phedel.findkey(phelist.keys(j));
      if (i==-1)
        phedel.add(phelist.keys(j),phelist.values(j));
      else
        phedel.values(i)+=phelist.values(j);
    }
  }
}

double uniqphediff(earrayof<int,eintarray>& phelist1,earrayof<int,eintarray>& phelist2)
{
  int i,j;

  int ccount,tcount;
  ccount=0;

  for (i=0; i<phelist1.size(); ++i){
    j=phelist2.findkey(phelist1.keys(i));
    if (j!=-1)
      ++ccount;
  }
  return(1.0-2.0*(double)ccount/(double)(phelist1.size()+phelist2.size()));
}

double phediff(earrayof<int,eintarray>& phelist1,earrayof<int,eintarray>& phelist2)
{
  int i,j;

  int ccount,tcount;
  ccount=0;
  tcount=0;

  for (i=0; i<phelist1.size(); ++i){
    j=phelist2.findkey(phelist1.keys(i));
    if (j!=-1)
      ccount += MIN(phelist1.values(i),phelist2.values(j));
    tcount+=phelist1.values(i);
  }

  for (j=0; j<phelist2.size(); ++j)
    tcount += phelist2.values(j);

  return(1.0-2.0*(double)ccount/(double)tcount);
}

int emain()
{
  int i;
  ldieif (argvc<4,"syntax: ./metnet-phediscover <file.net> <starter.net> <env.flx env2.flx ...>"); 

  estr outnet="default.net";
  estr solver="cplex";
  int strict=0;
  int mstep=10;
  int iter=10000;
  int internal_secretion=0;
  int mutate_transport=0;
  int force_away=0;
  int only_viable=0;

  epregister(outnet);
  epregister(solver);
  epregister(strict);
  epregister(mstep);
  epregister(iter);
  epregister(mutate_transport);
  epregister(internal_secretion);
  epregister(force_away);
  epregister(only_viable);

  enet net;
  net.load(argv[1]); 
  net.correct_malformed();

  enet net2;
  net2.load(argv[2]);

  erandomWalk rw(net,solver,strict);

  rw.internal_secretion=internal_secretion;
  rw.mutate_transport=mutate_transport;
  rw.only_viable=only_viable;


  cout << "# metnet-phediscover" <<endl;
  cout << "# mutate_transport: " << mutate_transport << endl;
  cout << "# internal_secretion: " << internal_secretion << endl;
  cout << "# only_viable: " << rw.only_viable << endl;
  cout << "# strict: " << strict << endl;
  cout << "# force_away: " << force_away << endl;
  cout << "# mstep: " << mstep << endl;
  cout << "# iter: " << iter << endl;

  cout << "# global network: "<<argv[1] << endl;
  cout << "# reactions in global net: " << net.links.size() << endl;
  cout << "# initial network: "<<argv[2] << endl;
  cout << "# reactions in initial net: "<<net2.links.size()<<endl;

  rw.getEnv(argvc,argv);

  rw.load(net2);
  rw.calcPhenotype();
  rw.viablePhenotype=rw.phenotype;
  if (net2.info.findkey("phetarget")!=-1){
    str2intarr(net2.info["phetarget"].substr(4),rw.viablePhenotype);
    cout << "# using phetarget from initial network file!"<<endl;
  }
  cout << "# viablePhenotype: " << intarr2str(rw.viablePhenotype) << endl;
  cout << "# initial phenotype: "<< intarr2str(rw.phenotype)<<endl;

  eintarray phe_f,gen_f;

  earrayof<int,eintarray> addphenotypes,delphenotypes;
  earrayof<int,eintarray> tphenotypes,taddphenotypes,tdelphenotypes;
  earrayof<int,eintarray> oaddphenotypes,odelphenotypes;

  gen_f = rw.genotype;
  phe_f = rw.phenotype;

  pherobust(rw,oaddphenotypes);
  pheessential(rw,odelphenotypes);
  phemerge(addphenotypes,oaddphenotypes);
  phemerge(delphenotypes,odelphenotypes);

  cout << "#iter   hamming_distance    addphe   delphe  diff(addphe,oaddphe)  diff(delphe,odelphe)  udiff(addphe,oaddphe)  udiff(delphe,odelphe)  cumul_addphe  cumul_delphe"<<endl;
  for(i=0; i<iter; ++i){
    if (force_away==1) rw.mutate_away(gen_f); else rw.mutate();

    rw.updatePhenotype();
    if (!rw.isViable()){ rw.revert(); rw.phenotype=phe_f; --i; continue; }
    phe_f = rw.phenotype;

    cout << i << " " << gendistance(gen_f,rw.genotype);
    if (i && !(i%mstep)){
      pherobust(rw,tphenotypes);
      pheessential(rw,tphenotypes);
      phemerge(rw.viablePhenotype,taddphenotypes,tdelphenotypes,tphenotypes);
      cout << " " << taddphenotypes.size() << " " << tdelphenotypes.size() << " "; 
      phemerge(addphenotypes,taddphenotypes);
      phemerge(delphenotypes,tdelphenotypes);

      cout << phediff(oaddphenotypes,taddphenotypes) << " " << phediff(odelphenotypes,tdelphenotypes) << " "<< uniqphediff(oaddphenotypes,taddphenotypes) << " "<<uniqphediff(odelphenotypes,tdelphenotypes) << " "<<addphenotypes.size()<< " " <<delphenotypes.size();
      tphenotypes.clear();
      taddphenotypes.clear();
      tdelphenotypes.clear();
    }
    cout << endl;
  }
  net.saveactive(outnet);

  cout << i << " " << gendistance(gen_f,rw.genotype) << " ";
  pherobust(rw,tphenotypes);
  pheessential(rw,tphenotypes);
  phemerge(rw.viablePhenotype,taddphenotypes,tdelphenotypes,tphenotypes);
  cout << taddphenotypes.size() << " " << tdelphenotypes.size() << " "; 
  phemerge(addphenotypes,taddphenotypes);
  phemerge(delphenotypes,tdelphenotypes);
  cout << phediff(oaddphenotypes,taddphenotypes) << " " << phediff(odelphenotypes,tdelphenotypes) << " "<< uniqphediff(oaddphenotypes,taddphenotypes) << " "<<uniqphediff(odelphenotypes,tdelphenotypes) << " "<<addphenotypes.size()<< " " <<delphenotypes.size()<<endl;

  return(0);
}

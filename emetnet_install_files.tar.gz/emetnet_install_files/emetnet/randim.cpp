#include <stdlib.h>
#include <stdio.h>
#include <time.h>

/* function main begins program execution */
int main(void) {

	srand(time(NULL)); /* seed random number generator */
	/* loop 10 times */ 

	/* pick a random number from 1 to 6 and output it */
	printf("%10d", 1 + (rand() % 600));


	return 0; /* indicates successful termination */
} /* end main */

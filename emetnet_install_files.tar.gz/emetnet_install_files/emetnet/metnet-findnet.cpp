#include "enet.h"
#include "erandomwalk.h"

#include <eutils/emain.h>
#include <eutils/ernd.h>

int emain()
{
  ldieif (argvc<4,"syntax: ./metnet-findphe [-phe count] [-outnet file.net] [-solver clp|cplex] <file.net> <starter.net> <env.flx env2.flx ...>"); 

  int rcount=0;
  int mutate_transport=0;

  estr outnet="default.net";
	estr solver="esolver_clp";

  epregister(rcount);
  epregister(mutate_transport);
  epregister(outnet);
  epregister(solver);
  

  enet net;
  net.load(argv[3]); 
  net.correct_malformed();

  enet net2;
  net2.load(argv[4]);

  epregisterClassProperty(erandomWalk,solvername);

  erandomWalk rw(net,solver,0);
  rw.mutate_transport=mutate_transport;
  epregister(rw);

  cout << "# solver: "<<rw.solvername << endl;
  cout << "# mutate_transport: "<< mutate_transport << endl;
  cout << "# global network: "<<argv[3] << endl;
  cout << "# total reactions (global): " << net.links.size() << endl;

  rw.getEnv(argvc,argv);

  cout << "# initial network: " << argv[4] << endl;
  cout << "# total reactions (initial): " << net2.links.size() << endl;

  rw.load(net2);
  rw.calcPhenotype();

  if (rcount>0)
    rw.setRSize(rcount);
  else
    rcount=rw.count;

  cout << "# rcount: "<< rcount << endl;
  cout << "# target network size: " << rcount << endl;

  int m,tmpmin;
  eintarray phe_s;
  eintarray phe_target;
  eintarray oldphe;
  phe_s=rw.phenotype;
  oldphe=rw.phenotype;

  cout << "# phenotype (initial): " << intarr2str(phe_s) <<endl;

  int i; 
  eintarray essreactions;
  for (i=0; i<rw.genotype.size(); ++i)
    essreactions.add(0);
  int esscount=0;

  i=0;
  while (rw.acount!=rw.count){
    rw.mutate();
    rw.updatePhenotype();

    tmpmin = countPhenotype(rw.phenotype);
    if (tmpmin==0){
      cout << "# " << rw.acount << " " << esscount << " " << rw.printPhenotype() << endl;
      if (essreactions[rw.lastRemoveMutation]==0)
        ++esscount;
      essreactions[rw.lastRemoveMutation]=1;
      rw.revert();
      rw.phenotype=oldphe;
      if (esscount==rw.acount) { cout << "# all reactions are essential: "<< rw.acount << " " << esscount << endl; break; }
      continue;
    }
    cout << rw.acount << " " << esscount << " " << rw.printPhenotype() << endl;
    oldphe=rw.phenotype;
    ++i;
    if (i==20000){
      cout << "# warning: viable network with requested size was not found in 10'000 iterations, stopping simulation"<<endl;
      exit(1);
    }
  }

  cout << "# found network with phenotype: "<< rw.printPhenotype() << endl;

  net.saveactive(outnet);

  return(0);
}

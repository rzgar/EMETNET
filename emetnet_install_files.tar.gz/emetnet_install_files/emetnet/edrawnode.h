#ifndef EDRAWNODE_H
#define EDRAWNODE_H

#include "edrawnet.h"

class edrawnet;

class edrawnode
{
 public:
  edrawnet* drawnet;
  bool selected;
  bool active;
  bool source;
  bool objective;

  enode* node;
  estr name;

  evector2 pos;
  evector2 pos2;
  evector2 acc;
   
//   earray<edrawlink*> links;
  int linkcount;

  edrawnode(edrawnet* drawnet,enode* node=0x00);
   
  void draw();
};


#endif


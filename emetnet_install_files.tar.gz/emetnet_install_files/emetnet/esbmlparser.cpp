#include <eutils/efile.h>
#include <eutils/ehtml.h>
#include <eutils/eregexp.h>
#include <eutils/eheap.h>

#include "emetnetdb.h"
#include "esbmlparser.h"
#include "enet.h"

void parseReactionReactants(ehtmltag& tag,enet& net,elink& reaction,estrhashof<enode*>& nodes)
{
  int i;
  enode *node;
  for (i=0; i<tag.parts.size(); ++i){
    if (tag.parts[i].type.len()==0) continue;
    ldieif(!nodes.exists(html_entities_decode(tag.parts[i].args["species"])),"Metabolite not found: "+html_entities_decode(tag.parts[i].args["species"]));
    node=nodes[html_entities_decode(tag.parts[i].args["species"])];
    if (tag.parts[i].args.findkey("stoichiometry")!=-1)
      reaction.src.add(elinkelem(node,tag.parts[i].args["stoichiometry"].d()));
    else
      reaction.src.add(elinkelem(node,1.0l));
  }
}

void parseReactionProducts(ehtmltag& tag,enet& net,elink& reaction,estrhashof<enode*>& nodes)
{
  int i;
  enode *node;
  for (i=0; i<tag.parts.size(); ++i){
    if (tag.parts[i].type.len()==0) continue;
    ldieif(!nodes.exists(html_entities_decode(tag.parts[i].args["species"])),"Metabolite not found: "+html_entities_decode(tag.parts[i].args["species"]));
    node=nodes[html_entities_decode(tag.parts[i].args["species"])];
    if (tag.parts[i].args.findkey("stoichiometry")!=-1)
      reaction.dst.add(elinkelem(node,tag.parts[i].args["stoichiometry"].d()));
    else
      reaction.dst.add(elinkelem(node,1.0l));
  }
}

void parseReaction(ehtmltag& tag,enet& net,estrhashof<enode*>& nodes)
{
  elink reaction;
//  estrarray arr;
  if (tag.args.findkey("id")!=-1){
    reaction.id=html_entities_decode(tag.args["id"]);
  }else if (tag.args.findkey("name")!=-1)
    reaction.id=html_entities_decode(tag.args["name"]);
  else
    ldie("Reaction name not found. Neither *id* nor *name*");

  if (reaction.id.substr(0,2)=="R_" || reaction.id.substr(0,2)=="r_") reaction.id.del(0,2); // remove r_ prefix

  reaction.transport=false;
	reaction.active=true;

  if (tag.args.findkey("reversible")==-1 || tag.args["reversible"]=="true")
    reaction.irreversible=false;
  else if (tag.args["reversible"]=="false")
    reaction.irreversible=true;
  else
    lwarn("unknown reversible value for reaction: "+tag.args["reversible"]+" id: "+reaction.id);

  bool foundProducts=false;
  int i;
  for (i=0; i<tag.parts.size(); ++i){
    if (tag.parts[i].type.len()==0) continue;
    if (tag.parts[i].type=="listofreactants")
      parseReactionReactants(tag.parts[i],net,reaction,nodes);
    if (tag.parts[i].type=="listofproducts"){
      parseReactionProducts(tag.parts[i],net,reaction,nodes);
      foundProducts=true;
    }
  }
  if (!foundProducts){
    ldieif(reaction.src.size()!=1,"Missing products and not single reactant");
    if (reaction.src[0].node->id.substr(0,-3)=="[e]") { lwarn("external exchange reaction: "+reaction.id); return; }
    reaction.dst.add(elinkelem(net.getnode(reaction.src[0].node->id.substr(0,-3)+"[e]"),reaction.src[0].rate));
  }else if (reaction.src.size()==1 && reaction.dst.size()==1 && reaction.src[0].node==reaction.dst[0].node){
//     lwarn("external exchange reaction: "+reaction.id);
     return;
  }

  reaction.info.add(reaction.id);
  net.links.add(reaction.id,reaction);
//  cout << reaction << endl;
}

void parseListOfReactions(ehtmltag& tag,enet& net,estrhashof<enode*>& nodes)
{
  int i;
//  estrarray rinfo;
  for (i=0; i<tag.parts.size(); ++i){
    if (tag.parts[i].type.len()==0) continue;
    parseReaction(tag.parts[i],net,nodes);
//    cout << rinfo << endl;
  }
}

eregexp re_compartment_suffix("_[a-z]$");

void parseSpecie(ehtmltag& tag,enet& net,estrhashof<enode*>& nodes)
{
  
  enode metabolite;
  estr metid;
  estr compartment;
//  estrarray arr;
  if (tag.args.findkey("id")!=-1){
    metabolite.id=html_entities_decode(tag.args["id"]);
  }else if (tag.args.findkey("name")!=-1)
    metabolite.id=html_entities_decode(tag.args["name"]);
  else
    ldie("Species name not found. Neither *id* nor *name*");

  metid=metabolite.id;

//  metabolite.id.replace("_DASH_","-");
//  if (metabolite.id.substr(0,2)=="M_" || metabolite.id.substr(0,2)=="m_") metabolite.id.del(0,2); // remove prefixes
//  if (re_compartment_suffix.match(metabolite.id)!=-1) metabolite.id.del(-2); // remove suffixes

  compartment=html_entities_decode(tag.args["compartment"]);
  if (tag.args.findkey("boundarycondition")!=-1 && tag.args["boundarycondition"]=="true")
    compartment="e";

  if (compartment=="Cytosol" && metabolite.id.substr(-2)=="_b")
    compartment="e"; // This is needed because in Palsson's SBML files they use sinks for internal metabolites degraded through unknown pathways
  compartment=compartment.substr(0,1).lowercase();
  metabolite.id.replace("_DASH_","-");
  if (metabolite.id.substr(0,2)=="M_" || metabolite.id.substr(0,2)=="m_") metabolite.id.del(0,2); // remove prefixes
  if (re_compartment_suffix.match(metabolite.id)!=-1) metabolite.id.del(-2); // remove suffixes
  nodes.add(metid,net.getnode(metabolite.id+"["+compartment+"]"));
}

void parseListOfSpecies(ehtmltag& tag,enet& net,estrhashof<enode*>& nodes)
{
  int i;
//  estrarray rinfo;
  for (i=0; i<tag.parts.size(); ++i){
    if (tag.parts[i].type.len()==0) continue;
    parseSpecie(tag.parts[i],net,nodes);
//    cout << rinfo << endl;
  }
}

void parseModel(ehtmltag& tag,enet& net)
{
  int i;
  estrhashof<enode*> nodes;
  for (i=0; i<tag.parts.size(); ++i){
    if (tag.parts[i].type.len()==0) continue;
    if (tag.parts[i].type=="listofspecies")
      parseListOfSpecies(tag.parts[i],net,nodes);
    if (tag.parts[i].type=="listofreactions")
      parseListOfReactions(tag.parts[i],net,nodes);
  }
}

void parseSBML(ehtmltag& tag,enet& net)
{
  int i;
  for (i=0; i<tag.parts.size(); ++i){
    if (tag.parts[i].type.len()==0) continue;
    if (tag.parts[i].type=="model")
      parseModel(tag.parts[i],net);
  }
}

void loadSBML(const estr& file,enet& net)
{
  ehtml html;
  html.load(file);

  int i;
  for (i=0; i<html.parts.size(); ++i){
    if (html.parts[i].type.len()==0) continue;
    if (html.parts[i].type=="sbml")
      parseSBML(html.parts[i],net);
  }

  cout << "# reactions: " << net.links.size() << endl;
  cout << "# metabolites: " << net.nodes.size() << endl;
}


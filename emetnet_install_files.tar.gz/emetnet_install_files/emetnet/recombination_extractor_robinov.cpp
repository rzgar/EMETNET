#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <vector>
#include <eutils/estrarrayof.h>
#include <eutils/eregexp.h>
using std::vector;

double D=-1;
double d=-1;
double delta=-1;
int carbon_source=-1;
int emain()
{
ldieif(argvc<6,"syntax: ./recombination_extractor2 <inputfile> <outputfile> -D <x> -d <y> -delta <del> -carbon_source <z>" );
epregister(D);
epregister(d);
epregister(delta);
epregister(carbon_source);
eparseArgs(argvc,argv);
/////////////////////////////////////////////////////////////////////////////////
double x=D;
double y=d;
double phen_dist=delta;
int z=carbon_source;
estr infile1=argv[1];
estr infile2=infile1+"_phen";
estr outfile=argv[2];
efile fin1;
efile fin2;
efile fout;
estr str1;
estr str2;
estrarray parts;
double phenotype[10000][50];
for (int i=0;i<10000;i++){
     for (int j=0;j<50;j++){phenotype[i][j]=0;}
}
double parent1[50];
double parent2[50];

for (int i=0;i<50;i++){parent1[i]=0;parent2[i]=0;}

double gain_loss[10000][4];
for (int i=0;i<10000;i++){
     for (int j=0;j<4;j++){gain_loss[i][j]=0;}
}
int count1=0;
int count2=0;
fin1.open(infile1,"r");
fin2.open(infile2,"r");

while (fin1.readln(str1)) {
      parts=str1.explode(" ");
      for (int i=0; i<parts.size();++i){int gg1=parts[i].i();double gg2=(double) (gg1); gain_loss[count1][i]=gg2;}
      count1++;
}
fin1.close();

while (fin2.readln(str2)) {
      parts=str2.explode(" ");
      if (count2==0){for (int i=0; i<parts.size();++i){int gg1=parts[i].i();double gg2=(double) (gg1);parent1[i]=gg2;}} 
      if (count2==1){for (int i=0; i<parts.size();++i){int gg1=parts[i].i();double gg2=(double) (gg1);parent2[i]=gg2;}} 
      if (count2>1){for (int i=0; i<parts.size();++i){int gg1=parts[i].i();double gg2=(double) (gg1);phenotype[count2-2][i]=gg2;}}
      count2++;
}
fin2.close();

double robust_gain1=0;
double robust_loss1=0;
double robust_gain2=0;
double robust_loss2=0;
double gain1=0;
double loss1=0;
double gain2=0;
double loss2=0;
double counter=0;
for (int i=0;i<10000;i++){
     gain1=gain1+gain_loss[i][0];
     gain2=gain2+gain_loss[i][1];
     loss1=loss1+gain_loss[i][2];
     loss2=loss2+gain_loss[i][3];
     if (phenotype[i][z]==1){robust_gain1=robust_gain1+gain_loss[i][0];robust_loss1=robust_loss1+gain_loss[i][2];robust_gain2=robust_gain2+gain_loss[i][1];robust_loss2=robust_loss2+gain_loss[i][3];
         counter++;}
}
double ave_robustness=(double) (counter/10000);
double ave_gain1=(double) (gain1/10000);
double ave_loss1=(double) (loss1/10000);
double ave_gain2=(double) (gain2/10000);
double ave_loss2=(double) (loss2/10000);
double ave_robust_gain1=(double) (robust_gain1/counter);
double ave_robust_loss1=(double) (robust_loss1/counter);
double ave_robust_gain2=(double) (robust_gain2/counter);
double ave_robust_loss2=(double) (robust_loss2/counter);

estr D_str=D;
estr d_str=d;
estr ave_robustness_str=ave_robustness;
estr phen_distance=phen_dist;

estr ave_gain1_str=ave_gain1;
estr ave_loss1_str=ave_loss1;
estr ave_robust_gain1_str=ave_robust_gain1;
estr ave_robust_loss1_str=ave_robust_loss1;

estr ave_gain2_str=ave_gain2;
estr ave_loss2_str=ave_loss2;
estr ave_robust_gain2_str=ave_robust_gain2;
estr ave_robust_loss2_str=ave_robust_loss2;

cout<<"/////////////////////////////////"<<endl;
cout<<D_str<<endl;
cout<<d_str<<endl;
cout<<ave_robustness_str<<endl;

cout<<ave_gain1_str<<endl;
cout<<ave_loss1_str<<endl;
cout<<ave_robust_gain1_str<<endl;
cout<<ave_robust_loss1_str<<endl;

cout<<ave_gain2_str<<endl;
cout<<ave_loss2_str<<endl;
cout<<ave_robust_gain2_str<<endl;
cout<<ave_robust_loss2_str<<endl;
cout<<"/////////////////////////////////"<<endl;

fout.open(outfile,"a");
fout.write(D_str+" "+d_str+" "+phen_distance+" "+ave_robustness_str+" "+ave_gain1_str+" "+ave_loss1_str+" "+ave_robust_gain1_str+" "+ave_robust_loss1_str+" "+ave_gain2_str+" "+ave_loss2_str+" "+ave_robust_gain2_str+" "+ave_robust_loss2_str+"\n");
fout.close();
return(0);
}

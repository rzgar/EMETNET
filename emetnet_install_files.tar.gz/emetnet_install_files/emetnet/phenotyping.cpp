#include "enet.h"
#include "erandomwalk.h"
#include <eutils/logger.h>
#include <eutils/emain.h>
#include <signal.h>
#include <eutils/eheap.h>
#include <algorithm>
#include <eutils/ernd.h>

estr solver="esolver_clp";
int netsize=-1;
int strict=0;
int periphery_only=0;
int mutate_transport=0;
int internal_secretion=0;
int only_viable=0;
double gendist=0.0;
enet net;
erandomWalk *prw=0x00;


int emain()
{ ldieif(argvc<3,"syntax: ./phenotyping  <file.net> <fluxbounds.flx>");  
  eparseArgs(argvc,argv);
////////////////////////////////////////////////////////////// Genotyping /////////////////////////////////////////////////////////////////
  net.load(argv[1]); 
  net.correct_malformed();
  erandomWalk rw(net,solver,strict);
  prw=&rw; 
  rw.periphery_only=periphery_only;
  rw.mutate_transport=mutate_transport;
  rw.internal_secretion=internal_secretion;
  rw.only_viable=only_viable;
  rw.setRSize(netsize);
  rw.getEnv(argvc,argv);
  rw.load(net);
  rw.calcPhenotype(); 

  estr filein=argv[1];
  estr fileout=filein+"_phenotype";
  eintarray phen = rw.phenotype;

  estr intstr = intarr2str2(phen);
  cout<<intstr<<endl;
  efile fout;
  fout.open(fileout,"w");
  fout.write(intstr+"\n"); 
  fout.close();
  return(0);
}




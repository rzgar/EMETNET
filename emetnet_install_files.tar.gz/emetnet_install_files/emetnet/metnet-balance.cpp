
#include "enet.h"

#include <fstream>
#include <eutils/emain.h>
#include <eutils/eudl.h>
#include "eformula.h"

etable table;
etable reactions;
etable ijr904compounds;

int find_entry(const estr& entry)
{
  int i;
  for (i=0; i<table.size(); ++i){
    if (entry == table["entry"][i].get<estr>().substr(0,6))
      return(i);
  }

  return(-1);
}

int find_ijr904entry(const estr& entry)
{
  int i;
  for (i=0; i<ijr904compounds.size(); ++i){
    if (entry==ijr904compounds["abbreviation"][i].get<estr>())
      return(i);
  }

  estr tmpstr;

  tmpstr=entry.substr(0,-4);
  for (i=0; i<ijr904compounds.size(); ++i){
    if (tmpstr==ijr904compounds["abbreviation"][i].get<estr>())
      return(i);
  }

  return(-1);
}

int find_reaction(const estr& entry)
{
  int i;
  for (i=0; i<reactions.size(); ++i){
    if (entry==reactions["entry"][i].get<estr>())
      return(i);
  }

  return(-1);
}

void cout_link(elink& link)
{
  int i,i2;

  cout << estr(link.info) << ": ";
  for (i=0; i<link.src.size()-1; ++i){
    if (link.src[i].rate!=1.0)
      cout << "("<<link.src[i].rate <<") ";
    cout << link.src[i].node->id << " ";
    i2=find_entry(link.src[i].node->id);
    if (i2!=-1)
      cout << "["<<table["formula"][i2]<<"] ";
    else{
      i2 = find_ijr904entry(link.src[i].node->id);
      if (i2!=-1)
        cout << "["<<ijr904compounds["molecular_formula"][i2]<<"] ";
    }


    cout << "+ ";
  }
  if (link.src[i].rate!=1.0)
    cout << "("<<link.src[i].rate <<") ";
  cout << link.src[i].node->id << " ";
  i2=find_entry(link.src[i].node->id);
  if (i2!=-1)
    cout << "["<<table["formula"][i2]<<"] ";
  else{
    i2 = find_ijr904entry(link.src[i].node->id);
    if (i2!=-1)
      cout << "["<<ijr904compounds["molecular_formula"][i2]<<"] ";
  }
 
  if (link.irreversible)
    cout << "--> ";
  else
    cout << "<=> ";

  for (i=0; i<link.dst.size()-1; ++i){
    if (link.dst[i].rate!=1.0)
      cout << "("<<link.dst[i].rate <<") ";
    cout << link.dst[i].node->id << " ";
    i2=find_entry(link.dst[i].node->id);
    if (i2!=-1)
      cout << "["<<table["formula"][i2]<<"] ";
    else{
      i2 = find_ijr904entry(link.dst[i].node->id);
      if (i2!=-1)
        cout << "["<<ijr904compounds["molecular_formula"][i2]<<"] ";
    }


    cout << "+ ";
  }
  if (link.dst[i].rate!=1.0)
    cout << "("<<link.dst[i].rate <<") ";
  cout << link.dst[i].node->id << " ";
  i2=find_entry(link.dst[i].node->id);
  if (i2!=-1)
    cout << "["<<table["formula"][i2]<<"] ";
  else{
    i2 = find_ijr904entry(link.dst[i].node->id);
    if (i2!=-1)
      cout << "["<<ijr904compounds["molecular_formula"][i2]<<"] ";
  }


  estr comment;
  if (link.info["DB"] == "KEGG"){
    comment = reactions["comment"][ find_reaction(link.info[0]) ].get<estr>();
    if (comment.len())
      cout << " | comment: "<<comment;
  }
}

void check_reaction(enet &net,elink &link)
{
  int i;
  int i2;

  eformula subst,prods;

  for (i=0; i<link.src.size(); ++i){
    i2=find_entry(link.src[i].node->id);

    if (i2==-1) {
      i2 = find_ijr904entry(link.src[i].node->id);

      if (i2==-1){
        cout << "* ";
        cout_link(link);
        cout << endl;
        return;
//    lderror("didnt find missing compound in ijr904 compound list!! ("+link.src[i].node->id+")");
      }

//      subst += eformula(ijr904compounds[ i2 ]["molecular_formula"])*(int)link.src[i].rate;
      subst += eformula(ijr904compounds["molecular_formula"][ i2 ].get<estr>())*link.src[i].rate;
    }
    else
//      subst += eformula(table[ i2 ]["formula"])*(int)link.src[i].rate;
      subst += eformula(table["formula"][ i2 ].get<estr>())*link.src[i].rate;
  }


  for (i=0; i<link.dst.size(); ++i){
    i2=find_entry(link.dst[i].node->id);
    if (i2==-1) {
      i2 = find_ijr904entry(link.dst[i].node->id);

      if (i2==-1){
        cout << "* ";
        cout_link(link);
        cout << endl;
        return;
//    lderror("didnt find missing compound in ijr904 compound list!! ("+link.src[i].node->id+")");
      }

      prods += eformula(ijr904compounds["molecular_formula"][ i2 ].get<estr>())*link.dst[i].rate;
//      prods += eformula(ijr904compounds[ i2 ]["molecular_formula"])*(int)link.dst[i].rate;
    }
    else
//      prods += eformula(table[ i2 ]["formula"])*(int)link.dst[i].rate;
      prods += eformula(table["formula"][ i2 ].get<estr>())*link.dst[i].rate;
  }

  if (subst == prods){
    link.info["B"] = "1";
    cout << "= "<< subst.str() << " - " << prods.str() << endl;
  }else{
    eformula diff;
    diff = (subst-prods);
    if (diff == eformula("H2O")){
      prods += "H2O";
      link.dst.add(elinkelem(net.getnode("C00001"),1.0));
    }else if (diff == eformula("H-2O-1")){
      subst += "H2O";
      link.src.add(elinkelem(net.getnode("C00001"),1.0));
    }else if (diff == eformula("CO2")){
      prods += "CO2";
      link.dst.add(elinkelem(net.getnode("C00011"),1.0));
    }else if (diff == eformula("C-1O-2")){
      subst += "CO2";
      link.src.add(elinkelem(net.getnode("C00011"),1.0));
    }

    
    if (subst == prods){
      link.info["B"] = "1";
      cout << "c " << (subst-prods).str() << " -- " << subst.str() << " - " << prods.str() << " :: ";

    }
      
    cout << "! " << (subst-prods).str() << " -- " << subst.str() << " - " << prods.str() << " :: ";
    
    cout_link(link);
    
    cout << endl;
  }
}



int main()
{
  ldieif (argvc<2,"syntax: ./emetnet <file.net>");  

  enet net;
  net.load(argv[1]); 

  table=udl_load("kegg_compound.csv");
  reactions=udl_load("mysql://root@localhost/kegg_ligand.reaction");
  ijr904compounds=udl_load("mysql://root@localhost/ijr904.compound");

  int i;
  for (i=0; i<net.links.size(); ++i)
    check_reaction(net,net.links[i]);

  if (argvc==3){
    ofstream f;
    f.open(argv[2]);
    f << net << endl;
    f.close();
  }

  return(0);
}
